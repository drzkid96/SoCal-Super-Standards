---
title: "E 660 Medians"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-600-cross-section-elements-6350a4f3/">E 600 Cross-Section Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-660-medians">Official BOE section</a></p>

<div><div>
        <div><p>A median is a portion of a divided street separating the traveled ways for traffic in opposite directions. It is an essential and intrinsic part of freeways and limited access streets, and a desirable element of major streets.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-661-use-medians-general-f2f5b5e5/">E 661 Use Of Medians (General)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-662-types-medians-7fd2bb99/">E 662 Types of Medians</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-663-width-standards-determination-medians-160eb177/">E 663 Width Standards Determination of Medians</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-664-median-left-turn-lanes-pockets-5917ecda/">E 664 Median Left-Turn Lanes (Pockets)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-665-grade-determination-medians-6a4b24d0/">E 665 Grade Determination of Medians</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-666-drainage-considerations-2c58bf16/">E 666 Drainage Considerations</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-667-cross-section-curbed-median-69bb173c/">E 667 Cross-Section of Curbed Median</a></li></ul>
