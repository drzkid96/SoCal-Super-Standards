---
title: "E 651 Block Corner Property Lines"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-650-borders-3f146405/">E 650 Borders</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-650-borders/e-651-block-corner-property-lines">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>All block corners should be provided with rounded or diagonal cutoff property lines. Adequate sight distance at the intersection for both pedestrian and motor vehicle operator may thus be obtained since construction of buildings or other improvements would not be permitted in this cutoff area. In some cases, the cutoff area may be needed to provide the minimum width required for sidewalk construction. In hillside terrain, the cutoff area may have to be graded to provide the sight distance or the sidewalk area.</p><p>On all major and secondary highways, the block corner property line should have a 20-foot-radius curve. On all other streets a 15-foot-radius curve may be permitted. However, where commercial development is permitted, a 15-foot by 15-foot diagonal cutoff, in lieu of a 20-foot-radius curve, and a 10-foot by 10-foot cutoff, in lieu of a 15-foot radius curve, may be used. In industrial zones, the curves should have minimum radii of at least 40 feet. However, every effort should be made to ensure that property line returns or cut corners are based on the ultimate right of way requirements. This is done to clearly indicate the City’s intent to improve intersecting streets (particularly major or secondary highways) to their ultimate right of way width. See Figure E 451A.</p><p>Some block corners in existing rights of way may have existing improvements or terrain which make it economically unfeasible to provide the cutoff dimensions given above. In such cases, it may be necessary to reduce either the radius of curvature or the length of the diagonal cutoff. See Figure E 451B.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing plan views of block corner property line cut-offs at secondary highways" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20451A%20Block%20Corner%20Property%20Line%20Cut-Offs.png?itok=FSTN8wkp">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing plan views of block corner property line cut-offs at secondary highways</figcaption>
</figure>
<p></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing the plan views of sidewalk alignments at intersections and variations of block corner property line cut-offs" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20451B%20Sidewalk%20Alignments%20at%20Intersections.png?itok=p9WWIyZi">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing the plan views of sidewalk alignments at intersections and variations of block corner property line cut-offs</figcaption>
</figure>
</div>
      </div></div>
