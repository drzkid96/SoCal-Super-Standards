---
title: "E 140 Fundamentals of Real Property for Street Design Purposes"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-100-introduction-and-general-information-2be36ad5/">E 100 Introduction and General Information</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information/e-140-fundamentals-real-property-street-design-purposes">Official BOE section</a></p>

<div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-0-d4e4374a/">E 141 Basis of Rights</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-1-d76a39a6/">E 142 Rights of Owner</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-5-08f3d80d/">E 143 Rights of City</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-3-f926a4c8/">E 144 City&#x27;s Use of Property</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-2-d15e99bc/">E 145 Procedures of Acquisition</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-4-11f67acb/">E 146 Procedures of Relinquishment</a></li></ul>
