---
title: "E 421 Basic Grade Controls"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-420-vertical-alignment-e0a07544/">E 420 Vertical Alignment</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-420-vertical-alignment/e-421-basic-grade-controls">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Part of this discussion will cover the basic grade controls: maximum grades, minimum grades, and critical lengths of grade. The rest of the discussion, as with basic grade control, will probably have more application to freeways and highways in undeveloped and rural areas than to City streets. The general principles, however, should be practiced, whenever feasible, in City streets.</p><h4>E 421.1 Maximum Grades</h4><p>The basic grade controls vary with the type of terrain and the design speed. The relation of maximum grade to design speed is shown in Figure E 321.1, below. The figure shows grades for main highways and those longer than 500 feet. Shorter length grades may be 1 percent steeper. Highways with low volume of traffic, lesser designated highways, and extreme cases such as underpasses and bridge approaches may be approximately 2 percent steeper than shown. All these criteria should be used as a guide rather than as an absolute control.<span>  </span>See Section E 500, Grade Determination.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table of the standard relation between the maximum grades on main highways to design speed" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-08/E%20400%20Fig%20E%20321.1%20Relation%20of%20Max%20Grades%20to%20Design%20Speed.png?itok=DvTNN0m2">



      </div>
          </div>

</div>

<figcaption>Table of the standard relation between the maximum grades on main highways to design speed</figcaption>
</figure>
<p></p><h4>E 421.2 Minimum Grades</h4><p>Flat or level grades on uncurbed pavements in outlying areas may be acceptable when the pavement has sufficient crown to transversely drain the surface runoff.  In cut sections or curbed streets, level or extremely flat grades cannot be used since lateral drainage is blocked. In these cases, adequate longitudinal drainage should be provided See Chapter E 500, Grade Determination.</p><h4>E 421.3 Critical Length of Grade</h4><p>The length or steep uphill grade beyond which truck traffic slows down to a speed which is more than 15 mph below the average running speed of all other vehicles is called the critical length of grade. <a>See Figure E 321.3</a>.<span>  </span>The following should be used as a guide rather than as an absolute control.<span>  </span>The length of the steep grade should not exceed the critical length for a given average running speed where long steep grades must be used and when one of the following conditions is<span> </span>present:</p><ol><li><span>The rate of grade cannot be</span><span> </span><span>reduced.</span></li><li><span>An additional passing lane is provided on</span><span> </span><span>the </span>ascending side of a two-lane highway.</li><li>An additional passing lane is provided on the ascending side of a four-lane highway approaching maximum<span> </span>capacity.</li></ol><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph showing the critical lengths of grade, in feet, by percent upgrade for design." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20321.3%20Critical%20Lengths%20of%20Grade%20for%20Design_crop.png?itok=9vM6JC4F">



      </div>
          </div>

</div>

<figcaption>Graph showing the critical lengths of grade, in feet, by percent upgrade for design.</figcaption>
</figure>
<p>For further discussion of related design criteria and details, the designer is referred to Section E 020F (1b), Vertical Alignment.</p><p>In addition to the above basic controls for vertical alignment, there are several general controls that should be considered:</p><ol><li><span>Avoid the use of a series of short breaks to closely fit the existing terrain. It is desirable to adopt a smooth grade line with gradual grade changes that are consistent with the standards for the street classification under design</span><span> </span><span>consideration.</span></li><li><span>In rolling country, a street following a straight horizontal alignment with a profile</span><span> </span><span>that closely adheres to the existing natural ground line will usually produce a “roller coaster” effect or a &quot;hidden dip.” Oncoming vehicles occupying hidden dips contribute to passing maneuver collisions, since the driver attempting to pass may be deceived by the view of an open highway beyond the dip which appears free of approaching vehicles. To eliminate or reduce these dips and produce a smoother, more gradual change of grade, several alternatives are open:</span><ol><li><span>Sacrifice some of the straight alignment and introduce horizontal curvature in a direction to follow more closely the same</span><span> </span><span>elevation contour lines.</span></li><li>Where it is desired to maintain a straight alignment and where, consequently, the street is cutting across many contour lines, the use of higher fills and deeper cuts will tend to offset the degree of<span> </span>undulation.</li><li>Where circumstances dictate, use a combination of these first two<span> </span>alternatives.</li></ol></li><li>On undulating grade lines that include long lengths of momentum (downhill) grades, truck traffic tends to operate at a higher speed than on those profiles containing an upgrade but not preceded by a downgrade. In permitting an undulating grade, the designer should weigh the advantage of permitting trucks to increase their average speed on the upgrade against what may be the greater disadvantage of enabling trucks to reach excessive speeds, to the detriment of other traffic, on the downhill<span> </span>side.</li><li>For ae<span>sthetic reasons, a broken-back grade line (two vertical curves in the same direction connected by a short section of tangent grade) generally should be avoided, particularly in sags, where both vertical curves are in full view.</span></li><li>On long grades it may be preferable to place the steepest grades at the bottom and lighten the grades near the top of the ascent. It may also be more desirable to use, instead of a uniform sustained grade only slightly below the allowable maximum, an interspersion of short intervals of lighter and maximum grades. This is particularly true of<span> </span>low design.</li><li><span>Where intersections at grade occur on highway sections with moderate to steep grades, it is desirable to reduce the gradient through the</span><span> </span><span>intersection. The intersection may sometimes act as a control, in that the elevations contained therein are relatively fixed. In some cases, the intersection grade may be fattened by steepening the grade at some distance before reaching the intersection, and then flattening the approach to and through the intersection without appreciably affecting the intersection control elevations. This flattening effect makes for easier drainage control and vehicular turning</span><span> </span><span>movements.</span></li></ol></div>
      </div></div>
