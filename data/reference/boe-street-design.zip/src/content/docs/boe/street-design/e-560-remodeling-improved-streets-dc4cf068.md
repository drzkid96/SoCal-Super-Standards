---
title: "E 560 Remodeling Improved Streets"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-560-remodeling-improved-streets">Official BOE section</a></p>

<div><div>
        <div><p>Basically, a street may be reestablished (in whole or in part) by means of resurfacing the existing pavement section or reconstructing a new one. Resurfacing and reconstruction projects are generally limited to the pavement and gutter. Where it is necessary to raise or lower the flow line, the change is made only to an extent that permits the curbs to remain undisturbed. Where grades of R-percent or less are encountered, concrete gutters should be constructed as part of the project. The following material will serve as a guide to determine whether the project should be resurfaced, reconstructed, or both. It will also provide the basic design criteria that should be followed once the type of improvement is decided upon. See Figures E 660A, B, and C.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing typical resurfacing and reconstruction cross-sections for four scenarios" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20500%20Fig%20660A%20Typical%20Resurfacing%20and%20Reconstruction%20Cross-Sections.png?itok=MnA35z5O">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing typical resurfacing and reconstruction cross-sections for four scenarios</figcaption>
</figure>
<p> </p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Typical plan and sections for a partially remodeled street" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20500%20Fig%20660B%20Typical%20Plan%20and%20Sections%20for%20Partially%20Remodeled%20Street.png?itok=sSvfGdq2">



      </div>
          </div>

</div>

<figcaption>Typical plan and sections for a partially remodeled street</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Typical sections of improvements within abandoned railway right-of-way for partial reconstruction or total reconstruction of the roadway." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20500%20Fig%20660C%20Typical%20Sections%20Abandoned%20Railway%20ROW%20Improvements.png?itok=jZSHER_9">



      </div>
          </div>

</div>

<figcaption>Typical sections of improvements within abandoned railway right-of-way for partial reconstruction or total reconstruction of the roadway</figcaption>
</figure>
</div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-94bf3391/">E 561 Need For Remodeling Streets</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-0-60f803d8/">E 562 Resurfacing</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-1-0039be03/">E 563 Reconstruction</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-2-65770955/">E 564 Grade Determination (Street Resurfacing and Reconstruction)</a></li></ul>
