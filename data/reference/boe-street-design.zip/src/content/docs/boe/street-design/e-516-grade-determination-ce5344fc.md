---
title: "E 516 Grade Determination"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-516-grade-determination">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The grade determination of alleys differs from that of streets in several respects. One reason is that the maximum speed limit for alleys is generally 15 miles per hour. This speed is considerably lower than that of most streets and thus permits the lowering of design standards in several directions. For example, the sight distance and length of vertical curves rarely become a factor.  However, a length of less than 50 feet for either sight distances or vertical curves should not be used. Another important difference is that streets have a border area and provide a buffer zone between the street grade and adjacent existing private improvements. This space permits a certain latitude in establishing a street grade. The lack of a buffer area does not usually create a problem in establishing a pavement grade for alleys in new subdivisions or for existing alleys in which adjacent property is unimproved. However, it often creates design problems in existing alleys where the existing improvements abut the alley property line and pavement.  This difference between alley and street grade design criteria will become evident as the alley grade determination procedures are outlined.</p><h4>E 516.1 Grade Determination Procedure</h4><p>In discussing the procedure outlined for the alley grade determination of existing unimproved alleys with the adjacent property developed, several factors should be considered. For example, most of the existing alleys have had an official grade established but in some instances were never improved. Or it may be found that the curb returns, sidewalk, and pavement at the intersection of the alley and the street have been previously constructed.</p><p>It may be evident from a field inspection that some of the existing improvements abutting the alley were constructed without regard to the existing or future established alley grade. In any case, a complete set of field notes (survey) should be obtained. If the existing field notes are five years old or older, or if there is any reason to believe that existing conditions are sufficiently changed, new fieldwork should be ordered. This information is plotted, and the official grade superimposed on the existing profile and cross-sections to determine whether all, part, or none of the established grade should be used. Wherever possible, the official grade should be used joining those intersections that were previously constructed. If this requires excessive removals of existing abutting improvements or results in substandard design, establishing a new grade may be more practical.  Where the alley intersections have previously been constructed, it may be even more economical to remove all or part of these intersections and reconstruct them to the new grade.<a> Additional criteria for removals are covered in </a><a href="/SoCal-Super-Standards/boe/street-design/e-570-realignment-andor-widening-0-e6b27d9e/"><u>Section E 571, Interference of Existing Improvements</u></a>.</p><p>In the above discussion it was indicated that the designer’s prime concern is to meet existing improvements in existing alleys without sacrificing the City’s design standards. To meet these standards for the existing alleys, the following procedure for establishing the grades in new unimproved alleys with undeveloped abutting property should be adhered to as closely as possible.</p><p>Referring to Figure E 616.1A below, pick off or calculate the flow line elevations at the PI’s at both intersections from plotted profiles of the existing or proposed flow line grades of the intersecting streets. The PI refers to the point of intersection of the flow line of the street and the alley property line (PL) produced.</p><p>Next, add the height of the curb at the intersection (assumed to be 8 inches, or 0.67 foot) to each calculated flow line (FL) elevation.  This determines the theoretical top of curb (DC) elevation at the PI. Next, the product of the normal sidewalk slope (2 ½ percent) and the distance between the curb face (CF) on the street side and the street property line (border distance) is added to the theoretical TC elevation. This is the design elevation at the P.L. corner at the alley intersection.</p><p>To illustrate with an example, point C on Figure E 616.1A has a proposed flow line elevation at the PI of 100.00 feet.  By adding 8 inches (0.67 feet) to the flow line, the theoretical top of curb elevation is 100.67 feet. The product of the curb-to- property-line distance (10 feet) and the normal sidewalk slope (2½ percent) equals:</p><p>$10&#x27; \times \frac{2.5}{100} = 0.25&#x27;$</p><p>The theoretical top-of-curb elevation plus the above product equals:</p><p>100.67&#x27; + 0.25’ = 100.92&#x27; = Point F (Elev. at P.L.)</p><p>This same procedure is followed for setting the other three P.L. corner elevations.</p><p>The elevations at the property line corners and the alley flow line at point A should be adjusted to provide an elevation at Point A that is not more than 1 inch below the elevation of the theoretical top of curb at point D. The theoretical top of curb is determined by averaging the theoretical curb heights at points B and C.  The curb height at B and C are based on the prevailing existing or proposed curb of “X” Street immediately south and north of the alley intersection.</p><p>Where point A is more than 1 inch below the top of curb at point D and where points A, E, and F cannot be adjusted to raise the elevation of point A and meet existing conditions as well as meet the City’s design criteria, an investigation of the “X” Street drainage overflow should be made by the Storm Drain Design Division or the Storm Drain Section of the District. This overflow should be adequately handled by the alley and the intersecting “Y” Street. If the overflow cannot be handled it will be necessary to use subsurface drainage.</p><p>The elevations at both alley intersections having been established, the next step is to connect the northwest to the northeast property corner and the southwest to the southeast corner. In this procedure, the design that is produced must at least meet the minimum design criteria set forth in the following Subsections. In establishing alley intersection curb grades, refer also to Figure E 616.1B below.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing a typical plan of alley intersections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2026-07/e_500_fig_616.1a_typical_plan_of_alley_intersections.png?itok=ddse0WT_">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing a typical plan of alley intersections</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing various alley intersection layout types" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2026-07/e_500_fig_616.1b_alley_intersections.png?itok=8AJHPDma">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing a various alley intersection layout types</figcaption>
</figure>
<h4>E 516.11 Maximum and Minimum longitudinal Grades</h4><p>The design standards presented here are for use for all alley design. However, absolute minimum design standards are also submitted which may be used, at the discretion of the Division or District Engineer, to meet existing improvements abutting existing unimproved alleys.</p><h5>E 516.111 Maximum Grades</h5><p>The maximum allowable longitudinal grade permitted is 15 percent.  In steep hillside areas where the existing grades exceed the maximum allowable, the difference in elevation between both ends of the alley or section of the alley must be reduced. This should be done by grading, providing smooth vertical curves to connect sharp grade breaks, acceptable crossfall for the transverse sections, and adequate drainage.</p><h5>E 516.112 Minimum Grades</h5><p>An economic study should be made of alternate designs for alleys in flat areas. Consideration should be given to all the factors, such as removal and reconstruction costs, property damage, easements, and storm drain construction costs. The most economical method that provides adequate drainage should be chosen.</p><p>There should be sufficient difference in the prevailing elevations between both ends or flat sections of the alley to permit longitudinal drainage. The minimum rate of longitudinal grade permitted is 0.200 percent. In flat terrain where there is insufficient “fall” and where existing improvements prevent the development of this minimum grade, there are several methods by which drainage may be achieved.  Where necessary, these methods permit the longitudinal grades of the alley property lines to be reduced to 0.000 percent, provided a longitudinal gutter grade of at least 0.200 percent and a minimum V cross-section are achieved.</p><p>Probably the most economical method is to vary the depth of the alley V cross-section from a minimum V depth at the high end to a maximum V depth at the low end of the alley.  See <a href="/SoCal-Super-Standards/boe/street-design/e-517-alley-cross-2e070f5f/"><u>Section E 517, Alley Cross-Sections</u></a>  for maximum and minimum V’s. This variation in V depth will increase the rate of grade of the concrete gutter or concrete pavement flow line.  If this method does not provide the minimum grade and if the amount of available “fall” is limited by a small difference of elevations of the previously paved alley intersections, the intersection pavements, curb returns, and abutting sidewalks may have to be removed.  The intersections will then have to be redesigned to increase the elevation difference between both ends of the alley. When the intersections are raised or lowered, the property line grades approaching the intersections must be raised or lowered. This grade change may prevent meeting the abutting existing improvements. If meeting these improvements is critical, the method of only slightly lowering the original grade may have to be combined with the above method of varying the depth of the V cross- section.</p><p>Other suggested methods of getting at least a minimum grade for drainage are as follows: Referring to the typical profile of the proposed alley grades in areas of flat or level terrain in Figure E 616.112(A), below, a high point is created in the alley to permit drainage in both directions. The high point should be located at such an elevation and location that a minimum rate of grade of 0.200 percent is developed.  If water is draining from adjoining property into the alley, the location of the high point should not block this drainage.</p><p>If this method is not satisfactory, a sump is created and subsurface drainage provided, as shown on Figure E 616.112(B), below. The elevation of the pavement surface at the sump should be low enough to provide at least a minimum longitudinal grade of 0.200 percent. In locating the low point there are several important points to consider. Care should be taken to meet existing improvements to avoid undermining buildings, walls, etc. There should be a consultation with a representative of the Storm Drain Design Division or the Storm Drain Section of the District to ascertain the feasibility of making a connection from the proposed sump catch basin to an existing or a new storm drain facility.  This may include contact with adjoining property owners to determine their attitude toward the City’s acquisition of a storm drain easement through their property, should one be needed.</p><p>Referring to Figure E 616.112(C), below, another possibility is reversing the flow. This reversal is done by sloping the proposed grade connecting the two alley intersections in the opposite direction to the slope of the existing terrain. In existing alleys with abutting improvements, this method would be practical only if the cut or fill required to reverse the flow would not excessively damage existing improvements.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram of three types of typical alley profiles" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20616.112%20Typical%20Alley%20Profiles.png?itok=2JFgJoch">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram of three types of typical alley profiles</figcaption>
</figure>
<h5>E 516.12 Grades for Driveway Encroachments at Alley Intersections</h5><p>Where existing driveways or driveways to be constructed encroach in existing or proposed alley intersection curb returns, and where the driveway relocation is not feasible, the curb returns should be depressed to a 0-inch curb face.  A transition is provided from the 0-inch curb lace to a 1-inch curb face where the curb return merges into the driveway curb depression, assuming that the driveway curb depression has a 1-inch curb face. See Figure E 616.1B, Plate IV.</p><h5>E 516.13 Maximum Grade Breaks</h5><p>In alleys in new subdivisions, or in existing unimproved alleys abutting undeveloped property, the maximum grade breaks should be 1 ½ percent with a minimum distance of 10 feet between elevations.  In order to meet existing conditions in unimproved alleys with abutting improved property, the maximum grade break permitted is 2 ½ percent.  The minimum distance between breaks is 5 feet.</p></div>
      </div></div>
