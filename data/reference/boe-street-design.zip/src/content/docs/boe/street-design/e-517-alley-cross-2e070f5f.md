---
title: "E 517 Alley Cross-Sections"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-517-alley-cross">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The criteria used for the design of geometric and structural cross-sections will be treated in the following subsections. Reference is also made to Streets Dimension Standard Plan (<a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf"><u>Standards S-470-1</u></a>)<a>; </a><a href="/SoCal-Super-Standards/boe/street-design/e-631-structural-types-and-uses-0d882f00/#:~:text=E%C2%A0631.1%20Permanent%20Curbs"><u>E 631.1, Permanent Curbs</u></a><a>;  E 616.1A; and E 616.1B.</a></p><h4>E 517.1 Alley Construction</h4><p>Figure 617.1, below, shows the standard geometric cross-section to be used for alley construction. Figure E 617A shows the standard transverse slopes, the maximum and minimum slopes, and the absolute maximum slopes used to form the V section for various widths of alleys under different conditions. These slopes are measured from the centerline of the gutter to the outer edges of the pavement at each property line.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing a standard alley cross-section" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20500%20Fig%20617.1%20Standard%20Alley%20Cross-Section.png?itok=OpwfJHrs">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing a standard alley cross-section</figcaption>
</figure>
<p>In general, it is desirable to have the property lines level with each other and to use a standard V of 0.25 foot. The tabulations furnished on Figure E 617A and the sections on Figure E 617B are to serve as a guide. Where circumstances dictate other criteria to be used, the minimum V may have to be increased and the maximum V decreased.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table of design criteria for &quot;V&quot; alley sections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20617A%20Table%20of%20Design%20Criteria%20for%20V%20Alley%20Sections.png?itok=8DpX72au">



      </div>
          </div>

</div>

<figcaption>Table of design criteria for &quot;V&quot; alley sections</figcaption>
</figure>
<p> </p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram of typical alley cross-sections in areas with excessive crossfall" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20617B%20Typical%20Alley%20Cross-Sections%20in%20Areas%20with%20Exc%20Crossfalls.png?itok=yRx4t2AJ">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram of typical alley cross-sections in areas with excessive crossfall</figcaption>
</figure>
<p>Often, it will be found that this standard alley cross-section is not flexible enough to be used under all conditions. For example, the design of an existing unimproved alley with abutting improvements on a sidehill location is often characterized by a lopsided V section because of the large amount of crossfall that is introduced. It may be found that the modified cross-sections shown in Figure E 617B are more adaptable to this type of design. These modified cross-sections may be used either throughout the entire alley length or only at critical areas.</p><p>Before determining which section is applicable, consideration must be given to the amount of crossfall, drainage control, and grading; the need for alley access from abutting property; and the construction costs.  For example, Figure E 617A shows, for an AC paved alley of 15 feet or less with a gutter offset of more than 5 feet, a minimum V depth of 0.17 foot. The Storm Drain Design Division or the Storm Drain Section of the District should be consulted for a specific location to see whether this minimum V is adequate to handle the anticipated drainage.  Also, since some of the adjacent property may or may not be improved, and since it is not always apparent where access may be required, contact with the property owners in the preliminary design stage is strongly recommended.  When the Division or District Engineer has been apprised of the circumstances requiring the use of sections, particularly those which may deny access, and has given his approval, these sections or any other suitable sections may be used.</p><p>These modified sections permit the development in the design of greater amounts of crossfall than the standard section and thus reduce the grading quantities involved and help meet existing improvements. In introducing large amounts of crossfall into the design, it may be necessary, in order not to exceed the maximum transverse slopes, to offset the gutter as shown on Figure E 617B, Plates II through VI. However, in offsetting the gutter, the water-carrying capacity of the alley is materially reduced, due to the elevation of the pavement at the lower property line in relation to the gutter centerline elevation. To increase the capacity, the lower property line elevation is compensated for by increasing the required minimum V depth as shown in the tabulation on Figure E 617A.</p><p>The sections on Figure E 617B<a> </a>show a curb or retaining wall used on the high side to reduce the amount of crossfall where vehicular access is not needed. A curb height of 4 to 6 inches is used where pedestrian access may be required. Concrete retaining walls may also be used on the low side both to reduce the crossfall and to increase the water-carrying capacity.  Asphalt concrete berm is used on Plate V on the low side, with a maximum height of 0.50 foot to warp to join existing abutting pavement, sidewalk, driveways, etc. See Section E 618. A minimum height of AC berm of 0.33 foot is required to provide a minimum water-carrying capacity.</p><p>In narrow alleys paved with concrete, the outer edges of the concrete should not be warped as much as in the case of alleys paved with asphalt.  Therefore, since greater flexibility is required to meet existing improvements, a greater percentage of cross-slope may be used. In addition, in narrow alleys 15 feet or less in width, the effective width of the alley is usually reduced owing to the placement or utility poles, encroaching fences, walls, structures, etc. Therefore, it is assumed that two vehicles would not attempt to pass each other simultaneously. However, in alleys more than 15 feet in width, the tops of two vehicles could make contact in attempting to pass. This is because each vehicle is tilted toward the other because of the cross-slope of each side of the alley section. This accounts for the greater percentage of cross-slope permitted (if needed) in narrow alleys.</p><p>It is also presumed that alleys more than 20 feet wide are constructed in industrial areas and are subject to use by maximum height vehicles. These vehicles may attempt passing maneuvers in the alley. Because of the greater encroachment of the vehicular paths of maximum-height vehicles, the maximum permitted percentage of cross-slope is further reduced.</p><h5>517.11 Warped Alley Sections</h5><p>Where deemed necessary by the designer, or when requested by the property owner whose property is affected, the alley surface may be warped to meet existing pavement, such as parking lots, driveways, house entrances, etc. The alley surface warping is done in the area where the existing pavement on private property is 6 inches or less above the alley pavement grade. The warped surface may not extend more than 18 inches into the alley. When existing pavement does not immediately abut the alley or is higher than 6 inches above the alley grade, and where the property owner does not wish to grant a right of entry for work to be done on private property, the alley pavement is not warped.</p><p>When alleys paved with concrete require warping to meet existing abutting pavement, the concrete may be warped up to a maximum of 0.2 foot.  Asphalt concrete pavement is superimposed on the concrete where the warp is more than 0.2 foot. The reason the concrete should not be warped more fully is that the asphalt concrete, being temporary, can be more readily removed if the existing abutting pavement need no longer be joined. Joining abutting pavement becomes unnecessary where, due to deterioration, obsolescence, etc., older buildings and abutting paving surfaces are likely to be removed within a short time after the completion of the alley improvement. Experience has shown that removing abutting improvements and leaving an exposed permanent excess warp is undesirable and may also be hazardous.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing different types of typical warped alley cross-sections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20617.11%20Warped%20Alley%20Section.png?itok=C8Hkxz2f">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing different types of typical warped alley cross-sections</figcaption>
</figure>
<p>Figure E 617.11, Plate I, shows a typical warped alley cross-section. In the example shown, it is assumed that at the vicinity where the alley pavement is to join the existing improvements, the alley grade was raised as high as possible, and a smooth longitudinal grade provided without impairing the longitudinal drainage.  In addition, a 10-percent maximum transverse slope is used for the V section. However, the proposed alley pavement at the property line remains below the level of the abutting pavement. Since the difference in elevation is 6 inches or less, the alley pavement may be warped as shown on the right side of the section.</p><p>Where the existing abutting pavement is higher than 6 inches above the alley pavement, or where the pavement is close to but does not abut the alley, as is shown on the left side of the section, work is required on private property. (If the property owner so desires, the work may be done by following the procedures outlined in Subsection E 054.22A, Right of Entry, and in Chapter E 800, Procedural Steps for Proposed Improvement, for acquisition of a right of entry to construct pavement.)<sup>1</sup>  All or part of the existing pavement may have to be removed and a smooth grade to the join provided.</p><p>A warped alley section 6 inches in height and extending laterally 18 inches into the alley can prove a substantial obstacle to a moving vehicle. Figure E 617.11, Plate II, is an elevation view and shows a transitional section provided for the purpose of lessening the effects of vehicular impact. The transition section should be a minimum of 1.5 feet in length for a 6-inch warped alley surface, or 5 feet minimum for berms, curbs, and retaining walls from 6 inches to 18 inches high.  A transition for walls above this height is unnecessary, as it is reasonable to assume that higher walls would be readily seen and avoided by drivers. If the alley warp is less than 6 inches, the transitional length may be proportionately less.</p><p>Figure E 617.11, Plate III, is a plan view showing the transitional section connecting the normal alley section to the fully warped alley section.</p><h5>E 517.12 Longitudinal Gutter Offsets from Alley Centerline</h5><p>The centerline of the longitudinal gutter should normally be located on the alley centerline. As previously indicated, to keep the V slopes within the prescribed limits and to aid in meeting existing excessive crossfall, it may be necessary to offset the longitudinal gutter from the alley centerline. In addition, since the gutters normally carry the dry weather flow, the gutters may be offset for ease of access and for keeping dry during maintenance or servicing in manholes located in alleys.</p><p>If only a short section of gutter requires off-setting because of a local crossfall condition or a manhole, a gutter transition should be provided. The offset position is maintained for the minimum length necessary to accommodate the crossfall or bypass the manhole. Referring to Figure E 617.12, below, the gutter is then either transitioned back to the centerline as shown on Plate A, or if there is justification (such as additional manholes) for continuing the offset, it may be done as on Plate B.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Plan views of longitudinal gutter transition from alley centerline to offset gutter line" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-08/E%20500%20Fig%20617.12%20Plan%20Views%20of%20Longitudinal%20Gutter%20Transition.png?itok=wS_HoMa8">



      </div>
          </div>

</div>

<figcaption>Plan views of longitudinal gutter transition from alley centerline to offset gutter line</figcaption>
</figure>
<p>In determining the amount of offset to use, consideration should be given to the construction problems that may be created by a gutter offset too close to the property line. The smallest width roller for pavement compaction is 3 feet.  If the width of asphalt concrete between the outer edge of gutter and the inner edge of header board is less than 3 feet, the construction contractor may be forced to use manual instead of mechanical compaction. This is expensive and not an efficient operation. Generally, the minimum distance that should be used for mechanical rolling is 4 feet. This means that the 2-foot-wide longitudinal gutter, in a 20-foot-wide alley, should have a maximum offset distance from the gutter centerline to the alley centerline of 5 feet. The desirable transition length of longitudinal gutter to be used, where the gutter is offset from the alley centerline, is 15 feet.</p><h5>E 517.13 Gutter Arrangements at Alley Intersections</h5><p>Referring to Figure E 517.13, the flow of one alley (if directed toward another alley) is generally elected by means of connecting one gutter to the other. To facilitate flow at intersections of alleys with streets, and to reduce gutter overflow at the gutter connections of two alleys, the intersecting gutter should be angled-off in the direction of the flow of the intersected gutter (where the intersected gutter has a relatively steep grade). Usually, if an intersecting alley is draining away from an intersected alley, no gutter connection is needed.</p><h5>E 517.14 Concrete Fillets at Alley Gutter Intersections</h5><p>The use of concrete fillets as shown on <a>Figure E 617.14, Plates I and II</a>, is advocated for the following reasons:</p><ol><li>They eliminate sharp-angled corners and the problem of mechanically rolling and compacting asphalt concrete in these corners.</li><li>They prevent the cracking and unraveling of the asphalt concrete pavement that tend to occur in these corners because of water overflow from the concrete gutters.</li><li>They reduce overall maintenance costs by lessening the shock to, and deterioration of, concrete gutter resulting from repeated vehicular impact.</li></ol><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Two types of plan views of concrete fillets at alley gutter intersections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20617.14%20Concrete%20Fillets%20at%20Alley%20Gutter%20Intersections.png?itok=hoCv_5VE">



      </div>
          </div>

</div>

<figcaption>Two types of plan views of concrete fillets at alley gutter intersections</figcaption>
</figure>
<h4>E 517.2 Structural</h4><p>The basic pavement thicknesses and the supporting materials for the paving of streets and alleys have been discussed in <a href="/SoCal-Super-Standards/boe/street-design/e-622-pavement-design-structural-9e4ac08c/"><u>Section E 622, Pavement Design (Structural)</u></a>.</p><p>Alleys paved with asphalt concrete pavement and 10 percent in grade should either use the thick-lift construction process or have the pavement rolled in two separate courses of equal thickness.</p><hr><p>Footnote</p><ol><li>This content is obsolete. Team is conducting research to identify the current equivalent reference or information.</li></ol></div>
      </div></div>
