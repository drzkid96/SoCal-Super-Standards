---
title: "E 653 Parkways"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-650-borders-3f146405/">E 650 Borders</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-650-borders/e-653-parkways">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The parkway is the unpaved area between the sidewalk and the curb. This acts as a buffer space between pedestrian and vehicular traffic. In many cases, parkway areas provide space for the installation of surface and subsurface utilities.<span>  </span>A minimum border width of 9 feet is necessary where the division or district engineer requires installation of trees and tree wells in the parkway.</p><p>In substandard width rights of way or on some hillside streets, the space allotted to sidewalk and pavement may limit the width of the parkway to less than 30 inches (2.5 feet) between curb face and front of walk. Under these circumstances the parkway should be paved to provide a continuous sidewalk between the curb and the property line. A parkway should always be graded or paved so that it lies in a plane between the sidewalk and the curb.</p></div>
      </div></div>
