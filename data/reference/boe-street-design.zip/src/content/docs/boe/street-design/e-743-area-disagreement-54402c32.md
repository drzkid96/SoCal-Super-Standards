---
title: "E 743 Area of Disagreement"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection/e-743-area-disagreement">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>If there is an area of disagreement between the engineer and the inspector during the final joint inspection, the engineer must immediately notify his supervisor either while in the field or upon his return to the office. The engineer in charge, without delay, will either reconcile the dispute or report the disagreement to the responsible Deputy City Engineer. In no case will any differences between the engineer and the inspector be discussed in the presence of the contractor or others who may not be acting on behalf of the City’s interest.</p></div>
      </div></div>
