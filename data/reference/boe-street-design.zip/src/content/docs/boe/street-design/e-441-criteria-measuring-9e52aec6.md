---
title: "E 441 Criteria for Measuring"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-440-sight-distance-488456e6/">E 440 Sight Distance</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-440-sight-distance/e-441-criteria-measuring">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Sight distance along the street and highway is measured from the driver’s eye to an object on the traveled way when it first comes into view. Measurement criteria for safe stopping sight distance are different from those for safe passing sight distance. Sight distance controlled by vertical alignment involves different elements than sight distance controlled by horizontal alignment. The height of the driver’s eye is assumed to be 3.75 feet above the pavement surface.</p><p>On crest vertical curves, sight distance is limited by some point on the pavement surface. The height of the object used to measure safe stopping sight distance on crests is 0.50 foot. The height of object for passing sight distance which represents the height of an oncoming vehicle in the opposing lane in a passing maneuver is 4.0 feet.</p><p>The average height of a truck driver’s eye above the pavement is 6 feet. On sag vertical curves where sight distance is limited by an overcrossing and where a sufficient percentage of trucks are using the highway (no percentage figures available), this additional height should be considered for design purposes. See <a href="/SoCal-Super-Standards/boe/street-design/e-442-safe-stopping-distances-0dd10e1d/#:~:text=E%20442.2%20Headlight%20Sight%20Distance%20on%20Sag%20Vertical%20Curves">Subsection E 442.2</a>. The height of the object is assumed as two feet above the pavement (representing the height of the taillight of a forward-moving vehicle).</p><p>For safe stopping distance on horizontal curves, the following height criteria are generally used at the midpoint of the sight line where the cut slope or obstruction usually interferes with sight: 3.75 feet for height of eye, 6 inches for height of object, and 2 feet for height above the pavement at the centerline of the inside lane radially opposite the point of obstruction. See Figure E 342.4A.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Figure featuring the illustrative diagram of sight distance in street design and graph of sight distance along clear distance from curb line and safe speed." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342.4A%20Non-Passing%20Sight%20Distance%20on%20Horizontal%20Curves_Crop.png?itok=LXfx2HXT">



      </div>
          </div>

</div>

<figcaption>Figure featuring the illustrative diagram of sight distance in street design and graph of sight distance along clear distance from curb line and safe speed.</figcaption>
</figure>
</div>
      </div></div>
