---
title: "E 741 Areas Of Inspection Jurisdiction"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection/e-741-areas-inspection-jurisdiction">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The design engineer should be aware of the extent to which the City has jurisdiction on final inspections of various types of projects. This section covers these areas of jurisdiction.</p><h3>E 741.1 Between the City and Other Agencies</h3><p>City facilities may be constructed under State or County contract. Conversely, State and County facilities may be constructed under City contract. Work for another agency is usually performed under its specifications and is usually reviewed by its own representative at the time of final inspection. The City design engineer should therefore be concerned only with those public works facilities that will be owned and/or maintained by the City.</p><h3>E 741.2 Between Bureaus</h3><p>Although the areas of inspection between the Bureaus of Engineering and Contract Administration may overlap to some small degree, the differences are outlined below.</p><h4>E 741.21 Bureau of Contract Administration</h4><p>The Bureau is limited to matters involving only construction operations, procedures, finished appearance, correctness of construction, and adequacy of clean-up.</p><h4>E 741.22 Bureau of Engineering</h4><p>The Bureau of Engineering is responsible for determining the adequacy of the construction regarding geometric design standards. This includes grades, sidewalk, slope, cross-gutter depressions, gutter hike-up, curvature, pavement elevations, etc.</p></div>
      </div></div>
