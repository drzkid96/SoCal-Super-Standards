---
title: "E 383 Local Street Intersecting Local Street"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-5bf4ef05/">E 380 Intersection Grades Controlled by Street Classification</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-380-intersection-grades-controlled-street-2">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>More consideration should be given to grades for local collectors than for non-collector streets.</p></div>
      </div></div>
