---
title: "E 360 Other Elements Affecting Geometric Design"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-360-other-elements-affecting-geometric-design">Official BOE section</a></p>

<div><div>
        <div><p>There are many other factors affecting or controlling the geometric design in addition to the basic elements previously covered.<span>  </span><a>Generally, in rural areas, the topography controls, and in City streets, meeting existing conditions is a more important consideration</a>. Other items that generally affect City street design are:</p><ol><li><p>Economic and Social Conditions: Available finances; new developments; redevelopment of blighted areas; safety, comfort, and convenience; greater accessibility; etc.</p></li><li><p>Terminal Facilities: Off-street parking, bus and railway terminals, freight terminals, airports, etc.</p></li><li><p>Public Transit Facilities: The design and arrangement of transit and pedestrian facilities, accommodation of the type of transit vehicle and spacing of stops, etc.</p></li><li><p>Traffic Operations During Construction: Temporary connections or detours are sometimes necessary during construction to maintain uninterrupted traffic flow; some locations may dictate the particular design of a temporary bypass as well as the main project.</p></li><li><p>Access Control — the use of cul-de-sacs: Frontage roads, alleys, etc., can affect the design as well as the street pattern.</p></li><li><p>Drainage: The location of sumps and drainage facilities can modify or alter street design.</p></li></ol><p>The designer has little or no control over some of these factors and more control over others. Therefore, only some of these factors, where the exercise of some degree of control is possible at the design level, will be dismissed.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-361-d1c67cc4/">E 361 Safety Features and Collision Data (Accident Records)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-362-88999c2f/">E 362 Access Control</a></li></ul>
