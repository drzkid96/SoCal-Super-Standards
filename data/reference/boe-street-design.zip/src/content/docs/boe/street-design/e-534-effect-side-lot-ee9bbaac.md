---
title: "E 534 Effect Of Side Lot Lines On Driveways"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-530-driveways-3a58bf38/">E 530 Driveways</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-530-driveways/e-534-effect-side-lot">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Except for side slopes, no portion of a driveway approach should extend in front of an adjoining lot without the consent of the owner of the lot. For exceptions, see <a href="/SoCal-Super-Standards/boe/street-design/e-532-prohibited-0d652c75/"><u>Section E </u><ins><span><u>532</u></span></ins><u>, Prohibited Locations For Driveway Approaches</u></a>. For this purpose, the division between two lots should be a line which is perpendicular or radial to the curb and passes through the intersection of the common lot line and the street property line, regardless of the angular relationship between these lines.</p><p>All driveways should be constructed at right angles to the curb. When the curb line is curved, the driveway should be constructed on a line radial to the curb.</p></div>
      </div></div>
