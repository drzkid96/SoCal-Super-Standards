---
title: "E 622 Pavement Design (Structural)"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-620-pavements-24c951c8/">E 620 Pavements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-620-pavements/e-622-pavement-design-structural">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Modern roadways are surfaced with two types of pavements: rigid and flexible. Criteria for the design and use of these two types of pavements are present in the following discussion.</p><h3>E 622.1 Flexible Pavements</h3><p>These pavements have sufficiently low bending resistance to maintain intimate contact with the underlying structure yet have sufficient stability to support the traffic. Examples include all bituminous types not supported by a rigid foundation.</p><h4>E 622.11 Flexible Pavement Design</h4><p>The R-value method of flexible pavement design presented here is substantially the same as that used by the State of California Division of Highways. This is not an attempt to explain the theory behind the method, but instruction in how to use it. The R-value method considers three variables to arrive at the thickness of the structural section:</p><ol><li>Traffic</li><li>Resistance value of the soil (R-value)</li><li>Slab strength (gravel equivalent factor).</li></ol><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Structural Design Chart for Flexible Pavements" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2025-09/E%20600%20Fig%20422.115B%20Structural%20Design%20Chart%20for%20Flexible%20Pavements_0.png?itok=37ooOCOC">



      </div>
          </div>

</div>

<figcaption>Structural Design Chart for Flexible Pavements</figcaption>
</figure>
<p>Figure E 422.115B enables the engineer to arrive at a total equivalent thickness of gravel (G.E.) to support the design traffic load over the soil in question.  The gravel equivalent factor enables the engineer to reduce the total thickness of gravel by replacing it with other materials in the structural section. The following discussion and examples illustrate the use of Figures E 422.114 and E 422.115B for arriving at a structural section.</p><h5>E 622.111 Traffic Evaluation</h5><p>For pavement design purposes, the traffic load is expressed as the traffic index (T.I.). For streets classified as major and secondary highways, and for some select system streets, the traffic index to be used for design is determined from Figure E 422.115A.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="20-Year Conversion Chart Average Daily Traffic to Traffic Index" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2025-09/E%20600%20Fig%20422.115A%2020-Year%20Conversion%20Chart%20Average%20Daily%20Traffic%20to%20Traffic%20Index_0.png?itok=olT88nSb">



      </div>
          </div>

</div>

<figcaption>20-Year Conversion Chart Average Daily Traffic to Traffic Index</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table of traffic index values estimates according to type of facility" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-10/E%20600%20Fig%20422.111%20Traffic%20Index%20by%20Street%20Type.PNG?itok=uNH0qkHx">



      </div>
          </div>

</div>

<figcaption>Table of traffic index values estimates according to type of facility</figcaption>
</figure>
<p>When estimating the average daily traffic (ADT) for the given design file, the present ADT is increased to account for increasing traffic volumes. The percentage of trucks, which may also be expected to change, can be determined from manual counts. The Department of Transportation provides traffic counts on most secondary and major highways. Several streets for which traffic counts are available also have manual counts from which the percentage of trucks and busses can be determined.</p><p>For local streets and alleys, the traffic index will be estimated according to the type of facility. See Figure E 422.111.</p><p>The engineer must use judgment in estimating the traffic index for streets in industrial and manufacturing areas. These streets may carry light traffic volumes but may have a large percentage of trucks. The heavier loads are many times more destructive than the lighter loads on a residential street and may damage the pavement in a relatively short time.</p><h5>E 622.112 Soil Evaluation</h5><p>The resistance value (R-value) of the soil is a measure of the soil’s ability to resist lateral deformation when subjected to a vertical load.  Measurement of the R-value is made with the soil sample at full moisture saturation. The testing procedure also considers some soils to be expansive. The R-value should be used for flexible pavement design.</p><p>If the results of past soil tests on adjacent projects indicate that the soil properties (Atterberg Limits, clay content, and R-value) are uniform over the area in question, the soil properties for the proposed project can be estimated to have the same resistance value as that of the adjoining projects.  The engineer should use judgment in estimating the R-value. When this value cannot be estimated tests should be requested from the Bureau of Standards. The traffic index should be predetermined and sent with the request, because the T.I. is used to compute the R-value when the soil is expansive. To simplify the computation and provide an added safety factor for the expansive R-value, the Bureau of Standards will use a gravel equivalent factor (G.F.) of 2.0. </p><p>For a full explanation of the R-value test, see Section E 020F(5e), Test Method No. Calif 301.</p><h5>E 622.113 Required Soil Information</h5><p>When the R-value cannot be estimated, the designer should obtain the following soil test information:</p><ol><li>Atterberg Limits (liquid limit, plastic limit, and plasticity index)</li><li>Mechanical and hydrometer analysis (clay content)</li><li>Resistance value.</li></ol><p>The above information should be retained in a central file and used for estimating the R-values of future projects in the area.</p><h5>E 622.114 Slab Strength</h5><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table summarizing gravel equivalent values assigned to various materials" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-10/E%20600%20Fig%20422.114%20Gravel%20Equivalent%20Factor%20Table%20.PNG?itok=7UqWiAtp">



      </div>
          </div>

</div>

<figcaption>Table summarizing gravel equivalent values assigned to various materials</figcaption>
</figure>
<p>The term strength means the tensile strength or cohesion of the elements of a pavement section. This strength gives the pavement section the ability to act as a slab, which serves both to reduce the pressure on the subgrade through beam action and to restrain the upward movement of the soil around the loaded area.</p><p>The effect of slab action is accounted for by the gravel equivalent factor (GB.). The gravel equivalent factor for asphalt concrete is 2.0. Each inch of AC is therefore equivalent to 2 inches of gravel. The gravel equivalent values have been assigned to the various materials and are tabulated in Figure E 422.114.</p><p>Any thickness of material above can be converted to an equivalent thickness of gravel (O.E.) by using the gravel equivalent factor or the material in question. For example:</p><p>Thickness of cement-treated base in inches x G.F. = G.E.</p><p>6” x 1.5 = 9” G.E.</p><p>where G.F. = Gravel equivalent factor</p><p>G.E. = Equivalent thickness of gravel</p><h5>E 622.115 Structural Section Design Examples</h5><p>Problem A: Design the structural section for Main Street between the Santa Monica Freeway and Washington Boulevard</p><p>Traffic Evaluation:</p><ul><li>Given: Manual traffic count m 15,000 ADT, 10% trucks, design service life = 20 years.</li><li>Solution: Use Figure E 422.115A and following values: 25,000 ADT (estimated 10-year increase) and 10% trucks.</li><li>Read: T.I. = 10.</li><li>Soil Evaluation: From soil tests, R = 35.</li></ul><p>Design:</p><ul><li>Determine the gravel equivalent. Use Figure E 422.115B and the above values: T.I.= 10, R = 35.</li><li>Read: G.E. = 25” total.</li><li>Assume it is desired to place 8” AC on CAB.</li><li>The CAB gravel factor = 1.1.</li><li>The CAB required is:</li></ul><p>$\frac{G. E. \left(total\right) - G. E. \left(AC\right)}{G. F. \left(CAB\right)} = CAB$ in inches</p><p>$\frac{25&quot; - 16&quot;}{1.1} = 8.18&quot;$ (use 8&quot;)</p><ul><li>Design section = 8” AC on 8” CAB</li></ul><p>Many situations allow comparison of several structural sections, each of which meets design criteria. The cost of each alternative should be considered for availability of materials, future maintenance, and other special conditions which may exist for the project.</p><p>Some alternate sections for the above design problem are:</p><ul><li>8” AC on 6” cement-treated base</li><li>8” AC on 9” select natural material</li><li>12” AC with no base.</li></ul><p>Problem B: Design the structural section for 53rd Street between Central Avenue and Avalon Boulevard.</p><p><u>Traffic Evaluation:</u></p><p><em>Given:</em> 53rd Street is a residential collector. </p><p><em>Solution:</em> From Figure E 422.111, T.I. = 5.</p><ul><li>Soil Evaluation: Tests adjacent to the project show that R = 42.</li><li>The soil in this area has been found, from previous testing, to be uniform. Therefore, assume for design purposes that R = 40.</li></ul><p>Use Figure E 422.115B and the above values:</p><p>T.I. = 5, R = 40.</p><ul><li>Read: G.E. = 12” total.</li></ul><p>Assume the use of asphalt concrete with no base.</p><ul><li>AC in inches <span>= $\frac{G.E.}{G.F.}=\frac{12}{2}=6&quot;$  </span>(no base required).</li></ul><p>An alternate section would be 4&quot; AC on 4” select natural material.</p><h4>E 622.116 Recommended Standard Practice</h4><ol><li>Minimum thickness of AC:</li></ol><ul><li>Secondary and major highways and commercial alleys: 6”</li><li>Traffic Index: &gt; 9 – 8”</li><li>Industrial and manufacturing areas: 8”</li><li>Residential streets and alleys: 4”</li></ul><ol start="2"><li>Crushed miscellaneous material is the highest untreated base material to be required for any project.  Minimum thickness when used: 4”</li><li>Alleys less than 15 feet in width should be paved with portland cement concrete. This is because of inadequate clearance for the equipment used to compact AC.</li></ol><h3>E 622.2 Rigid Pavement Design</h3><p>Rigid pavements are composed of portland cement or any other type of pavement laid on a portland cement concrete base. Because of their high bending resistance, rigid pavements can distribute loads over a comparatively large area of the foundation soil.</p><p>Where the soils are relatively non-plastic, concrete pavement may be deposited directly on the foundation soil and result in a minimum of bridging effect.  Where the soil is plastic, select material base should be applied to act as a buffer between the rigid pavement and the flexible supporting soil.  This will effectuate a reduction in pavement bridging and excessive pavement pumping action and will minimize pavement cracking.</p><h4>E 622.21 Where Concrete Pavement Is Used</h4><p>There are certain cases in which portland cement concrete is used in City streets:</p><ol><li>Where the petitioners in a proposed assessment act project specifically request concrete pavement.</li><li>Where existing concrete pavement is removed and replaced.</li><li>In streets and alleys with a rate of grade exceeding 30 percent.</li><li>In alleys less than 15 feet in width. (This is because of inadequate clearance for the mechanical equipment used to compact asphalt concrete. The AC must be hand-tamped around utility poles, fences, etc. Hand-tamping is a slow process and. increases the labor costs.) The use of AC or PCC pavement is optional with alleys 15 feet or wider.</li></ol><p>A careful economic study and comparison should be made in each situation to determine whether the use of rigid rather than nonrigid pavements is justified.  Particular attention should be paid to the possibility of future utility installations or maintenance requirements which would necessitate removal of the pavement.</p><h5>E 622.22 Concrete Pavement Thickness</h5><p>The minimum thickness of concrete pavement to be used in roadways is 6 inches. This thickness would normally be sufficient for major and secondary highways of medium traffic loads – equivalent wheel load (EWL) of 6-8 million.  The use of concrete pavement 8 inches thick should be considered for major and secondary highways or heavy traffic loads — EWL of 8 million and over —and in areas zones for heavy industry and subject to heavy traffic loadings. The maximum thickness of concrete pavement is 9 inches.</p><h5>E 622.23 Concrete Pavement Removal</h5><p>Removal and reconstruction of concrete pavement is expensive and should be avoided as much as possible. However, any existing improvements should be removed to a reasonable extent to provide a smooth, neat appearing join section.</p><p>When concrete pavement is removed, the removal should be extended to the nearest joint so that no small “floating islands” of concrete remain.</p></div>
      </div></div>
