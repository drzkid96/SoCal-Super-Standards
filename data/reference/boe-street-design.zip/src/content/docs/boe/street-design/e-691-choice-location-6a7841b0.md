---
title: "E 691 Choice of Location and Type"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-690-traffic-guides-and-barrier-installations-692a0ee6/">E 690 Traffic Guides and Barrier Installations</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-690-traffic-guides-and-barrier-installations/e-691-choice-location">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>When considering these danger areas and other elements, such as high vehicular speed and poor visibility, the more dangerous points along a highway are obvious from the construction plans. From these factors, the type of devices to be used, as well as their location, length, offset, and spacing, can be readily determined. However, the overall need for these installations is best decided by field inspection, since certain hazardous areas may not be evident until the grading nears completion. Installation should be made before the highway is opened to traffic.</p><p>The choice of type of installation required is largely a matter of the hazard involved. For example, guard rails are designed to resist impact by deflecting a vehicle so that it continues to move relatively parallel to the guard rail at reduced velocity. However, a vehicle may be deflected onto adjacent lanes into the path of vehicles moving in the same direction.<span> </span>Moreover, any abrupt stop of a vehicle is dangerous, and a guidepost or a projection on a guard rail which might snag a moving vehicle is undesirable. A sudden stop may be more hazardous than driving down a slope.</p><p>Generally, the need for these protective or warning devices is directly related to the steepness of downhill side slopes. For this reason, they may be omitted where it is practical to provide fill slopes of 4 to 1 or flatter. They should not be omitted where the terrain continues to drop away from the toe of fill even though the slope is 4 to 1 or flatter. Headwalls, interceptor drainage channels, trees, or other objects that may be present on slopes also represent a possible traffic hazard. Basically, wherever there is a potentially hazardous situation, even with flat slopes, guard or warning device installation is usually justified.</p><h3>E 691.1 Uses</h3><p>Guideposts, sight posts, and guide markers are primarily used to delineate the roadside direction at sections where many drivers might become confused. Although these appurtenances are not expected to resist impact, the heavy guideposts may prevent slow-moving vehicles from leaving the roadway.</p><p>When guard rail is used in hazardous locations, heavy guideposts or heavy sight posts, spaced to permit vehicular access to adjacent property, are substituted for a portion of the guard rail. At points where driving off the road is not highly dangerous, less heavy guide and sight posts and guide markers may be used, so that little damage will be done if they are struck.</p><p>Guard rails or guiding devices should be located at a constant horizontal offset from the edge of the pavement. This fixed distance serves as a guide to the driver as to the distance to the edge of the lane or road when visibility is limited. They should be located back from the shoulder line and set at about the same elevation. It is desirable to flare the rail outward for a short distance on the traffic approach end to lessen possible direct end impact and to provide a full view to the driver. Usually, only the outside of the horizontal curves need be outlined by guideposts or other warning devices.</p><p>There is no fixed spacing to be used between posts of the guide or sight markers. However, the more hazardous the situation, the closer the spacing of the guide installations should be.</p><p>Reference is made to Figures E 490(1), (2), and (3), and to Figure E 491.1. These figures illustrate some of the typical applications for these devices and provide standards or guides for their installation.</p><h3>E 691.2 Placement</h3><p>Figure E 490(1), Plate I, shows where guard rail may be omitted on the tangent portion of the horizontal alignment of a normal street section. Plate II shows traffic barriers and warning rails used as protection of pedestrian and vehicular traffic against hazardous hillside conditions. Chain link fence should be used where only pedestrian traffic requires protection. It should also be used adjacent to or in the vicinity of schools, playgrounds, parks, etc.</p><p>Where one or more of the minimum slope distance criteria as shown in Figure E 490(2), Plate III, cannot be met, guard rail is required.<span>  </span>Where the back edge of the guard post is less than 1-foot from the top of the fill slope, a longer post must be used. This post must be provided with a minimum depth of cover of 2-feet 2.5 inches. This cover is measured at a depth where a level line of at least 1 foot of width extends from the back of the post and intercepts the slope, as shown in Figure E 490(2), Plate IV.</p><p>Figure E 490(3), Plate V, shows a cul-de-sac terminating at the top of a ridge or steep fill.<span> </span>Plate VI shows a street with a sharp horizontal curve. Plates VII, VIII, and IX show a dead end, an abrupt alignment change, and a sudden narrowing of the roadway, respectively.</p><p>The placement of these guard or guide devices with respect to the offset from the street centerline, or the X and Y distances from the BC and the EC respectively, and the most probable path of a vehicle as shown on these plates, require the determination of roadway widths, vehicle speed, abruptness of alignment changes, visibility, etc., and the consideration of these factors for each individual case.</p><p>In conclusion, use of the metal-beam guard rail with metal posts is suggested for new installations, although the metal-plate and metal-beam type with wooden posts may be acceptable. Generally, the metal-plate type should be used only to replace portions of existing metal-plate guard rail. It is preferable to use metal installations, since wooden barriers and guideposts, such as laminated wooden guard rail or standard wooden warning rail, are not as effective or as durable. The types of installations shown in the City’s Standard Plans or any other type acceptable to the City Engineer may be used. The treatment of any situation not covered by these figures or the City’s Standard Plans, or any deviations from these standards, should be approved by the design office.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing typical installations of traffic guides and warning devices" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-1%20Typical%20Installations%20of%20Traffic%20Guides%20and%20Warning%20Devices_0.png?itok=2xZuQmDm">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing typical installations of traffic guides and warning devices</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing typical installations of traffic guides and warning devices where guard rail is required" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-2%20Typical%20Installations%20of%20Guard%20Rails_0.png?itok=9YBBZxvE">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing typical installations of traffic guides and warning devices where guard rail is required</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing typical installations of traffic guides and warning devices where metal guard rails are required" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-3%20Plan%20View%20of%20Typical%20Installations%20of%20Metal%20Guard%20Rails_0.png?itok=NjXbnsi8">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing typical installations of traffic guides and warning devices where metal guard rails are required</figcaption>
</figure>
<p></p></div>
      </div></div>
