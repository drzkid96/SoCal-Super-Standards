---
title: "E 665 Grade Determination of Medians"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-660-medians-17bb4fe7/">E 660 Medians</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-660-medians/e-665-grade-determination-medians">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Since painted medians are painted directly on the finished surface of the pavement, they are not included in the discussion that follows.</p><p>After the length, width, and other design considerations are determined for the median strip, the curb grade should be established.<span>  </span>Although the same basic principles apply here for any curb grade design, there are certain other factors not usually considered in curb design that are considered in median curb design. Refer to <a href="/SoCal-Super-Standards/boe/street-design/e-560-remodeling-improved-streets-dc4cf068/"><u>Section E 560, Remodeling Improved Streets</u></a>. For example, where it is intended to superimpose the curb directly on the existing or proposed pavement, a study is made of the finished surface pavement grades. If these grades are smooth and satisfactory in all respects, the median curb will probably also be satisfactory.</p><p>When an unpaved section of street, such as an abandoned railroad right of way, or a part of the existing street must be remodeled or resurfaced, the median curb grade design used must fit the existing street conditions. It is sometimes necessary to adjust the median curb grade or the street grade or both to achieve a balanced design would be reached by obtaining a satisfactory median curb grade with a minimum adjustment and remodeling of existing street conditions. See <a href="/SoCal-Super-Standards/boe/street-design/e-560-remodeling-improved-streets-dc4cf068/"><u>Section E 560, Remodeling Improved Streets</u></a>.</p><p>Median curb grades are affected in cases where the highway is divided into separate roadways. The separate roadways permit relatively independent grade design in relation to each other. The median curb grades provide a transition between the grades of the two roadways.  Figure E 465 shows how the design of the median acting as a road divider is gradually transitioned so that as the intersection is approached, the two roadways merge into one section of roadway.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams of highway cross-sections showing crossfall and superelevation" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20465%20Cross-Sections%20showing%20crossfall%20and%20superelevation.png?itok=hnUAl15R">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams of highway cross-sections showing crossfall and superelevation</figcaption>
</figure>
</div>
      </div></div>
