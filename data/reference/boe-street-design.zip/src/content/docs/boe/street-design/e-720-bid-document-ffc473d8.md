---
title: "E 720 Bid Document"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-700-new-project-construction-7cd75283/">E 700 New Project Construction</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-720-bid-document">Official BOE section</a></p>

<div><div>
        <div><p>The bid document is the official advertising literature used for bidding purposes. This includes the notice inviting bids and the bid proposal.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-721-bid-proposal-45a88666/">E 721 Bid Proposal</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-722-contract-documents-d1c4f94e/">E 722 Contract Documents</a></li></ul>
