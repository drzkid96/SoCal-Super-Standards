---
title: "E 237 Requests for Immediate Financing"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-230-street-improvement-policies-348b87cd/">E 230 Street Improvement Policies</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-230-street-improvement-policies/e-237-requests">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p><span>Capital Improvement Project Requests for streets and transportation facilities should normally be referred to the Street/Transportation Projects Oversight Committee (</span><a>Technical Committee for Capital Programming)<sup>1</sup></a><span>. A project request may</span>be considered for immediate financing solely on its own merits under one or more of the following circumstances:</p><ol><li>The project is partially financed or otherwise previously authorized.</li><li>There is an agreement, commitment, or coordination required with other agencies or projects.</li><li>City financing is recommended in accordance with established policies or practices (such as City contributions to assessment projects, assistance to religions institutions, etc.).</li><li>There are contemplated substantial cost savings.</li><li>The project is relatively small (currently under $5,000) or nature that is not normally considered in the capital program.</li><li>The project is of an emergency nature involving:<ol><li>The protection of life or health,</li><li>The provision of safety measures, or</li><li>The prevention of property damage.</li></ol></li></ol><hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and is no longer in use.</li></ol></div>
      </div></div>
