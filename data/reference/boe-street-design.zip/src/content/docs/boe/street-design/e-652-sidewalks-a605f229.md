---
title: "E 652 Sidewalks"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-650-borders-3f146405/">E 650 Borders</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-650-borders/e-652-sidewalks">Official BOE section</a> · City revision July 27, 2026</p>

<div><div>
        <div><p>The term sidewalk applies to the portion of the pavement reserved for pedestrian use. A sidewalk is generally aligned parallel to the property line and the roadway. The other pavement reserved for pedestrians is generally perpendicular to the sidewalk. Those portions of pavement traversing the parkway area and providing access to the abutting property or located on private property have been referred to as walks, crosswalks, or housewalks. To differentiate between these terms, reference is made to Figure E 452. <em>Pedestrian walkway or inner block walk</em> is the term used to describe the inner block pedestrian walkways. <em>Crosswalk</em> is the term used to describe the roadway area used by pedestrians crossing the street. <em>Housewalk</em> is the term used to describe the pavement reserved for pedestrians and generally aligned perpendicular to the sidewalk.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing the plan view of pedestrian rights-of-way with labels for nomenclature" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20452%20Nomenclature%20for%20Pedestrian%20Rights%20of%20Way_Crop.png?itok=8AtVnEup">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing the plan view of pedestrian rights-of-way with labels for nomenclature</figcaption>
</figure>
<h3>E 652.1 Locations</h3><p>The location of sidewalks is shown on the <span><span>Streets Dimension Standard Plan </span></span><span>(</span><a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard S-470-1</a><span>)</span>. Sidewalks should also be provided on culverts in City street easements and on bridges, including those over open channels and over canyons. However, sidewalks should not be constructed unless a curb grade has been approved and the curb is constructed either prior to or concurrently with the sidewalk.</p><p>In new subdivisions, sidewalks should be constructed so that the back of the sidewalk abuts the property line. Where existing improvements such as walls, buildings, etc., abut the property line or encroach within the right of way, it may be practical to remove these obstructions. In these cases, it may be necessary to offset the back of sidewalk one-half foot or one foot from the property line.</p><p>Large volumes of pedestrian traffic may be anticipated in commercially zoned areas or near schools, etc. In these cases, the parkway should be eliminated, and sidewalk should be constructed across the entire width of border.</p><p>Some suggested treatments of sidewalk in which the border widths, corner cutoffs, and back-of-sidewalk offsets from property line may vary because of any of the above existing conditions are illustrated in Figure E 451B.</p><p>At the discretion of the district or division engineer, sidewalk may be omitted in the following cases:</p><ol><li>In industrial areas zoned M-3 or less, in which full-width pavement between property lines is proposed.</li><li><p>In existing right of way where the terrain or existing improvements make sidewalk construction economically unfeasible.</p><p> </p></li></ol><h3><span>E 652.2 Widths</span></h3><p>The width of sidewalk that is used in conjunction with the various street classifications is illustrated on the <span><span>Streets Dimension Standard Plan (</span></span><a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf"><span><span>Standard Plan S-470-1</span></span></a><span><span>)</span></span>. The width of the sidewalk is always measured from the top of curb face. Therefore, in making estimates of sidewalk quantities, where the entire border area is paved with sidewalk or where the sidewalk abuts the curb, the one-half foot of width for the top of curb is deducted.</p><p>The curb return radius should be adjusted or a property line cutoff should be provided at intersections where there is less than a 5-foot width of sidewalk between the property and the face of curb. See Figure E 451B.</p><p>In existing right of way with existing sidewalk, any proposed sidewalk should be constructed to match the width of the existing sidewalk. When joining the sidewalk that is abutting the property line, it may be necessary to acquire a right of entry to construct the proposed sidewalk. If this is not readily attainable, the back of sidewalk may have to be offset one-half foot from the property line to avoid encroachment on private property during construction.</p><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Sidewalk Alignment at Intersections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2026-05/sidewalk-alignment-at-intersections.png?itok=IcxCviXz">



      </div>
          </div>

</div>
<p> </p><h3><span>E 652.3 Types of Materials, Thickness, and Construction Practices</span></h3><p>Sidewalks should be constructed using the materials and to the thickness specified in Standard Plan <a href="https://apps.engineering.lacity.gov/archive/techdocs/stdplans/s-400/S-444-1_SIDEWALKS.pdf">S-444-1</a>. For sidewalk construction practices, refer to the <a href="https://www.bnibooks.com/products/2021-greenbook-standard-specifications-for-public-works-construction#:~:text=First%20published%20in%201967%2C%20Standard,used%20by%20local%20public%20agencies.">2021 Greenbook: Standard Specifications for Public Works Construction (2021 Greenbook)</a> and the <a href="https://apps.engineering.lacity.gov/brownbook/frame.cfm">City of Los Angeles Department of Public Works Additions and Amendments to the 2021 Edition of the Standard Specifications for Public Works Construction (Brown Book, 8th Edition)</a>.</p><h3>E 652.4 Sidewalk Design</h3><p>One of the design considerations is to enable a plane to be formed by the top of curb, the transverse slope of the parkway, the sidewalk, and the surface at the property line. However, establishing this plane relationship between the property line and the curb is not always possible in hillside areas. The transverse slope, which is normally set at 2.5 percent, should direct drainage from the property line toward the roadway. The maximum transverse sidewalk slope permitted is 6 percent and the minimum is 1 percent. The maximum longitudinal grade change permitted for sidewalk slopes is 6 percent.</p><p>Usually, if the curb grade has been properly established, the sidewalk design will fall within the foregoing prescribed design limits. However, sidewalk design problems may arise where private improvements which either encroach to the right of way or are located on private property and abut the right of way have been constructed after the establishment of the curb grade. If, in constructing these private improvements, little regard has been given to their relationship to the official curb grade, it may not be possible to provide a smooth join between the proposed sidewalk and the existing improvements. The designer must then decide whether to remove all or part of the private improvements or to change the curb grade and possibly the pavement grade.</p><p>In other situations, there may be existing trees which may interfere with the sidewalk construction. In this case the designer should consult with the personnel of the Urban Canopy Division of the Bureau of Street Services. This Division will estimate the probability of tree survival following partial root or limb removal. In some cases, it may decide that the tree should be completely removed.</p><p>If the grading of side slopes is also involved, it may be expedient to check with the personnel of the Bureau of Standards as to the stability of the side slopes. Other related situations are covered under <a href="/SoCal-Super-Standards/boe/street-design/e-535-driveway-design-1403b041/"><u>Section E 535, Driveway Design</u></a>; <a href="/SoCal-Super-Standards/boe/street-design/e-570-realignment-andor-widening-f2211fb1/"><u>Section E 570, Realignment and/or Widening of Improved Streets</u></a>; and other sections of this Part of the Manual.</p><p>The design investigation should include the plotting of a sufficient length of the existing sidewalk profile and alignment beyond the point where it is joined by the proposed sidewalk profile and alignment. This plot will enable the designer to eliminate any abrupt angle points that may be due to changes in horizontal alignment, sidewalk widths, or grades.</p><p>When the removal of sidewalk is contemplated, the field observations should include existing sidewalk conditions, probable limits or sidewalk removal, and location of nearest scoring line beyond the sidewalk removal limit.<span>  </span>Whenever it is practical to do so, the sidewalk should be removed to the nearest scoring line.</p><h4><span>E 652.5</span><span> </span><span>Sidewalk Design at Intersections</span></h4><p>After a curb return grade has been established, a profile of the proposed sidewalk should be plotted. Normally, the sidewalk grade closely follows the curb grade. Only a short portion of the front and back of the intersecting sidewalks need be plotted. A smooth line should result when the profiles are plotted through the front and back sidewalk points of intersections (PI’s) and extended to the points at which they intersect the top of the curb. In large intersections with extensive sidewalk area, plotting one or two radial sections to check for smooth grades is justifiable. Only in unusual circumstances should the curb return grade be adjusted instead of the sidewalk grade.</p><p><span>A similar procedure is followed where an existing curb return requires replacing by a new curb return. If there is any significant difference in grade between the two returns, all, or part of the existing sidewalk within and at the vicinity of the </span><span>intersection may have to</span><span> </span><span>be removed and replaced. T</span><span>he amount of sidewalk to be removed can be determined by plotting various test profile lines of the existing sidewalk. The proposed curb grade is then superimposed at the points where the existing sidewalk profile intersects the new curb. Enough of the existing sidewalk is removed to permit construction of a new sidewalk with a smooth grade, and to connect the remaining existing sidewalk and the top of the new curb grade.</span></p><hr><p>Footnote</p><p><sup>1</sup>The text in parenthesis is from the legacy Street Design Manual text and has been superseded by the text that follows.</p></div>
      </div></div>
