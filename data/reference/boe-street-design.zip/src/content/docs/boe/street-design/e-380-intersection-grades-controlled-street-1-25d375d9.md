---
title: "E 382 Major Highway Intersecting Local Street"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-5bf4ef05/">E 380 Intersection Grades Controlled by Street Classification</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-380-intersection-grades-controlled-street-1">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The grades should favor the major highway, giving less consideration to the local street. Cross-gutters are permitted only across local streets. </p></div>
      </div></div>
