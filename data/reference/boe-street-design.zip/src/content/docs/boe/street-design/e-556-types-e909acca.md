---
title: "E 556 Types Of Intersections"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">E 550 Intersections At-Grade</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-550-intersections-grade/e-556-types">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The basic types of intersections at grade are “T”, “Y”, 4-leg, multileg, and rotary. The rotary intersection is not commonly used in the City and the design principles involved will not be discussed in this Part of the Manual.</p><p>Any one basic intersection type can vary greatly in scope, shape, and degree of channelization. Once the type is established, it is a matter of applying the design techniques and criteria to arrive at a suitable geometric design for intersections. The types and some of the variations of each type are discussed in this section and are shown on Figure E 656.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram general types of at-grade intersections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20500%20Fig%20656%20General%20Types%20of%20At-Grade%20Intersections.png?itok=hxBb8h5T">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram general types of at-grade intersections</figcaption>
</figure>
<p> </p></div>
      </div></div>
