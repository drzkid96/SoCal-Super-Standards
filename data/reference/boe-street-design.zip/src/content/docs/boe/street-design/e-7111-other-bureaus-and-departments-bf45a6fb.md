---
title: "E 711.1 Other Bureaus and Departments indirectly Involved"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-710-construction-control-e2fc0ac6/">E 710 Construction Control</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-710-construction-control/e-7111-other-bureaus-and-departments">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><div><div><div id="_com_1"><p>Some City bureaus and departments act primarily as advisers to the engineer on matters pertaining to their specialties, thus being indirectly involved in the construction of street projects. These bureaus and departments are:<span></span></p><ol><li>(Bureau of Assessments (for City awarded contracts only).)<sup>1</sup></li><li>Bureau of Sanitation.</li><li>Bureau of Street Services.</li><li>(Bureau of Right of Way and Land.)<sup>1</sup></li><li>Bureau of Street Lighting</li><li>Department of Transportation</li></ol><p>However, the latter two make the necessary changes for their own facilities affected by the project construction.<br>When Street Lighting work is included in the City Engineer’s plans, the Bureau of Street Lighting will prepare the necessary change orders in coordination with the appropriate District or Division Engineer. <br>In as much as the Department of Traffic is not under the Board of Public Works that Department must request the City Engineer to issue the necessary change orders and will furnish any necessary sketches describing the work.</p><hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and is no longer in use.</li></ol><p><br></p></div></div></div></div>
      </div></div>
