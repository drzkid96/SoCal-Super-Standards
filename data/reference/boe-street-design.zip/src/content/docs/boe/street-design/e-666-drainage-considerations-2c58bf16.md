---
title: "E 666 Drainage Considerations"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-660-medians-17bb4fe7/">E 660 Medians</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-660-medians/e-666-drainage-considerations">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Construction of a curbed median on streets having a high rate of superelevation or crossfall will result in the interception by the median of the transverse drainage due to the storm water or gutter overflow. Disposition must also be made of dry-weather flow from the irrigation of landscaped medians. See <a href="/SoCal-Super-Standards/boe/street-design/e-667-cross-section-curbed-median-69bb173c/#:~:text=asphalt%20concrete%20pavement.-,E%20667.3%20Landscaping,-The%20following%20criteria"><u>Subsection E 667.3, Landscaping</u></a>. To dispose of this water, concrete gutters are constructed abutting the median curb. The median gutter should be designed with adequate longitudinal grade, so that the flow continues to a point of surface or subsurface disposal. Although a 1-foot-wide gutter is normally used, a considerable flow of water may require a 2-foot-wide gutter.</p><p>The method of drainage disposal used is usually dictated by the availability of drainage facilities. When none of these facilities are available, the engineer may have to resort to intersection cross-gutters. However, although intersection cross-gutters are permitted on local streets, they are not to be used on major or secondary highways. Since most medians are constructed on major or secondary highways, the water generated in these cases should be handled by providing subsurface drainage disposal. If subsurface drainage is not available or economically feasible, items such as irrigated landscaping should be postponed until a storm drain system is installed.</p><p>Figure E 466 shows four typical street cross-sections with curbed medians. These sections show how the transverse median gutter section<span> </span>should be tilted, based on a given situation.</p><p>“A” shows a level cross-section with no dry- weather flow. Since there is no water to confine, the transverse slope of the median gutter is constructed in the place of the crown section.</p><p>&quot;B” shows a level cross-section with irrigated landscaping that receives dry-weather flow. The median gutter is tilted up to the standard gutter hike-up, so that the dry-weather flow entering the median gutter is confined as it flows longitudinally.</p><p>“C” shows a tilted section with no dry-weather flow. The median gutter is constructed in the plane of the crown section for the same reasons as for Section A. </p><p>“D” shows a tilted cross-section with dry-weather flow. The slope of the median gutter has a standard hike-up on both sides of the median.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing various types of street cross-sections with curbed medians" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-10/E%20600%20Fig%20466%20Street%20Cross-sections%20with%20curbed%20medians.png?itok=76vJhgXG">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing various types of street cross-sections with curbed medians</figcaption>
</figure>
<p></p></div>
      </div></div>
