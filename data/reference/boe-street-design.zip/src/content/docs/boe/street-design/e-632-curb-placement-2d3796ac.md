---
title: "E 632 Curb Placement"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-630-curbs-and-gutters-19d35d20/">E 630 Curbs and Gutters</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-630-curbs-and-gutters/e-632-curb-placement">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The placement of curbs can generally be determined from the <span>Streets Dimension Standard Plan (</span><a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a><span>).</span> There are other considerations, however, such as clearances between the curb face and the face of an abutment, a pier, a column, or other <span>obstruction</span>. Refer<span> to </span><a href="/SoCal-Super-Standards/boe/street-design/e-320-design-vehicle-physical-characteristics-and-1-c058a34c/"><span><u>Section E 322, Clearances</u></span></a><span>.</span></p><p>Curb should be offset 2 feet from edge of through traffic lanes. The 2-foot gutter width as normally constructed may constitute the 2-foot curb offset. <span> </span>In special cases in which the available street width is limited, it is permissible to include the gutter width as part of the usable traffic lane width.</p><p>Generally, curb positioning should provide the same unobstructed roadway width at intersections, median openings, and undercrossings or overcrossings. See <a href="/SoCal-Super-Standards/boe/street-design/e-556-types-e909acca/"><u>Section E 556, Types of Intersections</u></a>.</p><p>In setting the alignment for curbs, adequate clearance should be provided to prevent encroachment of the back of curb into private<span> </span>property.</p></div>
      </div></div>
