---
title: "E 554 Signalized Intersection Capacity Data"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">E 550 Intersections At-Grade</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-550-intersections-grade/e-554">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div>
<p>All the factors as stated in <a href="/SoCal-Super-Standards/boe/street-design/e-553-c8e60f05/"><u>Section E 553,  Factors Affecting Intersection Capacity</u></a> are also used in determining signalized intersection capacity. Much of this data is supplied by the Department of Transportation. <span> </span>Various charts and tables supplied by previously mentioned public agencies are also included in this section to enable estimates to be made, under varying conditions, of the signalized intersection capacity.</p><p></p><h4>E 554.1 Levels of Service</h4><p></p><p>Figure E 554.1A, below, shows levels of service as related to load factor for individual, isolated intersection approaches. <span> </span>The load factors ranging from 0.0 to 1.0 as shown on the curves of the basic data in Figures E 554.IB(l) and (2), Plates I and H, and E 554.IC and (2), Plates I and II, are indicative of levels of service. The load factor is a ratio of the number of green signal intervals that are fully utilized by traffic during the peak hour to the total number of green intervals for that approach during the same period. For intersection conditions, Highway Capacity Manual considers the load factor as an appropriate measure of the levels of service, since the loading is something the driver sees and interprets in terms of degree of congestion. See Section E 020F(4a).</p><p></p><p><span>A level of service B-load factor of not more than 0.1 is considered in the Highway Capacity Manual to be suitable for the design of intersections under typical rural conditions. A level of service C-load factor of not more than 0.3 is normally recommended for design of intersections in urban areas. A level of service E with operation at a load factor of 0.85 is taken to be representative of possible capacity.</span><span> </span><span> </span>Although a factor of 1.0 may sometimes be approached, a lesser factor such as 0.85 generally indicates the maximum loadings that can be achieved repetitively and sustained over a period of one hour.</p><p></p><p><strong><u>LEVELS OF SERVICE</u></strong></p><p></p><div><table><thead><tr><th scope="col"><p><strong>Level of Service</strong></p><p></p></th><th scope="col"><p><strong>Traffic Flow Description</strong></p><p></p></th><th scope="col"><p><strong>Load Factor</strong></p><p></p></th></tr></thead><tbody><tr><td><p>A</p><p></p></td><td><p>Free flow</p><p></p></td><td><p>0.0</p><p></p></td></tr><tr><td><p>B</p><p></p></td><td><p>Stable flow</p><p></p></td><td><p>≤ 0.1</p><p></p></td></tr><tr><td><p>C</p><p></p></td><td><p>Stable flow</p><p></p></td><td><p>≤ 0.3</p><p></p></td></tr><tr><td><p>D</p><p></p></td><td><p>Approaching unstable flow</p><p></p></td><td><p><span> </span>≤ 0.7</p><p></p></td></tr><tr><td><p>E</p><p></p></td><td><p>Unstable flow — capacity</p><p></p></td><td><p>≤ 1.0</p><p></p></td></tr><tr><td><p>F</p><p></p></td><td><p>Forced flow</p><p></p></td><td><p> </p></td></tr></tbody></table></div><p><span><strong>Figure E 654.1A</strong></span></p><p></p><h4>E 554.2 Factor f for Conversion of Design Capacity to Possible Capacity</h4><p></p><p>Using the load factors as stated in Subsection E 554.1 for rural intersections and for different street types, the relationship between design capacity and possible capacity is summarized in Figure E 654.2, below. The values shown are the ratios of attainable volumes per hour of green (average conditions) at 0.3-load factor (0.1 for rural conditions) to the attainable volumes at 0.85-load factor.<span>  </span>Therefore, design capacity can be converted directly to possible capacity by multiplying design capacity by the appropriate factor in the figure below.</p><p></p><p><span><img alt="A black and white paper with numbers and text

Description automatically generated"></span></p><p></p><h4>E 554.3 Factor f for Adjustment to Various Levels of Service</h4><p></p><p>Although Figures E 654.1A, E 654.1B, E 654.1C, and E 654.2 are based on design capacity (service level C for urban conditions and service level B for rural conditions), conversion to any other level of service can be achieved using the factors shown in Figure E 654.3, Plates I and II.<span>  </span>Thus, the figures may be used with equal facility to find design capacity and possible capacity in accordance with AASHO’s practice, or to find the maximum service volumes for any level of service (A to E), in accordance with the Highway Capacity Manual procedure.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph showing the load factors to determine intersection approach service volume for 2-way streets" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20500%20Fig%20654.1B%281%29%20Intersection%20Approach%20Service%20Volume.png?itok=A7QSffsy">



      </div>
          </div>

</div>

<figcaption>Graph showing the load factors to determine intersection approach service volume for 2-way streets</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph of load factors to help determine intersection approach service volume on 1-way streets" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20500%20Fig%20654.1C%281%29%20Intersection%20Approach%20Service%20Volumes.png?itok=d0bse5RI">



      </div>
          </div>

</div>

<figcaption>Graph of load factors to help determine intersection approach service volume on 1-way streets</figcaption>
</figure>
<div><div><div id="_com_2"><p></p><p></p></div></div><p></p></div>
</div>
      </div></div>
