---
title: "E 391 Design Details"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-390-grade-design-policy-d14643a0/">E 390 Grade Design Policy</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-390-grade-design-policy/e-391-design-details">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>To present the specific design details for determining the grade for City streets, the street is divided into three separate areas: </p><ol><li>Between Intersections,</li><li>Approaching Intersections, and</li><li>Within Intersections.</li></ol><h4><a>E 391.1 Between Intersections:</a></h4><p>Because of all the complex factors involved, grades are usually developed on a trial-and-error basis. Curb grades should be established to direct drainage toward the street from the abutting property. The top of curb is then used as a reference in establishing the pavement grades. Wherever possible, the roadway should be designed with a level cross-section and a uniform crown. Normal crown should be maintained on all through streets. The curb grades should be laid in straight lines between intersections. Where straight grades are not practical, a reasonable balance should be maintained between meeting existing improvements, design standards, and construction costs.</p><p>The existing terrain or improvements may be such that the design of a street grade would entail the use of a grade less than the minimum permitted.  To avoid using this flat grade, it may be desirable to create a sump. The grades approaching the sump would then be designed to exceed the minimum grade or at least equal it. A storm drain system must be available to use this method. An alternative method would be to create a high point at some strategic location and design the street grades setting the high point so that a grade results that equals or exceeds the minimum grade.</p><h5>E391.11 Rate of Grade (longitudinal):</h5><p>In developing a longitudinal grade there is no desirable rate of grade that should be used. However, grades of 6 percent or less are preferable. </p><h6>E 391.111 Maximum:</h6><p>The maximum desirable grade for major or secondary streets is 6 percent, with 7 percent being the absolute maximum. All other streets have a normal maximum limit of 15 percent. See <a href="/SoCal-Super-Standards/boe/street-design/e-421-basic-grade-controls-3592058e/#:~:text=E%20421.1%20Maximum%20Grades">Subsection E 421.1, Maximum Grades.</a></p><h6>E 392.112 Minimum:</h6><p>The minimum desirable rate of grade is 0.400 percent. Where unavoidable, a rate of grade of 0.200 percent may be used. When using flat grades, concrete gutter should be used. See <a href="/SoCal-Super-Standards/boe/street-design/e-421-basic-grade-controls-3592058e/#:~:text=E%20421.2%20Minimum%20Grades">Subsection E 421.2, Minimum Grades</a>.</p><h5>E 391.12 Grade Breaks:</h5><p>The maximum grade break permitted between two adjoining chords varies with the location and circumstances.</p><h6>E 391.121 Rate Differences:</h6><p>Connecting chords that have a grade difference of more than 1.25 percent on local streets and 0.50 percent on <a>major and secondary highways</a> should be replaced with vertical curves. <a>Vertical curve calculations are shown in </a>Section <a href="/SoCal-Super-Standards/boe/street-design/e-422-vertical-curves-b3cbff29/">E 422, Vertical Curves</a><a>.</a></p><h6>E 391.122 Spacing:</h6><p>Grade breaks on vertical curves will normally be spaced at about 25-foot intervals on flat grades and about 10-foot intervals on steeper grades. The minimum spacing permitted is 5 feet. Use of the 5-foot minimum spacing may be unavoidable in some existing alleys. There is no maximum spacing.  However, due to conditions that generally prevail in existing streets, the spacing between elevations will rarely exceed 100 feet.</p><h5>E 391.13 Crossfall (Traverse Slopes)</h5><p>The crossfall in a street is the difference in elevation between the two sides of the street. Street cross-sections should be held level on major or secondary highways and should not exceed 1.50 percent on other streets. Where it is necessary to meet existing improvements on existing streets in hillside areas, a maximum crossfall of 8 percent-near be permitted.</p><p>The rate of crossfall is calculated by determining the difference in elevation at each end of a transverse section. The transverse section used should be normal to the curbs on tangent street sections or radial on curved street sections. To obtain the percentage of crossfall, this difference in elevation (usually between the outer edges of gutter) is divided by the horizontal distance between elevations and the resulting quotient is then multiplied by 100.</p><h4><a>E 391.2 Approaching Intersections:</a></h4><p>Where relatively level (transverse direction) streets in hillside areas intersect streets having a steep longitudinal grade, as the proposed level street approaches the intersection, crossfall, or cross slope, must be developed to meet the grade of the intersecting street.</p><h5>E 391.21 Crossfall</h5><p>This may be affected by providing a smooth transition of gradually increasing crossfall starting at 75 feet from the BCR. See Figure E 531.3.</p><p>Approximately two-thirds of the grade of the intersecting street is set at the BCR.  The maximum crossfall at this point should not exceed 10 percent.  The crossfall is then permitted to increase beyond the BCR until the intersection is reached, where the remaining one-third of the grade of the intersecting street is developed.</p><h4><a>E 391.3 Within Intersections</a></h4><p>After preliminary grades are set, the theoretical curb grades are extended on smooth lines across all intersecting streets. Crown sections are reduced at the approach to the intersection where transitions are required to meet the cross-gutters or depressed flow lines. The specific details are shown on <a>Figure E 531.3</a>.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing specific details of intersection design criteria" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20300%20Fig%20531.3%20Intersection%20Design%20Criteria.png?itok=sOglH_PL">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing specific details of intersection design criteria</figcaption>
</figure>
<h5>E 391.31 Grade Breaks</h5><p>On major and secondary highways, the desirable maximum grade break permitted within an intersection is the same as between intersections (50 percent). For local street intersections, T intersections, or local streets where permanent stop signs are installed, the desirable maximum is 3.50 percent, and the absolute maximum is 6 percent. See Figures E 531.3 and E 531.31A and B. However, use of the 5-foot minimum spacing may be unavoidable in some existing street intersections. See Figure E 531.3.</p><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing the plan view and gutter and flow line profiles of intersection grades at local street " src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20300%20Fig%20531.31A%20Intersection%20at%20Local%20Streets.png?itok=zn1BqkxG">



      </div>
          </div>

</div>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing the plan view and gutter and flow line profiles of intersection grades for local streets with extremely flat grades" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20300%20Fig%20531.31B%20Intersection%20at%20Local%20Streets%20.png?itok=wx2RmocQ">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing the plan view and gutter and flow line profiles of intersection grades for local streets with extremely flat grades</figcaption>
</figure>
<h6>E 391.311 Around Curb Returns</h6><p>A vertical curve should be used around a curb return where practical. The maximum grade change permitted per grade break is 3 percent.</p><h5>E 391.32 Rideovers</h5><p>To reduce the longitudinal grade break across intersections to provide a smoother riding line, rideovers are used.<a> </a>See various sections on Figures <a>E 531.3; E 441.33A, Street Plan; and E 441.33B, Work Sheet Profile and Cross-Sections (Showing Non-intersecting Cross-Gutter).</a></p><p>A rideover is generally used where there is no surface drainage across the intersection. However, rideovers can also be used in connection with existing or proposed cross-gutters, provided these are adequate fall across an intersection. The rideover profile on the west side of “A” Street on <a>Figure E 531.3 </a>represents the flow line profile of the cross-gutter. This profile indicates that although a vertical curve (rideover) has been introduced into the cross-gutter flow line, drainage can take place across the intersection.</p><h5>E 391.33 Drainage</h5><p>Surface drainage is not normally permitted across intersections on major or secondary highways. Surface drainage across intersections of local streets, although not desirable, is permitted.  However, cross-gutters must be provided, using the standards for construction indicated on Figures E 431.1, Types of Curbs and Gutter, and E 441.32, Low Flow Channels for Cross-Gutters. Since catch basins are not permitted within the curb return area, the policy is to design the gutter so that any sumps that will be created are located outside the curb return.  Due to the variation of grades approaching intersections, various drainage patterns are created, as indicated by the direction of the drainage arrows shown on Figure E 531.33.</p></div>
      </div></div>
