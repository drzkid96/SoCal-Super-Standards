---
title: "E 740 Final Inspection"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-700-new-project-construction-7cd75283/">E 700 New Project Construction</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection">Official BOE section</a></p>

<div><div>
        <div><p>Upon completion of their work, the contractor calls for a final inspection. For City contracts, the Bureau of Contract Administration schedules the final inspection and notifies all parties involved. The inspection party jointly reviews the work in the field and if all agree that the work is satisfactory, the City accepts the work. When all other requirements are met, the contractor is paid; the bonds are released; and the contract is fulfilled.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-741-areas-inspection-jurisdiction-f8c41eef/">E 741 Areas Of Inspection Jurisdiction</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-742-joint-inspection-148e52ba/">E 742 Joint Inspection</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-743-area-disagreement-54402c32/">E 743 Area of Disagreement</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-744-changes-prior-final-acceptance-b3ff5e27/">E 744 Changes Prior To Final Acceptance</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-745-final-acceptance-857f0710/">E 745 Final Acceptance</a></li></ul>
