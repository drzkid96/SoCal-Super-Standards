---
title: "E 130 Abbreviations"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-100-introduction-and-general-information-2be36ad5/">E 100 Introduction and General Information</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information/e-130-abbreviations">Official BOE section</a></p>

<div><div>
        <div><p>The standard abbreviations commonly used by the Bureau of Engineering are listed in the Standard Specifications and in Standard Plan S-610. A list of those used in this Part of the Manual, but not given in the Standard Specifications or S-610, follows. The list is in three parts: abbreviations of one or more words; abbreviations of the owners of utility pipes, conduits, rails, and rights of way; and abbreviations of active company appurtenances.</p><p>Since these abbreviations are not given in the &quot;Standard Specifications for Public Works Construction,&quot; or Standard Plan S-610, whenever these abbreviations are used on a set of plans, they must be defined on THAT set of plans.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-131-terms-or-words-04d557b5/">E 131 Terms or Words</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-132-owners-utility-pipes-conduits-1f2be0e7/">E 132 Owners Of Utility Pipes, Conduits, Rails And Rights Of Way</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-133-active-company-appurtenances-e0e5bd42/">E 133 Active Company Appurtenances</a></li></ul>
