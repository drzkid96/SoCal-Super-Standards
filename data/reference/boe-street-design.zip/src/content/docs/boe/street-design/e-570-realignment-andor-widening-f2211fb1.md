---
title: "E 570 Realignment and/or Widening of Improved Streets"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-570-realignment-andor-widening">Official BOE section</a></p>

<div><div>
        <div><p>The principal reasons for realigning and/or widening streets previously improved are:</p><ol><li>The need for redesigning the existing alignment to reduce accidents or increase the efficiency of traffic movements.</li><li>The necessity for meeting the street or highway standards of various ordinances or codes, such as Highway Dedication and Improvement (R-3), Subdivision, and Parcel map; also those standards due to zone changes and conditional uses. This necessity may be the result of private development by permits, Council Resolution, or assessment proceedings.</li><li>The need for projects included in the Five-Year Capital Program to conform to the width and alignment requirements of streets designated as major or secondary highways of the City’s Master Plan of Highways and Freeways and to those shown on Figure E 113, Standard Street Dimensions.</li><li>The necessity for modifying a street pattern because of a major project, such as a freeway, a grade separation, Urban Renewal Development, Community Redevelopment, etc. Figure E 670 shows typical sections of streets that are to be widened and some of the affected component parts.</li></ol><p>The design particulars for realignment and/or widening of improved streets are covered by the standards presented throughout this Part of the Manual and by the discussions that follow.</p><div><div><div id="_com_1"><p></p></div></div></div></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-570-realignment-andor-widening-0-e6b27d9e/">E 571 Interference of Existing Improvements</a></li></ul>
