---
title: "E 641 Types of Gutter"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-640-concrete-gutters-8e4a12d9/">E 640 Concrete Gutters</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-640-concrete-gutters/e-641-types-gutter">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>There are three types of gutter used. One type is a longitudinal gutter and, as previously noted, is placed adjacent to the curb. The second type is also longitudinal gutter, is used in alleys, and is generally constructed along the alley centerline. The third type is a cross-gutter and is placed in a transverse direction to the street, usually at street intersection.</p><p>Figure E 431.1 and the Standard Plan <em>Low Flow Channels for Cross-Gutters</em> show details of construction and design for the types of gutter used in the City.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing different types of curb and gutter" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20431.1%20Types%20of%20Curbs%20and%20Gutter_crop.png?itok=8swnyXKn">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing different types of curb and gutter</figcaption>
</figure>
<p></p><h3>E 641.1 Longitudinal Gutter (Adjacent to the Curb)</h3><p>In addition to its use for drainage control, the longitudinal gutter is placed against the curb for construction purposes. The width of concrete gutter separates the curb from the asphalt concrete pavement. This clearance enables a pavement roller to compact the edges of the asphalt concrete pavement more efficiently and eliminates roller damage to the curb.</p><p>Except where existing curb is to remain in place, concrete gutter should always be constructed integrally with proposed curb. Normally, concrete gutter is constructed 2 feet wide.</p><p>Concrete gutter may be omitted from projects where temporary detours are constructed, and from hillside projects where temporary asphalt berm has been permitted for use in lieu of concrete curb.</p><h3>E 641.11 Transverse and Longitudinal Gutter Slopes</h3><p>Gutters placed against curbs are constructed with transverse and longitudinal slopes. These slopes confine and direct the water to predetermined disposal points. The criteria for these slopes are as follows:</p><h5>E 641.111 Transverse Slopes</h5><p>Normally, the transverse slope of the gutter is designed to drain toward the curb. The exceptions to this are channelization islands and median strips. If, because of the landscaping of these traffic devices, there is no irrigation or dry-weather flow generated, 1-foot-wide gutters may be used. These gutters are constructed in the plane of the pavement and may be sloped so that drainage is away from the curb. However, in such a case the gutters would be constructed to facilitate construction rather than for drainage purposes.</p><p>The standard transverse gutter section when draining toward the curb should slope as follows:</p><ul><li>1 inch of slope for a 1-foot-wide gutter,</li><li>1.5 inches of slope for a 2-foot-wide gutter,</li><li>2 inches of slope for a 3-foot-wide gutter.</li></ul><p>The maximum slope for gutters 2 feet or less in width is 8.5 percent. The maximum slope for gutters 3 feet or more in width is 7 percent. A minimum slope may have to be used when reconstructing existing gutter or constructing new gutter in existing improved streets having extremely flat pavement crown sections. Although there is no minimum transverse slope limitation, slopes less than standard greatly reduce the gutter’s confining effects on drainage. The maximum slopes are used when reconstructing existing gutter or constructing new gutters on existing improved streets having higher than standard pavement crown sections. If the maximum gutter slope is exceeded, the confining of the drainage in the gutter is increased. However, the resulting excessive hike-up at the outer edge of gutter, if occurring at a driveway entrance, may result in a vehicle scraping its undercarriage in traversing the driveway. See <a href="/SoCal-Super-Standards/boe/street-design/e-2-65770955/"><u>Section E 564, Grade Determination (Street Resurfacing and Reconstruction)</u></a>.</p><h5><span>E 641.112 Longitudinal Slopes</span></h5><p><span>It is very difficult to construct concrete gutters with extremely flat longitudinal grades without creating</span><span> </span><span>some local flat areas or sumps. Therefore,</span><span> </span><span>the minimum longitudinal gutter slope to use is 0.200 percent. At the discretion of the office engineer, the absolute minimum longitudinal gutter slope that is permitted is 0.150 percent. Gutter grades of less than 0.150 percent cannot be constructed to drain satisfactorily. Where the existing conditions are such that a gutter grade of less than 0.150 percent would have to be constructed, the gutter grade would have to be redesigned.  Various methods for redesigning the gutter are suggested in </span><a href="/SoCal-Super-Standards/boe/street-design/e-390-grade-design-policy-d14643a0/"><span><u>Section E 390, Design Policy</u></span></a><span>; </span><a href="/SoCal-Super-Standards/boe/street-design/e-560-remodeling-improved-streets-dc4cf068/"><span><u>Section E 560, Remodeling Improved Streets</u></span></a><span>; and other sections of this Part of the Manual.</span></p><h5><span>E 641.113 Hydraulic Capacity of Gutter</span></h5><p>The average 5/8-inch-diameter garden hose 75 feet long will discharge approximately 10 gallons per minute under a head of 40 pounds per square inch. Assuming this represents runoff or dry-weather flow, the hydraulic capacity of a standard 2-foot- wide gutter on various longitudinal slopes is as shown in Figure E 441.113, below:<strong></strong></p><div><table><thead><tr><th scope="col"><strong>FOOT PER FOOT</strong></th><th scope="col"><strong>CUBIC FEET PER SECOND</strong></th><th scope="col"><strong>GALLONS PER MINUTE</strong></th></tr></thead><tbody><tr><td>0.015</td><td>0.230</td><td>103</td></tr><tr><td>0.02</td><td>0.264</td><td>119</td></tr><tr><td>0.04</td><td>0.375</td><td>168</td></tr><tr><td>0.06</td><td>0.459</td><td>206</td></tr><tr><td>0.08</td><td>0.530</td><td>238</td></tr><tr><td>0. 10</td><td>0.592</td><td>264</td></tr><tr><td>0. 12</td><td>0.650</td><td>292</td></tr><tr><td>0. 14</td><td>0.700</td><td>315</td></tr></tbody></table></div><p>When the dry-weather flow exceeds these values, either the slope should be increased, or a storm drain inlet should be constructed to prevent gutter overflow.</p><h5>E 641.114 Warping Gutters at Drainage Structures</h5><p>The concrete gutter surface is usually warped at the area of the entrance of drainage structures. This warping accelerates the flow and is a more efficient means of directing the water into the side-opening basins than standard gutter construction.</p><p>A local depression (LD) is not to be used on major traffic streets. It may be occasionally justified on purely local residential streets under special or unusual conditions.</p><p>Referring to Figure E 441.114, the various design criteria are shown for warping the concrete gutter at a side-opening catch basin and remodeling the adjacent pavement. The width of the warped area should not extend beyond the outer edge of gutter, or in a concrete paved street, not more than 2 feet from the curb line.</p><p>In constructing a warped gutter, additional pavement beyond the periphery of the warped gutter area should be removed for street with existing AC pavement to provide space for forming the concrete. See Figure E 441.114, Cases I and II. Additional pavement removal is not necessary for those portions of the proposed warped gutter area that would abut existing concrete gutter or concrete roadway. However, in order not to exceed the values for the various design criteria for warped gutter (as shown in the figure) and to provide a smooth grade in both a longitudinal and a transverse direction, it may be necessary to re- model the pavement beyond the limits of the warped gutter construction.</p><p>For grating catch basins without warped gutters, the curb face at the grating should not exceed the normal curb face plus 1 inch. At driveways with a 1-inch curb face, the top of the grating should not be set more than 1 inch below the finished surface. In cases where the depressed driveway curb face exceeds 1 inch, the difference in elevation between the top of grating and the top of the depressed curb should not exceed 2 inches.</p><h3><span>E 641.2 Longitudinal Gutter (Not Adjacent to the Curb)</span></h3><p>A longitudinal gutter is used without curbs in locations where a curb is not required, such as in some industrial streets and most alleys. See <a href="/SoCal-Super-Standards/boe/street-design/e-621-geometric-cross-section-730a18c4/#:~:text=E%20621.2%C2%A0Special%20Sections">Subsection E 621.2, Special Sections</a>; the figures for <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/"><u>Section E 510, Alleys</u></a>; and Figure E 431.1.</p><p>The standard longitudinal gutter is 2 feet in width. The cross-section and other construction and design details are shown on Figure E 431.1.</p><p>The information concerning maximum and minimum transverse and longitudinal slopes in<a href="/SoCal-Super-Standards/boe/street-design/e-641-types-gutter-f24fcd76/#:~:text=curb%20and%20gutter-,E%20641.1%20Longitudinal%20Gutter%20(Adjacent%20to%20the%20Curb),-In%20addition%20to"> Subsection E 641.1 Longitudinal Gutter</a> (Adjacent to the Curb) applies here as well.</p><p></p><h3><span>E 641.3 Cross-Gutters</span></h3><p><span>Subsurface drainage disposal systems are not always feasible from an economic standpoint. In such cases, surface drainage that is transferred from the high side to the low side of the street is usually handled by means of cross-gutters.</span><span> </span><span>Cross-gutters are generally placed across intersections or at sumps that may be in the street between intersections. However, cross-gutters should not be located across major or secondary highway intersections. Two types of cross-gutters are used by the City: </span></p><ol><li><span>the Standard Cross-Gutter and</span></li><li><span>the Low Flow</span><span> </span><span>Channel.</span></li></ol><h4><span>E 641.31 Standard Cross-Gutter</span></h4><p>The Standard Cross-Gutter is useful where dry-weather flow runs intermittently because the flow is confined to a limited area. However, to confine the water, cross-gutter design requires the construction of a dip in the pavement. This design has the disadvantage of creating an uncomfortable effect on the occupants of the vehicle when crossing the dip. In addition, the water carried in the gutter is subject to splashing by these vehicles. The dip in the pavement may be reduced in part by the method outlined in the next section.</p><h4>E 641.32 Low Flow Channel Cross-Gutter</h4><p>Some of the disadvantages of the standard cross-gutter have been overcome in part using the low-flow channel cross-gutter. The plan view, cross-section, and other design details of the grooved gutter are shown on the Standard Plan <em>Low Flow Channels for Cross-Gutters</em>.</p><p><span>The grooved area normally carries the dry-weather flow, preventing the water from encountering the tires of vehicles. Where a greater quantity of dry-weather flow is anticipated, the double grooved section is</span><span> </span><span>used.</span></p><p><span>The reduction of the pavement dip when using this type of cross-gutter instead of the standard cross-gutter is accomplished in the following manner. Referring to the profile of the flow line, groove, and gutter<strong> </strong>lines on the Standard Plan </span><em><span>Low Flow Channels for Cross-Gutters, </span></em><span>the top edge or the groove and the outer edge of the gutter are set at high enough elevations to minimize the dip for crossing</span><span> </span><span>vehicles.</span></p><p><span>The low flow cross-gutter may in turn create other problems. It sometimes requires excessive maintenance for proper operation. This is because any sediment, silt, or rubbish which accumulates in the groove, particularly on flat grades, reduces or eliminates the water-carrying capacity of the groove. When this occurs, the cross-gutter acts as a standard cross-gutter. Another disadvantage is that narrow-wheeled vehicles such as bicycles, baby-carriages, etc., as well as pedestrians’ shoe heels can be caught in the</span><span> </span><span>groove.</span></p><h4><span>E 641.33 Cross-Gutters Located at Other Than Intersections</span></h4><p>Cross-gutters may be constructed on local streets other than at intersections under the following circumstances:</p><ol><li>When a sump is located on the high side of the street and cannot be economically eliminated because of the interference of existing improvements.</li><li>When provisions for subsurface drainage disposal are not economically feasible.</li><li>When the cross-gutter is aligned perpendicular or at least roughly perpendicular to the street and there will be sufficient crossfall (at least 0.25% grade) to provide surface cross-drainage.</li><li>When the lower side of the street has longitudinal drainage. When there is sufficient crossfall, the cross-gutter flowline may be provided with a small amount of crown to approximate the existing crown in the street. The effect of this crown in the cross-gutter is to minimize the dip in the street profile at the cross-gutter. See <a href="/SoCal-Super-Standards/boe/street-design/e-391-design-details-97799cee/#:~:text=is%203%20percent.-,E%20391.32%20Rideovers,-To"><u>Subsection E 391.32, Rideovers</u></a>. When there is very little crossfall to provide cross-drainage, it is usually necessary to use a straight grade for the cross-gutter flowline. However, this straight grade increases the dip in the street profile at the cross-gutter vicinity. To reduce the dip, a transition of the street pavement crown sections approaching each side of the cross-gutter will have to be provided by fattening from the normal crown section to the grade of the cross-gutter.</li></ol><p>It is particularly important to produce a smooth riding line for cars traversing the cross-gutter, since a driver will not normally expect a sudden dip in the pavement surface at or near the mid-block.</p><p>A hypothetical design showing cross-gutter in a local noncontinuous street is provided on Figures E 441.33A and B. The cross-gutter is provided in this case because the sump cannot be eliminated. The elevations used on these figures show what the relationship should be between the flowlines, the outer edges of gutters, the street quarterlines, and the centerlines. This design should provide adequate longitudinal and cross drainage and smooth riding lines.</p><p></p><p>The elevations used at the cross-gutter edges of the quarterlines and the centerline provide a standard 0.03-foot hike-up above the gutter flowlines. However, the gutter hike-up at the corners of the cross-gutter are nonstandard since a compromise is sought between providing smooth riding lines and controlling the water in the longitudinal gutter or cross-gutter to prevent it from overflowing the corners of the cross-gutters. To provide this compromise, the hike-up at the corners of the cross-gutters may vary between 0.03 foot and 0.06 foot.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing the street plan for a non-intersection cross gutter" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20441.33A%20Street%20Plan_Crop.png?itok=Io3_2sT1">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing the street plan for a non-intersection cross gutter</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Work sheet showing non-intersection cross gutter profile and cross sections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-10/E%20600%20Fig%20441.33B%20Work%20Sheet%20Profile%20and%20Cross%20Sections.png?itok=mRmZj4NM">



      </div>
          </div>

</div>

<figcaption>Work sheet showing non-intersection cross gutter profile and cross sections</figcaption>
</figure>
<p></p></div>
      </div></div>
