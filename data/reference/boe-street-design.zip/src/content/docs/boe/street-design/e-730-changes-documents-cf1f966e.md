---
title: "E 730 Changes In Documents"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-700-new-project-construction-7cd75283/">E 700 New Project Construction</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-730-changes-documents">Official BOE section</a></p>

<div><div>
        <div><p>All changes in documents after the City Engineer signs the plans must be by one of the sequential processes as outlined below. For further discussions, see Part C, Operations and Control, when this Part of the Manual is printed.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-731-prior-advertising-bids-7ac47d26/">E 731 Prior To Advertising For Bids</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-732-prior-receiving-bids-and-after-d72de0ba/">E 732 Prior to Receiving Bids and After Advertising for Bids</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-733-after-contract-awarded-4c363952/">E 733 After Contract Is Awarded</a></li></ul>
