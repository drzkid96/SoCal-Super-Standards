---
title: "E 520 Cul-de-Sacs and Elbow Curves"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-520-cul-de-sacs-and-elbow-curves">Official BOE section</a></p>

<div><div>
        <div><p>Cul-de-sacs may be created as a means of access control and are used in areas in which the nature of the terrain, conflict with existing improvements, and economic considerations restrict, or fail to justify, the use of a through street.  Elbow curves are flared curves that are used to improve an abrupt change in street alignment. This section discusses methods of meeting the requirements of cul-de-sacs and elbow curves.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-455f74de/">E 521 Cul-De-Sac Alignments, Widths, and Turning Radii</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-0-6e5a837a/">E 522 Grades For Cul-De-Sacs</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-1-2eedf7ff/">E 523 Elbow Curves</a></li></ul>
