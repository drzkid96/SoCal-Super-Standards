---
title: "E 611 Standard Nomenclature of Street Cross-Section Elements"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-610-streets-fdc2b48b/">E 610 Streets</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-610-streets/e-611-standard-nomenclature-street-cross-section">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p><span>There is a tendency to interchange the terms of certain component parts of pavement and pavement support, as well as other features of street cross-section elements. The lack of uniform terminology has resulted in confusion and misunderstanding of legal documents and of oral and written communications.</span></p><p><span>The following discussion includes the terminology used to describe structural and geometric elements. Reference is also made to the typical cross-sections shown in Figure E 411.</span></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing the structural elements of three typical street sections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20411%20Strucutal%20Elements%20of%20Typical%20Sections_CROP.png?itok=ePogwvlt">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing the structural elements of three typical street sections</figcaption>
</figure>
<p></p><h3>E 611.1 Structural Elements</h3><p>The layers of materials which comprise the structural elements of a street are referred to as <em>courses</em>. These courses are put into place and brought to a specific grade. The top course is referred to as the surface course and the courses supporting the top course are called base courses. <span> </span>Since there are several types of base courses, the use of the term &quot;base course&quot; must also be qualified. For example, the term pavement base (course) is used for the layer below the surface course where two courses of pavement are used, the term subbase (course) where select material is required to support the pavement course(s), and the term stabilized subbase (course) where stabilization of the foundation or subsoil is used below the subbase course.</p><p>The term grade or subgrade, when used as a noun, indicates a line, surface, elevation, or place to which these courses are brought during construction. Where more than one course is used, each course is brought to a particular surface or plane and designated by the corresponding term, as illustrated on <a>Figure E 411.</a></p><h3><span>E 611.11 Geometric Elements</span></h3><p><span>Two geometric terms requiring clarification of usage are roadbed and parkway. Refer to Figure E 411. The term “roadbed” applies to the width of street between the backs of curbs. It is not to be confused with f</span><em>oundation </em>or subsoil, which is the undisturbed supporting soil within the roadbed limits.<span>  </span>The term parkway is often used to describe the area between the back of curb and the pedestrian access route (PAR), as well as the area between the face of the curb and the property line.<span>  </span>AASHO suggests the use of the term border for that area located between the curb face and the property line. The term “parkway” would then be reserved to define the area between the back of curb and the front of the pedestrian access route (PAR).</p><div><p> </p><div><div id="_com_1"><p></p></div></div></div></div>
      </div></div>
