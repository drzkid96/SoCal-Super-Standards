---
title: "E 630 Curbs and Gutters"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-600-cross-section-elements-6350a4f3/">E 600 Cross-Section Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-630-curbs-and-gutters">Official BOE section</a></p>

<div><div>
        <div><p><span>Curbs and gutters are used to:</span></p><ol><li><span>Define the</span><span> </span><span>roadway.</span></li><li><span>Control access to adjacent</span><span> </span><span>properties.</span></li><li>Protect<span> </span>pedestrians, vehicles, and private property.</li><li><span>Assist in orderly roadside</span><span> </span><span>development.</span></li><li><span>Channelize traffic flow.</span></li><li><span>Control drainage.</span></li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-631-structural-types-and-uses-0d882f00/">E 631 Structural Types and Uses</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-632-curb-placement-2d3796ac/">E 632 Curb Placement</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-633-miscellaneous-curb-design-details-cab9c63f/">E 633 Miscellaneous Curb Design Details</a></li></ul>
