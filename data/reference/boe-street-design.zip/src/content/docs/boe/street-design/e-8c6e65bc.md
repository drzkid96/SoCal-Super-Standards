---
title: "E 591 Design Criteria (formerly E 532.1)"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-590-access-ramps-formerly-e-532-2902e60f/">E 590 Access Ramps (formerly E 532)</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-590-access-ramps-formerly-e-532/e">Official BOE section</a> · City revision January 1, 1975</p>

<div><div>
        <div><p>The primary concern is the safety of people using the access ramp. The ramps must be designed to accommodate everyone, people who use wheelchairs, with low or no vision, with other physical disabilities, and those who are able-bodied alike. </p><p>Ramp slopes must be moderate to be usable by people who use wheelchairs without assistance.  Ramps should not be provided along streets which have grades too steep for safe use by people with disabilities.</p><p>While a ramp provides no particular benefit to people with low or no vision, a uniform location and surface texture along the pedestrian access route is important for orientation and wayfinding.</p><p>At least some curb face is needed at the foot of a ramp for the blind to locate the curb line. Conversely, the curb face must be minimal to present no serious obstruction to the passage of wheelchairs.</p><p>Sufficient ramps shall be provided at a given intersection or pedestrian crossing to avoid trapping a person with disabilities with no exit other than the entrance way.</p></div>
      </div></div>
