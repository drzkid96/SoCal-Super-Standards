---
title: "E 220 Financing"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-200-overview-street-improvement-projects-4d26d94a/">E 200 Overview of Street Improvement Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-overview-street-improvement-projects/e-220-financing">Official BOE section</a></p>

<div><div>
        <div><p>Funds from various sources are used by the City for financing the construction of street improvements.<span>  </span>The use of these funds is regulated by various codes and ordinances, and they must not be used indiscriminately. For purposes of this Street Design Manual, these funds may be classified as Gas Tax Funds, Private Funds, and Miscellaneous Funds.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-221-gas-tax-funds-8f1eb9a3/">E 221 Gas Tax Funds</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-222-private-funds-2a884d4a/">E 222 Private Funds</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-223-miscellaneous-funds-3106ee5e/">E 223 Miscellaneous Funds</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-221-gas-tax-funds-superseded-3f87f4c4/">E 221 Gas Tax Funds (Superseded)</a></li></ul>
