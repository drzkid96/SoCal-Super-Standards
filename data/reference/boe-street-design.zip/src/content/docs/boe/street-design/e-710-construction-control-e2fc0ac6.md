---
title: "E 710 Construction Control"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-700-new-project-construction-7cd75283/">E 700 New Project Construction</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-710-construction-control">Official BOE section</a></p>

<div><div>
        <div><p>The control of construction discussed in this section pertains <strong>primarily to </strong>street design projects which are contracted by the City. City control of street projects involves many City Bureaus, each having specific duties and responsibilities within the scope of the contract<strong>:</strong></p><ol><li>Bureau of Contract Administration—Inspects construction materials and workmanship and enforces compliance with the contract documents. See <a href="/SoCal-Super-Standards/boe/street-design/e-722-contract-documents-d1c4f94e/">Section E 722, Contract Documents</a>.</li><li><a>(Bureau of Standards — Samples and tests all materials incorporated into the work.)<sup>1</sup></a></li><li>Bureau of Engineering — Many Divisions are involved:<ol><li>Survey Division — Provides the surveys required for construction (for City awarded contracts only).</li><li>Utility and Estimating Division — Notifies the owners of public utilities of needed relocations of their facilities.</li><li>Coordinating Division — Negotiates supplementary agreements, processes change orders, negotiates extra work costs, etc.</li><li>A Design Division or District— Makes necessary design changes and decides on the intent of the contract documents. See <a href="/SoCal-Super-Standards/boe/street-design/e-722-contract-documents-d1c4f94e/">Section E 722, Contract Documents</a>.</li></ol></li></ol><hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and is no longer in use.</li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-7111-other-bureaus-and-departments-bf45a6fb/">E 711.1 Other Bureaus and Departments indirectly Involved</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-712-relationships-e0fdf478/">E 712 Relationships</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-713-duties-engineer-13e40863/">E 713 Duties of the Engineer</a></li></ul>
