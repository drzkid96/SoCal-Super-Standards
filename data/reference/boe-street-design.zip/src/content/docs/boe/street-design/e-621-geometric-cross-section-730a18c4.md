---
title: "E 621 Geometric Cross-Section"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-620-pavements-24c951c8/">E 620 Pavements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-620-pavements/e-621-geometric-cross-section">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Street pavements are provided with cross-slope to confine the flow of water along a street in a relatively narrow channel. The rate of cross-slope should be sufficient to remove surface waters quickly, yet the pavement should not be inclined to such an extent that drivers are conscious of it.</p><p>There are three different basic pavement shapes: the parabolic or T section; the V section; and the inverted V or tent section. Parabolic crown sections or T sections (special parabolic sections) are generally used on the surfaces of most City streets. Inverted V sections are generally used on freeways and limited access highways. Y sections are used in alleys. See <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/"><u>Section E 510, Alleys</u></a>. When circumstances dictate, it is sometimes necessary to use a combination of plane and curved<span> </span>surfaces.</p><h3>E 621.1 Parabolic Crown Sections</h3><p>The advantage in using parabolic crown sections is that the lane areas normally used for vehicular travel are relatively flat and the cross-slope steepens toward the edge of pavement, thereby facilitating transverse drainage toward the curb. The disadvantage is that parked vehicles or moving cars in the lane adjacent to the curb feel the effect of the steeper cross-slope, particularly where this slope acts adversely to vehicular turning movements on curved alignments.</p><p><span>To determine the parabolic crown, assuming a 2.5-percent slope over the 10-foot-width lane adjacent to the gutter (this is slightly steeper than</span><span> </span><span>the </span>2.08 percent recommended by AASHO), the<span> </span>gen<span>eral formula is:</span></p><p>$C=\frac{W^2}{160\left(W-10\right)}$</p><p><span>where  C </span>= <span>Crown in feet</span></p><p><span>                W </span>= <span>Width in feet of the parabolic</span><span> </span><span>section</span></p><p><span>See Figure E 421.1B.</span></p><p><span>It is possible to get approximately the same results obtained with the above quadratic equation by using a linear equation.  The deviation will not be more than 0.01 foot over the entire range of street widths.  The use of this linear equation</span><span> </span><span>is</span> <span>acceptable and may be used instead of the</span><span> </span><span>above</span> equation in determining the crown value. This formula is:</p><p>$C=0.006W + 0.10$</p><p><span>See Figure E 421.1B.</span></p><p>For example, using a width (W) of 36 feet, the value of the crown (C) is 0.006(36) + 0.10 = 0.316’ or say 0.32’. The value of the radius curve that approximates the parabolic curvature is determined by the formula R = 20W — 200, and the radius that may be used for laying out the parabolic curve for the above example would be R= 20(36)-200= 520’.</p><p>A table of values has been provided for various width highways.  See Figure E 421.1B. The table includes the corresponding radius, crown, or T section to be used. It also indicates how to calculate the elevation at any point on the parabolic crown surface.</p><p>Figures E 421.1A(1) and (2) show methods of detailing the elevations of the pavement surfaces for various<span> </span>cross-section.</p><p><span>Another common practice for designating parabolic curved crown surfaces is the use of the T section. A T section is a particular type of parabolic curve in which the letter “T” followed by a number designates the crown height in inches. </span>For example, T-3 and T-4 correspond to crowns 3 inches and 4 inches in height, respectively. In computing T sections, the total street crown (C) is determined either by formula or from the chart on Figure E 421.1B.<strong></strong></p><p><span>When W is 36 feet or less, a single T section may be used for the full width of the street. If W is greater than 36 feet, two T sections, each equal to 1/2 W in width, should be used. In this case, the total crown (C) will determine the elevation (E), and the sum of the crowns for the two one-half-width T sections should equal one-half the total crown. See Figure E 421.1B. The crowns on</span><span> </span><span>the two one-half-width T sections need not be equal, provided that their sum equals one-half the total crown.</span></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram and table of values to help define crown section by street class." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20421.1B%20Defining%20Crown%20Section_Crop.png?itok=prUlV9SU">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram and table of values to help define crown section by street class</figcaption>
</figure>
<p></p><h3>E 621.2<span> </span>Special Sections</h3><p>Normally in industrial areas, standard street cross-sections are used, as in other locations. However, if the street is not expected to carry much water, consideration may be given to a full width pavement between property lines. In such a case, longitudinal gutters not less than 4 feet wide are provided. The centerlines of these gutters are located along both theoretical curb lines. The longitudinal gutters are constructed as per Figure E 431.1. A V type cross-section for the entire width of street with a center gutter is not permitted. Where the entire surface is concrete pavement, longitudinal gutters may be provided that are equivalent to the above type of <span>gutter in dimensions and width by warping the </span>concrete in the gutter area and forming “V” depressions along the theoretical curb lines.<span>  </span>See <span>Figure E 421.2 below.</span></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing a special section for industrial streets" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20421.2%20Special%20Section%20for%20Industrial%20Streets.png?itok=TOZcNF2X">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing a special section for industrial streets</figcaption>
</figure>
<p></p></div>
      </div></div>
