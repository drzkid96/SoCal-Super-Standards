---
title: "E 340 Highway (Street) Capacity"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-340-highway-street-capacity">Official BOE section</a></p>

<div><div>
        <div><p>Highway, or street, capacity pertains to the ability of a roadway to accommodate traffic movements. Like speed, it is affected by various factors, such as traffic conditions, geometric features, and highway type. See <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">Section E 550, Intersections at Grade</a>. An analysis of highway capacity must be made by the designer because of the effect of these factors on design. The design elements used are based on the capacity figures for the future demand and the design capacity values.</p><p>Highway capacity is generally classified into two categories — capacity with uninterrupted flow where continuous traffic movements can be maintained for a substantial distance, and capacity with interrupted flow, a characteristic of City streets with at-grade intersections. Although the City is primarily concerned with interrupted flow, these two types of flow will be discussed here in broad general terms. Interrupted flow, the influence of the intersection, and the specific determination of intersection flow are presented in greater detail in <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">Section E 550, Intersections at Grade</a>.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-341-uninterrupted-flow-8686bddf/">E 341 Uninterrupted Flow</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-342-interrupted-flow-87afdbfe/">E 342 Interrupted Flow</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-343-equating-various-768e58c6/">E 343 Equating Various Highway Capacity Terminology</a></li></ul>
