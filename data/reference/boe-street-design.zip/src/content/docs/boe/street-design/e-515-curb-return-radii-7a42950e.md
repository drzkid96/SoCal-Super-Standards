---
title: "E 515 Curb Return Radii At Street Intersections"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-515-curb-return-radii">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>An alley return is that portion of the curb which begins at the BCR on the intersecting street and ends at the ECR, the intersection of the property lines of the street and alley. See Figure E 616.1B. The normal curb return radius is 5 feet for an alley intersecting a street. In areas zoned for industry, commerce, or multiple residences, or in narrow streets, the vehicular turning movements should be facilitated by increasing the alley return radii The curb return radius may be increased from 5 feet to any radius up to 10 feet, provided it does not encroach onto private property.</p><p>Where existing improvements such as utility poles, fire hydrants, or other appurtenances interfere with the construction of a 5-foot-radius curb return, they should be moved. However, if existing facilities require costly remodeling or removals, a smaller curb return radius may be used to avoid incurring excessive costs. In any case, any variations from the standard 5-foot curb return radius are subject to the approval of the District or Division Engineer.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing a typical plan of alley intersections" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20616.1A%20Typical%20Plan%20of%20Alley%20Intersections.png?itok=zVnK5PKP">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing a typical plan of alley intersections</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing different types of standard alley intersection configurations" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20616.1B%20Alley%20Intersections.png?itok=RDrnDShn">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing different types of standard alley intersection configurations</figcaption>
</figure>
</div>
      </div></div>
