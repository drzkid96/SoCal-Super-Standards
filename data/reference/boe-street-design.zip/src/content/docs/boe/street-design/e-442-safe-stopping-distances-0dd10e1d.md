---
title: "E 442 Safe Stopping Distances"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-440-sight-distance-488456e6/">E 440 Sight Distance</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-440-sight-distance/e-442-safe-stopping-distances">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The minimum stopping sight distance is equal to the safe stopping distance. It is the sum of two distances:</p><ol><li>The distance D<sub>1</sub> covered by a vehicle from the instant the driver sights an object to the instant the brakes are applied.</li><li>The distance D<sub>2</sub> required to stop the vehicle from the instant the brakes are applied.</li></ol><p>The time required for the first distance also consists of two components and is called the perception time. This is the sum of the time that elapses from the instant an object appears to the driver to the instant of realization that a stop must be made. The amount of perception time varies with the operator, the road conditions, and the situation involved. AASHTO considers 1.5 seconds as a sufficient time for most drivers. The second time interval is called brake reaction time and is the time required to apply the brakes. AASHO uses one second as a safety factor to include most drivers. <a>A constant value of 2.5 seconds for the total brake reaction and perception time is assumed by AASHTO for all ranges of design speed in their development of values for minimum stopping sight distance</a>.</p><p>Figure E 342 gives safe stopping distances for speeds from 20 to 70 miles per hour and formulas for calculating these distances. It also includes curves that provide a correction for the greater or lesser lengths traveled by a vehicle operating on descending or ascending grades. The formulas include a coefficient of friction between the tires and the roadway. An additional safety factor has been added by assuming a wet pavement and a correspondingly lower friction factor. Curves based on these equations are plotted on various figures included in this section.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Figure featuring safe stopping distances based on the AASHO formula." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342%20Safe%20Stopping%20Distances_crop.png?itok=h3f7GXXV">



      </div>
          </div>

</div>

<figcaption>Figure featuring safe stopping distances based on the AASHO formula.</figcaption>
</figure>
<p>The minimum stopping sight distance values are based on passenger car operation.  Generally, trucks require a longer distance to stop, for a given speed, than do passenger vehicles.  AASHTO does not provide any values for the additional lengths that would be required at the various speeds. However, trucks generally travel slower, and the operator, seated at a higher level, is provided with a greater vertical sight distance than passenger vehicle operators. Therefore, no distinction is usually made for sight distance requirements, between trucks and passenger vehicles. However, where truck traffic (no percentage figures available), efforts should be made to provide longer sight distances, particularly on downgrades, where truck traffic tends to increase speed.</p><h4><a>E 442.1 Stopping Sight Distance on Crest (Summit) Vertical Curves</a></h4><p>The algebraic difference in intersecting grades at the crest of a vertical curve is the basic limiting factor of the available sight distance. Figure E 342.1 gives the length of vertical curve necessary to provide the safe stopping sight distance required for a given algebraic difference in grade and for a given design speed.  The algebraic formulas for calculating sight distances are included in the figure.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Figure featuring an illustrative diagram of sight distance on a vertical curve and graph of stopping sight distance by length of crest vertical curves." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342.1%20Stopping%20Sight%20Distance%20on%20Crest%20Vertical%20Curves_crop.png?itok=8VgdMHcU">



      </div>
          </div>

</div>

<figcaption>Figure featuring an illustrative diagram of sight distance on a vertical curve and graph of stopping sight distance by length of crest vertical curves.</figcaption>
</figure>
<h4><a>E 442.2 Headlight Sight Distance on Sag Vertical Curves</a></h4><p>The minimum length of safe vertical curve should provide headlight visibility for unlit or poorly lit highways for a distance that is at least equal to the safe stopping distance for the design speed of the street. The headlights are assumed to be 2.0 feet above the pavement surface and have a maximum deviation of the beam above the horizon of one degree of arc. The headlight beams may be cut off by the sag in grade and/or any over- crossing structures. In the case of the truck driver, the sight distance may be less than that of the passenger vehicle operator because the view, as provided by the higher eye level of the truck driver, is cut off sooner by an overcrossing structure. This factor should be considered in determining the length of sag vertical curves, with overcrossings, that have a large proportion of truck traffic (truck percentages not available).</p><p>Figure E 342.2 shows a series of curves for determining the length of sag vertical curves. These lengths will provide the necessary sight distance for a given algebraic difference in grade and a designated design speed. Formulas which may be used for determining the required length of vertical curve are also included.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Figure featuring an illustrative diagram of headlight sight distance on a sag vertical curve and graph of algebraic difference of grades by length of vertical curve." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342.2%20Headlight%20Sight%20Distance%20on%20Sag%20Vertical%20Curves_crop.png?itok=XONU969y">



      </div>
          </div>

</div>

<figcaption>Figure featuring an illustrative diagram of headlight sight distance on a sag vertical curve and graph of algebraic difference of grades by length of vertical curve.</figcaption>
</figure>
<h4><a>E 442.3 Minimum Radii for Stopping Sight Distance on Vertical Curves</a></h4><p>All the formulas used in the investigation and calculation of vertical curves contain the ratio .  It can be shown that  is equal to the minimum radius of a parabola. The minimum radius of a parabola occurs at the point where the slope of the tangent to the vertical curve is zero. On a summit vertical curve connecting a plus and a minus grade it is located at the highest point on the curve. On a sag vertical curve with the same conditions, it will be located at the lowest point on the curve. On vertical curves connecting two plus or two minus grades it would occur not on the finite curve but on the imaginary prolongation of the curve at the point where the tangent grade is zero. Since both the sight distance and the riding qualities of a vertical curve are functions of the minimum radius, it is possible to specify minimum radii for vertical curves which will provide any desired sight distance or comfortable speed. See <a>Figure E 342.3A</a>, below.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table of minimum radii of parabola by class of highway" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20400%20Fig%20E%20342.2A%20Minimum%20Radii%20for%20Vertical%20Curves.png?itok=gTZNpwng">



      </div>
          </div>

</div>

<figcaption>Table of minimum radii of parabola by class of highway</figcaption>
</figure>
<p>The use of the figure is illustrated by the following examples:</p><ol><li><p>Given a crest vertical curve connecting a +6 percent grade and a -2 percent grade. Design speed is 50 miles per hour. Calculate the minimum length of vertical curve for the stopping sight distance.</p><p>$A=\frac{+6-\left(-2\right)}{100}=0.08$</p></li></ol><p>From the figure opposite design speed of 50 miles per hour and under the column headed “Crest Curve -6” Object”, read R = 8763 feet. Then L = 8763 x 0.08 = 701.04 feet, which is the minimum length of vertical curve to provide a stopping sight distance for 50 miles per hour. </p><ol start="2"><li><span>Given a sag vertical curve connecting a +5 percent grade and a -4 percent grade. Design speed is 50 miles per hour. Calculate the minimum length of curve required for a lighted</span><span> </span><span>highway.</span></li></ol><p>$A=\frac{+5-\left(-4\right)}{100}=0.09$</p><p>From the figure opposite 50 miles per hour design speed and under the column headed “Speed — No Apparent Acceleration,” read R = 3000 feet.<span>  </span>Then L = 3000 x 0.09 = 270 feet, which is the minimum length of a sag vertical curve to be used for 50 miles per hour on a lighted highway.</p><ol start="3"><li>Given a crest vertical curve, design speed of 50 miles per hour, length of 600 feet, and an algebraic difference in grades of 7 percent.<span> </span>Can the stopping sight distance for a 6-inch object be satisfactory for the design speed?</li></ol><p>$R=\frac{L}{A}=\frac{600}{\frac{7}{100}}=8571&#x27;$</p><p>From the figure opposite 50 miles per hour design speed and under the column headed “Crest Curves — 6” Object”, read R = 8763 feet, which is the minimum radius required and which is greater than the radius calculated.  The length of vertical curve is unsatisfactory. Therefore, either a greater length of vertical curve must be used or the algebraic difference in grades must be reduced. The minimum radii for stopping sight distance on vertical curves may be deters tried graphically by referring to Figure E 342.3B.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Figure featuring illustrative diagrams of stopping sight distance on vertical curves and graph of stopping sight distances by minimum radius of vertical curves." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342.3B%20Min%20Radii%20for%20Stopping%20Sight%20Distance%20on%20Vertical%20Curves_crop.png?itok=I7GV839O">



      </div>
          </div>

</div>

<figcaption>Figure featuring illustrative diagrams of stopping sight distance on vertical curves and graph of stopping sight distances by minimum radius of vertical curves.</figcaption>
</figure>
<p></p><h4><a name="_Toc167119786">E 442.4 Non-Passing Sight Distance on Horizontal Curves:</a></h4><p>The horizontal sight distance on the inside of a curve may be restricted by objects located off the pavement, such as buildings, bridge piers, natural growth, cut slopes, or other topographic features. Where this sight restriction occurs, the safe stopping sight distance (non-passing sight distance), on horizontal curves for a given design speed determines the minimum horizontal radius to be used.</p><p>From the equation or curves shown on Figure E 342, the safe stopping sight distance can be obtained for a given design speed.<span>  </span>Referring to Figure E 342.4A, an algebraic or graphic solution can be found, using the safe stopping<span>  </span>sight<span> </span>distance S previously obtained, knowing either the available horizontal radius of curvature R or the available clear distance D as measured radially from inside edge of pavement or curb line.</p><p>Since extreme accuracy is not necessary, simple but approximate equations as shown on Figure E 342.4A and in the following discussion have been provided.  The values secured in using these equations are slightly in error but are on the side of safety. If the height criteria are used for horizontal curves as stipulated in Section E 441, small height variations, such as nonlevel pavement cross- sections, do not usually affect design except where the sight restriction is a cut slope or other variable-height object.</p><p>The curves on Figure E 342.4A are limited to those cases in which the required sight distance is less than the length of curve provided. The approximate formula when S ≤ L<span> </span>is:</p><p>$D=\frac{S^2}{8\left(R+\frac{W}{2}\right)}-\frac{W}{2}$</p><p>Although these curves are plotted for lane widths of 12 feet, approximate answers may be obtained for other typical lane widths.</p><p>As noted above, the graph in the figure is for sight distances less than the length of curve provided. No such graph is available at this time for sight distances greater than the length of curve provided. However, it should be emphasized that there is an approximate formula for use in such cases.<span>  </span>The approximate formula when S ≥ L is:</p><p>$D=\frac{2SL-L^2}{8\left(R+\frac{W}{2}\right)}-\frac{W}{2}$</p><p>The following examples illustrate the application of these formulas for a given set of conditions.</p><p>Given: Primary hillside collector street with a 74-foot-width right-of-way and a 60-foot-width roadway. </p><p>See Figure E 113, Standard Street Dimensions.  Figure E 311.6 indicates the use of a minimum centerline radius R of 443 feet where a curved street alignment is necessary.  A minimum sight distance of 275 feet is required for a design speed of 40 miles per hour.<span>  </span>See Figure E 342.4A. Other considerations assumed are a 6 percent pavement superelevation, a 2:1 side slope, a 2.5 percent sidewalk grade, and an 8-inch curb face.</p><p>Find: The horizontal distance from the curb to the point where the 2:1 slope through the obstruction intersects the 2.5 percent sidewalk slope, and determine if available clear horizontal distance D in feet from the curb line to the obstruction at height of the line of sight is adequate (does not require a sight distance easement).<span> </span>See Figure E 342.4B.</p><p>From the formula:</p><p>$L_L=\frac{R_L \times L_S}{R_S}$</p><p>Where  L<sub>L</sub> = Length of curb lane centerline</p><p>R<sub>L</sub> = Radius of curb lane centerline</p><p>L<sub>s</sub>= Length of street<span> </span>centerline</p><p><span>R<sub>S</sub> = Radius of street</span><span> </span>centerline</p><p>Since the required sight distance of 275 feet is less than the centerline length of curb lane provided, the value D is obtained from the<span> </span>formula:</p><p>$D=\frac{S^2}{8\left(R+\frac{W}{2}\right)}-\frac{W}{2}=\frac{275^2}{8\left(413+\frac{10}{2}\right)}-\frac{10}{2}=17.6&#x27;$</p><p>From the curves, using a 12-foot-width lane, a clear horizontal distance D of 16.6 feet would have been required.</p><p>It can be seen from the figure that due to the slope of the existing ground, there is an insufficient distance D available. For met practical purposes, the approximate D distance is determined as in the above example and rounded off to the nearest higher even foot. Either the slopes are then graded back (in the above case to a D distance of 18 feet) in newly developed areas (such as new subdivisions) or, if the property has been previously developed, a sight distance easement is acquired for this grading. In order to calculate more precisely where the 2:1 slope through the obstruc<span>tion intersects the 2.5 percent sidewalk</span><span> </span><span>slope,</span><span> </span><span>proceed</span><span> </span><span>as</span><span> f</span><span>ollows:</span></p><p>Assume a straight pavement grade around the curve along the lane centerline, between the driver and the object on the pavement. The average height of the driver’s eye above the pavement (3.75 feet) and the object on the pavement (0.5 feet) is:</p><p>$\frac{3.75&#x27;+0.5&#x27;}{2}=2.13&#x27;$</p><p>By adding an assumed pavement elevation of 100.00 feet to this, an elevation of the line of sight of 102.13 feet is found. From this we obtain the following:</p><ol><li>Side AW = 17.6&quot; × tan angle AYW (0.50) = 8.80’</li><li>Side AC = 102.13’ — top of curb elevation of 100.37’ = 1.76’<span>    </span>the<span>   </span>average<span>   </span>of<span>  </span>the<span>   </span>eye<span>   </span>level<span>  </span>of<span>   </span>the<span>   </span>driver and</li><li>Side CW = 8.80&#x27;— 1.76&#x27;= 7.04’</li><li>Angle BXC = 0.025 (sidewalk slope)</li><li>Angle CXW = 0.50 — 0.025 = 0.475</li><li>Side $BX =\frac{7.04&#x27;}{0.475}=14.82&#x27;$<span></span></li><li>Elevation of point X = 100.37’ +(14.82’ × 0.025) = 100.74’</li><li>Side GX = 102.13’ — 100.74’ = 1.39’</li><li>Side $GY = \frac{1.39&#x27;}{tan angle AYW \left(0.05\right)}=2.78&#x27;$  <span></span></li></ol><p><span>From the calculations made, the 2:1 slope through the obstruction intersects the sidewalk slope 14.82 feet from the curb. The existing ground at the average height of the line of sight is higher than </span>102.13 feet at a point 17.6 feet back from the curb.<span>  </span>Therefore, where the grade and/or alignment of the street cannot be adjusted, either the slopes have to be graded or a retaining wall must be constructed (whichever is determined to be more economical) to provide this clear<span> </span>distance.<span></span></p><p>The City’s minimum standards for the design of local hillside streets in new subdivisions or in existing streets do not usually require additional easements for sight distance when grading streets and side slopes or constructing a retaining wall at the theoretical grading line. This method should be used also to determine whether sight distance easements are required in improving streets with existing substandard right of way widths or alignments. See Figure E 113 Standard Street Dimensions. The following example illustrates these points since minimum standards are included in the calculations.</p><p><em>Given:</em> Local hillside street with a design speed of 25 miles per hour and a sight distance S of 150 feet, a minimum centerline radius R of 132 feet, a minimum curve length L of 100 feet, a superelevation of 6 percent, and a new subdivision with side slopes graded at a 2:1 slope.</p><p><em>Find: </em>The clear horizontal distance D from the inside edge of the inner riding lane to the 2:1 slope at the line of sight, and the sight distance S when the required sight distance is greater than the centerline curve length L of the inner riding lane.<span> </span>See Figure E 342.4C.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Plan and cross-section views of non-passing sight distance on horizontal curves on a local hillside street" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20342.4C%20Non-Passing%20SIght%20Distance%20on%20Horizontal%20Curves_crop_0.png?itok=5gW-XinG">



      </div>
          </div>

</div>

<figcaption>Plan and cross-section views of non-passing sight distance on horizontal curves on a local hillside street</figcaption>
</figure>
<p></p><ol><li><span>As in the previous example, the elevation of the average eye level of the driver and the height of object is 102.13 feet. This average elevation is radially opposite the point of obstruction on the centerline of the inner riding lane. Also, the elevation on the pavement at this point is 100.00 feet. Extending the 6 percent superelevation down from the 100-foot elevation to the flow line and adding a 8-inch curb face to this gives a top of curb elevation of:</span></li></ol><p>100.00’ — 0.06(8&#x27; + 5&#x27;) +<span> </span>0.67&#x27;= 99.89&#x27;</p><ol start="2"><li><span>The elevation at the toe of slope, point A,</span><span> </span><span>is: </span>99.89&#x27; + (0.025<span> </span>×<span> </span>5’) = 100.02&#x27;</li><li>The distance AC is: 102.13’ — 100.02’= 2.11’</li><li>The horizontal distance BC equals twice AC when there Is a 2:1 slope. Therefore: 2.11’ x 2 = 4.22’</li><li><span>When checking a riding lane that is not adjacent to the curb, assume, for calculating purposes, that the inner edge of the inner riding lane is the theoretical</span><span> </span><span>curb</span><span> </span><span>line</span><span> </span><span>and</span><span> </span><span>proceed</span><span> </span><span>as</span><span> </span><span>in</span><span> </span><span>the</span><span> </span><span>previous example. Therefore, in this case the assumed curb radius is 122 feet, and the clear distance D</span><span> </span><span>is: </span> </li></ol><p>8’+ 5&#x27; + 4.22’ = 17.22’</p><p>The sight distance provided by these factors should be checked using the formula when S is equal to or less than the length of the curve to see whether the sight distance overlaps the center length of the riding<span> </span><span>lane.</span></p><ol start="6"><li><span>Length L along the centerline of the inner</span><span> </span><span>riding lane is:</span></li></ol><p>$\frac{127&#x27;}{132&#x27;}\times100&#x27;=96.21&#x27;$</p><ol start="7"><li>Using the formula:</li></ol><p> $D=\frac{S^2}{8 \left(R+\frac{W}{2}\right)}-\frac{W}{2}$, then</p><p></p><p><span>$S=\sqrt{8 \left(D+\frac{W}{2}\right) \left(R+\frac{W}{2}\right)}=150.25&#x27;$ </span></p><p>Since 150.25 feet is greater than 96.21 feet, the sight distance overlaps the centerline length of the inner riding lane. The formula where S is equal to or greater than the curve length should be used instead:</p><p>$D=\frac{2SL-L^2}{8 \left(R+\frac{W}{2}\right)}-\frac{W}{2}$, then</p><p><span>$S=\frac{8 \left(D+\frac{W}{2}\right)\left(R+\frac{W}{2}\right)+L^2}{2L}=165.43&#x27;$ </span></p><p><span>Since 165.43 feet is greater than 150.25 feet, grading the slope at 2:1 or constructing a retaining wall (if more economical) provides a sight distance greater than the required sight distance. Therefore, no additional sigh distance easement is required.</span></p><p>However, if it is an existing street with existing improvements, check whether the existing ground can remain undisturbed (no sight distance easement required) and yet provide adequate clear distance D. Assume that a wall or other obstruction exists on the theoretical grading line (1 foot in back of the property line). The available clear distance D would then be measured from this grading line to the theoretical curb line (the inner line of the riding lane.<span>  </span>Therefore, referring to Figure E 342.4C, D is 13 feet. Using the formula:</p><p>$D=\frac{2SL-L^2}{8 \left(R+\frac{W}{2}\right)}-\frac{W}{2}$, then</p><p>$S=\frac{8 \left(D+\frac{W}{2}\right)\left(R+\frac{W}{2}\right)+L^2}{2L}=143.15&#x27;$ </p><p></p><p>The sight distance of 143.15 feet furnished is less than the sight distance of 150.25 feet required.<span> </span>However, there is a sufficient safety factor involved in arriving at the required sight distances for given speeds for most practical purposes.<span>  </span>This is true for all minimum standard City streets, as shown on Figure E 113, Standard Street Dimensions. The horizontal sight distance provided by the above conditions obviates the necessity for obtaining sight distance easements on private property. It should also be noted that a car parked on the inside curb lane near the end of the line of sight will reduce the sight distances calculated- above by approximately one-third.<span>  </span>Since parking restrictions are difficult to enforce on residential streets, the above facts should emphasize the undesirable effects produced by using minimum design standards.</p><p>When changes of grade coincide with horizontal curves (either a crest vertical curve or a sag vertical curve with an overhead obstruction such as a bridge) , the vertical sight distance is the controlling factor and should exceed the horizontal sight distance requirements. In some cases, despite the use of a minimum horizontal radius of curvature, it may be necessary, to improve the line-of-sight clearance, to cut back the slope or natural growth or, where feasible, remove or modify existing structures.</p></div>
      </div></div>
