---
title: "E 690 Traffic Guides and Barrier Installations"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-600-cross-section-elements-6350a4f3/">E 600 Cross-Section Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-690-traffic-guides-and-barrier-installations">Official BOE section</a></p>

<div><div>
        <div><p>In hazardous areas where vehicles which inadvertently leave the highway may be subjected to considerable damage, traffic guides and barrier installations are used.<span>  </span>Such areas include steep fill or natural side slopes, steep grades on long through fills, abrupt changes of alignment, sharp curves, dead-end streets, etc. See Figures E 490(1), (2), and (3) for typical installations.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing typical installations of traffic guides and barrier devices" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-1%20Typical%20Installations%20of%20Traffic%20Guides%20and%20Warning%20Devices.png?itok=o9p7eyJh">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing typical installations of traffic guides and barrier devices</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing typical installations of guard rails" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-2%20Typical%20Installations%20of%20Guard%20Rails.png?itok=8DnNWPsT">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing typical installations of guard rails</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Plan view of typical installations of metal guard rails" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20490-3%20Plan%20View%20of%20Typical%20Installations%20of%20Metal%20Guard%20Rails.png?itok=LF9lV036">



      </div>
          </div>

</div>

<figcaption>Plan view of typical installations of metal guard rails</figcaption>
</figure>
</div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-691-choice-location-6a7841b0/">E 691 Choice of Location and Type</a></li></ul>
