---
title: "E 321 Design Vehicle Physical Characteristics"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-320-design-vehicle-physical-characteristics-and-a21225d6/">E 320 Design Vehicle Physical Characteristics and Minimum Clearances</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-320-design-vehicle-physical-characteristics-and-0">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>For geometric and structural highway design purposes, the design vehicle characteristics considered are size, weight, power (acceleration) and deceleration (stopping distance). <a>See Figure E 221.</a></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="This is an illustrative diagram showing the dimensions of various test vehicles." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20300%20Fig%20221%20Dimensions%20of%20Test%20Vehicles.png?itok=DNFPYp93">



      </div>
          </div>

</div>

<figcaption>This is an illustrative diagram showing the dimensions of various test vehicles.</figcaption>
</figure>
<p></p><h4><a name="_Toc167118270">E 321.1 Size</a></h4><p>The size determines the radius of clearances between motor vehicles and highway curves, lane widths, parking or storage dimensions structures and other highway appurtenances<span> </span>as for turning movements, and horizontal and vertical well as some of the physical characteristics of the clearances.</p><h5>E 321.11 Length</h5><p>The length of vehicle directly affects the minimum turning radius and the parking or storage dimensions. Its length of wheelbase and overhang indirectly affects the vertical clearance between the pavement and the vehicle, e.g., in steep driveways. It indirectly affects the lane widths to the extent that additional lane widths may be necessary to accommodate the turning of the longest vehicles.<span>  </span><a>The maximum length vehicle permitted in California is a semitrailer with a maximum length of 40 feet together with a truck combination, making a total length of 65 feet.</a></p><h5><span>E 321.13 Width</span></h5><p>The width of the vehicle directly affects the lane width and parking dimensions and indirectly affects the radius of curvature. Also, to maintain at least the same horizontal clearance, wider vehicles require wider lanes which in turn require wider structures and/or rights-of-way. The maximum width of the vehicle is 8 feet.</p><h5>E 321.13 Height</h5><p>The height of the vehicle directly affects the vertical clearance between vehicles and structures, the sight distance, and the driveway clearance. The maximum height of vehicle permitted in the State of California is 13.5 feet.</p><p>Vehicles are designed so that no portion of the undercarriage is lower than the lowest portion of the rim of the wheel. The tire size determines the lowest point of the rim. Passenger cars usually have a minimum clearance of at least 6 inches, although it may be less when the car is fully loaded.</p><p>The level of the average driver’s eyes above the pavement surface for passenger vehicles is 3.75 feet.</p><h4><a name="_Toc167118271">E 321.2 Weight</a></h4><p>The weight determines the design of the structural pavement cross-section and the appurtenant highway structures. State regulations permit a maximum wheel load of 9500 pounds on any one wheel supporting one end of an axle and a maximum load of 18,000 pounds per axle.</p><h4><span>E 321.3 Acceleration and Power</span></h4><p>The vehicle’s ability to accelerate is basically dependent on the power. The acceleration and power enable the vehicle to maintain speed on uphill grades, make it necessary to provide uphill as well as level passing lanes, and are major factors in determining the maximum allowable grades.</p><p>Modern cars can accelerate at a greater rate than as indicated on Figure E 221.3, below. This maximum acceleration is usually used for ascending steep grades or for overtaking other vehicles. But for normal acceleration, the curves on the figure show, for example, that a vehicle whose initial speed is 30 mph will require 400 feet to attain a speed of 40 mph.</p><p><a>In terms of maximum rates of acceleration, passenger cars vary from 4 to 6 mph/sec. and trucks from 1.5 to 2 mph/sec.</a></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="This is a graph showing the normal acceleration of passenger vehicles increases (as measured by miles per hour reached) over distance traveled (in feet)." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20300%20Fig%20221.3%20Normal%20Acceleration%20of%20Passenger%20Vehicles.png?itok=x9P7c5NS">



      </div>
          </div>

</div>

<figcaption>This is a graph showing the normal acceleration of passenger vehicles increases (as measured by miles per hour reached) over distance traveled (in feet).</figcaption>
</figure>
<p></p><h4><a name="_Toc167118273">E 321.4 Deceleration</a></h4><p>The rate of deceleration determines the safe stopping distance and safe sight distance. Trucks generally require longer distances to come to a stop under emergency conditions than passenger cars. <a>Based on the U.S. Bureau of Public Roads tests conducted in 1955 on various types of vehicles, the distances required for brake system application and braking are as shown in Figure E 221.4A</a>. See Subsection E 041.6 (3b1). </p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="This is a table summarizing the 50th and 85th percentile of brake-system application and braking distances (in feet) from 20 miles per hour by vehicle type." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20300%20Fig%20221.4A%20Brake%20System%20Application%20and%20Braking%20Distances%20Table.PNG?itok=rS_pFz5Y">



      </div>
          </div>

</div>

<figcaption>This is a table summarizing the 50th and 85th percentile of brake-system application and braking distances (in feet) from 20 miles per hour by vehicle type.</figcaption>
</figure>
<p></p><p></p><p>From the Figure 221.4B below, all vehicles traveling at an initial speed of 20 mph and decelerating to a stop will require a distance ranging from 23 feet for a passenger car to 67 feet for a truck-tractor and will lie in the 85-percentile group. Those vehicles falling outside of this group require either more or less distance due to more extreme conditions of the braking systems, reaction times, and other miscellaneous causes. Figure E 221.4B, below, indicates the distance traveled by a passenger vehicle while decelerating. For example, a vehicle decelerating at a <em>comfortable rate</em> would travel about 125+/- feet from 50 mph to 40 mph, and at a <em>leisurely rate</em> about 230+/- feet from 50 mph to 40 mph.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph showing distance traveled in feet while braking based on initial speed when brakes are applied, measured in miles per hour." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20300%20Fig%20221.4B%20Distance%20Traveled%20While%20Braking%20Graph.PNG?itok=eJpHt43K">



      </div>
          </div>

</div>

<figcaption>Graph showing distance traveled in feet while braking based on initial speed when brakes are applied, measured in miles per hour.</figcaption>
</figure>
<p><span></span></p><h4><a name="_Toc167118274">E 321.5 Minimum Turning Radii</a></h4><p>Based on the discussion previously presented, the designer determines the largest size vehicle expected to use a particular street. This vehicle should then be able to negotiate a turn without striking or mounting the curbs or encroaching on the lane lines that delineate the median opening or channelized intersections.</p><p>Computer software such as AutoTURN or Vehicle Tracking can draw the swept width and/or tracking width along any design curve within a CADD drawing program such as MicroStation or AutoCAD. Dimensions taken from the vehicle diagrams in Figure 221 may be inputted into the computer program by creating a custom vehicle if the vehicle is not already included in the software library. Swept path analysis software will allow you to outline the minimum turning radius path required for the largest vehicle that frequently uses a roadway facility or intersection. </p><p>(The simplest method of determining the minimum turning radii to be used on these streets is the use of the turning vehicle templates. <a>A pair of clear plastic templates is included in the pocket of the cover of this manual.</a> These templates, which are drawn to a scale of 1” = 20’ and 1” = 40’, outline the minimum turning radius path required for the largest legal-sized tractor-trailer truck combination.</p><p>The template is placed on the drawing to see if any part of the wheel path or overhang path encroaches on the proposed curb or paint lane lines that demarcate the median opening or traffic islands. The adjustment of the location of the channelized openings and required lane widths can then be readily affected by this method.)<sup>1</sup></p><p>If any part of the wheel path or overhand path encroaches on the proposed curb or paint lane lines that demarcate the median opening or traffic islands, the location of the channelized openings, land widths, and intersection approach striping may need to be adjusted.</p><hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and has been superseded by the italicized text that follows.</li></ol></div>
      </div></div>
