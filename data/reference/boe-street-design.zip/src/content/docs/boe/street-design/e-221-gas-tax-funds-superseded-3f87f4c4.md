---
title: "E 221 Gas Tax Funds (Superseded)"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-220-financing-5a80427a/">E 220 Financing</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-220-financing/e-221-gas-tax-funds-superseded">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p><strong>Note: The information in this page is superseded by </strong><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-220-financing/e-221-gas-tax-funds"><strong>E 221 Gas Tax Funds</strong></a></p><p>Gas Tax Funds are received by the City from the State of California. The use of these funds is regulated by the California <em>Streets and Highways Code </em>and the specific applications as covered by the <em>City and Country Projects Manual. </em>See Section E 020E and E 020F (5d). <em> </em>These documents limit the use of gas tax funds to the improvement of Select System streets, including certain rights of way and appurtenances necessary for their construction and maintenance. A list of these gas tax eligible items is presented under Section E 132.</p></div>
      </div></div>
