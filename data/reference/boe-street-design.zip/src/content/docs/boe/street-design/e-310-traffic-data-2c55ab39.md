---
title: "E 310 Traffic Data"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-310-traffic-data">Official BOE section</a></p>

<div><div>
        <div><p>Generally, the street project engineer requires traffic data which should include present volumes for the days of the year and times of the day.<span>  </span>Also, there should be traffic trends stated from which an estimate may be made of future volumes.<span>  </span>This data helps the designer plan the type of (highway)<sup>1</sup> street. </p><p>The distribution of vehicles by types and by weights determines the traffic load, which is expressed as the traffic index (T.I.). This determines the required structural section, lane widths, turning radii, etc., for the street. The flow pattern and diagrams aid in determining the geometrics of intersections, median strips, channelization, access control, traffic controls, etc. The analysis of (accident)<sup>1</sup> collision  data and volume is used in establishing economic justifications for budgeting purposes and priority of project construction for the correction of hazardous traffic conditions. (These calculations are generally done by the Coordinating Division of the Bureau of Engineering.)<sup>1</sup> These calculations are generally done by the Department of Transportation. </p><hr><p>Footnote</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and has been superseded by the italicized text that follows.</li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-311-volume-c23a0a49/">E 311 Volume</a></li></ul>
