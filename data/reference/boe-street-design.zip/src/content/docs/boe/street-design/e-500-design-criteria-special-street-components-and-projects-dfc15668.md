---
title: "E 500 Design Criteria For Special Street Components and Projects"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects">Official BOE section</a></p>

<div><div>
        <div><p>In general, the design criteria and policies previously presented are applicable to the special street components and projects that are discussed in this chapter. However, since certain additional considerations must be given to these special street components or types of projects, their separate treatment is warranted.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-520-cul-de-sacs-and-elbow-curves-1eb455a8/">E 520 Cul-de-Sacs and Elbow Curves</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-530-driveways-3a58bf38/">E 530 Driveways</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-540-grade-separations-48d42a32/">E 540 Grade Separations</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">E 550 Intersections At-Grade</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-560-remodeling-improved-streets-dc4cf068/">E 560 Remodeling Improved Streets</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-570-realignment-andor-widening-f2211fb1/">E 570 Realignment and/or Widening of Improved Streets</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-580-private-streets-559f2d13/">E 580 Private Streets</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-590-access-ramps-formerly-e-532-2902e60f/">E 590 Access Ramps (formerly E 532)</a></li></ul>
