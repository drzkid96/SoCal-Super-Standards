---
title: "E 620 Pavements"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-600-cross-section-elements-6350a4f3/">E 600 Cross-Section Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-620-pavements">Official BOE section</a></p>

<div><div>
        <div><p><span>The criteria for pavement cross-sections</span><span> </span><span>are</span><span> </span><span>considered from two aspects: </span></p><ol><li><span>the geometric section, which involves the shape or crown given to the pavement, and </span></li><li><span>the structural section, which deals with pavement and</span><span> </span><span>pavement</span><span> </span><span>support.</span></li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-621-geometric-cross-section-730a18c4/">E 621 Geometric Cross-Section</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-622-pavement-design-structural-9e4ac08c/">E 622 Pavement Design (Structural)</a></li></ul>
