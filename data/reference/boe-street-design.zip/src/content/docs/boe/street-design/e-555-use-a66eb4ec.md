---
title: "E 555 Use Of Nomographs For Determination Of Signalized Intersection Capacity"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">E 550 Intersections At-Grade</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-550-intersections-grade/e-555-use">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The nomographs, Figures E 655A, Chart 1, and E 655B, Chart 2, represent two samples of twenty charts that are included in the Public Roads publications of August and October 1967. These charts are used for making various adjustments to find design capacities for given roadway and traffic conditions. They are simple arrangements for determining the design capacity of one approach to a signalized intersection for average conditions. <a> Average conditions constitute 5 percent trucks and buses, 10 percent right turns, 10 percent left turns, and no bus stops. </a>Figure E 655A is for 2-way facilities, and Figure E 655B is for a 1-way facility. The upper part of each nomograph is a plot of the curves from Figures E 554.1B and C with a load factor of 0.3 for the different types of facilities (except for rural highways), parking conditions, and location within the metropolitan area. The curves show the relationship between the approach width and the design capacity for average conditions in terms of vehicles per hour of green. <span> </span>The lower part of the chart is a proportional graph that converts, for a given signal timing, the design capacity to a volume of vehicles per hour. The third graph unit on the right adjusts this volume to a given metropolitan<span> </span>size.</p><p>The two charts are applicable to situations where only approximate solutions are required or where specific traffic characteristics are not known. They also form the basis for developing additional nomographs for specific conditions. In the upper parts of the graphs are curves, <span>five in Figure E 655A and eight in Figure E 655B, which are the basis for 13 additional detailed charts which are included in the publications. Each curve in the succeeding charts, expanded to a family of curves representing various percentages of trucks in the traffic stream, forms the upper section of a separate nomograph. The signal-timing adjustment (G/C ratio) part of the graphs in Figures E 655A and B is used to form the last section of the succeeding charts. The intermediate parts of the succeeding charts account successively for the effects of right tums, left turns, and metropolitan area size.</span></p><p>The first 15 charts are supplemented by an additional five charts. The first three of these five additional charts provide adjustments for conditions where there are bus stops at the intersection, determine capacities of separate right- and left- turn lanes without signal indication, and determine capacities of separate right- and left-turn lanes with separate signal indication.</p><p>The last two of these charts are designed for use in planning street systems and in preliminary design, or for review of plans where approximate but quick solutions are desired in terms of total or overall intersection capacity. Also, they are augmented by several tables and special conditions that can be used for complete analyses of practically any form of signalized intersection problem.</p><div><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Nonograoh of design capacity of signalized intersections for a two-way street" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20500%20Fig%20655A%20Design%20Capacity%20of%20Signalized%20Intersections.png?itok=KN91B1ot">



      </div>
          </div>

</div>

<figcaption>Nomograph of design capacity of signalized intersections for a two-way street</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Nonograoh of design capacity of signalized intersections for a one-way street" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20500%20Fig%20655B%20Design%20Capacity%20of%20Signalized%20Intersections.png?itok=gUe1ypeW">



      </div>
          </div>

</div>

<figcaption>Nomograph of design capacity of signalized intersections for a one-way street</figcaption>
</figure>
<div><div id="_com_2"><p></p></div></div></div></div>
      </div></div>
