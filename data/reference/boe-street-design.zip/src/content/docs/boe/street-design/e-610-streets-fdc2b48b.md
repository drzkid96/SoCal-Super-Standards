---
title: "E 610 Streets"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-600-cross-section-elements-6350a4f3/">E 600 Cross-Section Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-610-streets">Official BOE section</a></p>

<div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-611-standard-nomenclature-street-cross-section-2d4f1f12/">E 611 Standard Nomenclature of Street Cross-Section Elements</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-612-width-standards-and-component-arrangements-af302672/">E 612 Width Standards and Component Arrangements</a></li></ul>
