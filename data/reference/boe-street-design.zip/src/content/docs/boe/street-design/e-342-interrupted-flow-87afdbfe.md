---
title: "E 342 Interrupted Flow"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-340-highway-street-capacity-cff5a112/">E 340 Highway (Street) Capacity</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-340-highway-street-capacity/e-342-interrupted-flow">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>In urban areas, interrupted flow will occur due to many factors, including the following:</p><ol><li>Number and geometrics of intersections.</li><li>Volume of cross-traffic.</li><li>Lane and street widths.</li><li>Parking conditions.</li><li>Percent of truck traffic.</li><li>Percent of turning vehicles.</li><li>Bus stops.</li><li>Pedestrian movements.</li></ol><p>Generally, uninterrupted flow capacities are used as a basis or capacity and then modified when interrupted flow conditions prevail.</p></div>
      </div></div>
