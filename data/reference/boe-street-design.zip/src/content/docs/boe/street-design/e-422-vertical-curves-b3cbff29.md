---
title: "E 422 Vertical Curves"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-420-vertical-alignment-e0a07544/">E 420 Vertical Alignment</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-420-vertical-alignment/e-422-vertical-curves">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><h4>E 422.1 Purpose</h4><p>A vertical curve is used to avoid the sudden change of direction when moving from one grade to another.<span>  </span>If the vertical curve is properly designed, it will provide adequate sight distance, safety, comfortable driving, good drainage, and pleasing appearance. If the curve is too short it will probably sacrifice some of these desirable features. On the other hand, long, flat vertical curves are undesirable, because they may develop poor drainage conditions. In addition, they may discourage some drivers from attempting passing maneuvers even though there may be an adequate passing safety margin.</p><p>One of the most important controls is ample sight distance for a given design speed. This factor will be discussed separately in <a href="/SoCal-Super-Standards/boe/street-design/e-440-sight-distance-488456e6/"><u>Section E 440, Sight Distance</u></a>.</p><h4>E 422.2 Properties</h4><p>That portion of a parabolic curve which closely approximates the parabolic curve is generally used in highway design.<span>  </span>Although highway lengths are measured on a horizontal plane rather than the profile slope, and because highway grades are generally flat, the use of a parabola results in no appreciable error. In addition, the ease of calculations of the vertical offsets from a tangent grade as against the more involved calculations of a circular curve justifies its use. Another advantage of the use of the true parabola is that it permits the sight distance and the speed to be calculated or scaled from charts. The sight distance and speed cannot be calculated for curves with unequal grade breaks or for curves with equal grade breaks including the two end breaks because neither of these curves is a true parabola. This means that time-consuming graphical methods must be resorted to for a determination of sight distance and safe speed. See <a href="/SoCal-Super-Standards/boe/street-design/e-440-sight-distance-488456e6/"><u>Section E 440, Sight Distance</u></a>.</p><h4><span>E 422.3 Computations</span></h4><p><span>See Figure E 322.3 below.</span></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Diagram and table providing the series of computations to determine values for vertical curve design" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20322.3%20Vertical%20Curve%20Computations_crop.png?itok=fkGiXa_y">



      </div>
          </div>

</div>

<figcaption>Diagram and table providing the series of computations to determine values for vertical curve design</figcaption>
</figure>
<p></p><h4>E 422.4 Requirements for Comfortable Riding Qualities<span></span></h4><p>Making riding conditions comfortable as well as safe should always be a part of the street designer’s goal. The degree of comfort is affected by the length of curve, the design speed, and the grade differences. The relationship between these factors is determined by the formulas and conditions listed below.</p><h5>E 422.41 Acceleration Not Perceptible</h5><p>Where it is unnecessary to provide stopping sight distance equal to the safe stopping distance, as for example on a lighted sag curve, vertical curves should be of sufficient length to produce no perceptible sensation of vertical acceleration. The maximum vertical acceleration which will pass unnoticed on a vertical curve is approximately two feet per second, per second. Using a value of 1.79 feet per second, per second for maximum vertical acceleration, the minimum length of vertical curve will be L = 1.2 AV<sup>2</sup>, where A equals the algebraic difference in grades in percent ÷ 100 and V is the design speed in miles per hour. The length of curve given by this formula should be used only when sight distance requirements do not govern. See Figure E<span> </span>322.41.</p><p></p><h5>E 422.42 Maximum Acceleration</h5><p>There will be <span>a</span><span> </span><span>few</span><span> </span><span>instances,</span><span> </span><span>such</span><span> </span><span>as</span><span> </span><span>approaches</span><span> </span><span>to</span><span> </span><span>cross</span><span> </span><span>gutters and warped surfaces in intersections, where due to space limitations it will be necessary to use vertical curves which produce a definite sensation of vertical acceleration. The maximum vertical acceleration that still provides comfort is between four and five feet per second, per second.  Using a value of 4.30 feet per second, per second for acceleration, the minimum length or vertical curve will be L = 0.50 AV<sup>2</sup>.</span></p><h5><span>E 422.43 Distance</span><span> </span><span>Between Grade Breaks</span></h5><p><span>Grade breaks on vertical curves should be computed or plotted on the profile at such intervals that assuming the curve to be constructed as a series of chords, the maximum difference between the chord and the true curve shall not be greater than 0.02 of a foot. The distance between grade breaks which will limit this difference to 0.02  of a foot is given by the following</span><span> </span><span>formula:</span></p><p>$d=0.4\sqrt{\frac{L}{A}}$</p><p>Where d = The distance between grade breaks in feet</p><p>L<span> = </span>Length of vertical curve</p><p><span>A = </span>Algebraic difference in grades in percent ÷ 100</p></div>
      </div></div>
