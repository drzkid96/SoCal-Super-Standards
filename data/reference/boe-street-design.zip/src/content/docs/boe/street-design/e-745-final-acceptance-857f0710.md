---
title: "E 745 Final Acceptance"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection/e-745-final-acceptance">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>After the corrections have been made by the contractor, the final inspector will notify the engineer to submit his acceptance and will give the engineer the option of accepting this correction with or without an additional field review. Delays in acceptance of the work result in a delay of formal acceptance of the project and the final payment to the contractor. Such delays may therefore contribute to higher bids from contractors on future projects.</p><p>The engineer shall therefore prepare a “Project Completion Report” immediately, or on the day following his acceptance of the work, independent of the inspector’s acceptance. This report memorandum shall be transmitted to the Coordinating Division for work order and assessment act projects and to the Street Opening and Widening Division for “B” Permits. This procedure shall be followed even if submitted change orders have not been issued and processed.</p></div>
      </div></div>
