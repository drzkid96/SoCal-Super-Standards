---
title: "E 380 Intersection Grades Controlled by Street Classification"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-380-intersection-grades-controlled-street">Official BOE section</a></p>

<div><div>
        <div><p>Wherever possible, grades will be laid straight across intersecting streets without the use of benches. Where, due to steep grades, the use of a bench is unavoidable, the street of major importance will preferably be laid straight and the intersecting street benched.<span>  </span>In the case of a T intersection, the through street will be on a straight grade and the grade of the side street may be flattened as necessary to meet the plane of the through street.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-0-8389dad9/">E 381 Major Highway Intersecting Major Highway</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-1-25d375d9/">E 382 Major Highway Intersecting Local Street</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-2-a5f8b52b/">E 383 Local Street Intersecting Local Street</a></li></ul>
