---
title: "E 532 Prohibited Locations For Driveway Approaches"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-530-driveways-3a58bf38/">E 530 Driveways</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-530-driveways/e-532-prohibited">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Driveway approaches should not be constructed in the following locations or under the following conditions:</p><ol><li>Under permit, when the Standard Plans cannot be followed because of local conditions.  However, if the (Design Office)<sup>1</sup><s> </s>City Engineer or designee permits a deviation and obtains a signed waiver from the property owner, construction may be permitted.</li><li>When records do not show an official street grade. Construction may take place only after an official street grade has been established.</li><li>Where vehicular access to property is already provided from an abutting alley. However, if there are existing driveways serving more than half of the properties within a given block, driveways may be constructed at the discretion of the Design Office.</li><li>Between the prolonged intersecting property lines at any street or alley intersection, or between the points of curvature of any curb return having a radius of 20 feet or less. Under certain conditions, a driveway may be merged with an adjacent alley intersection.</li><li><a>Where only partial ingress of vehicles onto private property for the purpose of loading and unloading is possible (where vehicles parked across the sidewalk would prevent full and free use of the sidewalk by pedestrians).</a></li><li>Where no ingress of vehicles onto private property is possible.</li><li>Where the curb or berm to be depressed will not include improvement of the area bounded by the curb or berm depression and the property line.</li><li>Where a driveway approach which serves “C-2” or less restrictive zoned property is constructed less than 5 feet from an adjoining “A” or “R” zoned property. (Requirements apply to any automotive service station. tire and tube repairing, battery service, automobile lubrication, automobile laundry. or wash rack establishment.) To determine whether a minimum of 5 feet is provided, find the distance to be measured by drawing a line, perpendicular or radial to the curb, from the intersection of the side lot line and the street property line, regardless of the angular relationship between these lines. See Figure E 632, below.</li></ol><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing specific details of a driveway approach serving C-2 or less restrictive zoned property" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-09/E%20500%20Fig%20632%20Driveway%20Approach%20Sering%20C-2%20or%20Less%20Restrictive.png?itok=f-Y4e3Xb">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing specific details of a driveway approach serving C-2 or less restrictive zoned property</figcaption>
</figure>
<hr><p>Footnotes</p><p><sup>1</sup>The text in parenthesis is from the legacy Street Design Manual text and has been superseded by the text that follows.</p></div>
      </div></div>
