---
title: "E 110 Manual References and Sources of Information"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-100-introduction-and-general-information-2be36ad5/">E 100 Introduction and General Information</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information/e-110-manual-references-and-sources-information">Official BOE section</a></p>

<div><div>
        <div><p>The charts, tables, sketches, and discussions presented in this Street Design Manual are extracts from the references listed in this section and from the practices and policies of various offices in the Department of Public Works. It is suggested that the designer become familiar with the original sources of information contained in these references, as well as with the contents of various sections of this Street Design Manual.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-111-f2dc6d2a/">E 111 The Los Angeles Municipal Code</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-112-21964e81/">E 112 Standard Specifications for Public Works Construction</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-113-f60ab151/">E 113 Standard Plans</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-114-81ab8815/">E 114 Records</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-116-0eb30311/">E 116 Other Reference Sources</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-115-5e648e97/">E 115 California State Statutes Relating to the Department Of Public Works (Superseded)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-116-0-05b479d7/">E 116 Other Reference Sources (Superseded)</a></li></ul>
