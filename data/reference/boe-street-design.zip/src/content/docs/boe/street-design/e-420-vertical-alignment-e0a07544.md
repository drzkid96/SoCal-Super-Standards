---
title: "E 420 Vertical Alignment"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-400-general-roadway-design-elements-f5b07ac0/">E 400 General Roadway Design Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-420-vertical-alignment">Official BOE section</a></p>

<div><div>
        <div><p>As with horizontal alignment, there are general design policies for vertical alignment, as well as certain modifications that are required in dealing with urban areas. A general discussion, along with some of these modifications and the different applications of vertical curves, are presented in the sections that immediately follow. Other design details and procedures are given in Chapter E 500, Grade Determination.</p><div><div><div id="_com_4"><p></p></div></div></div></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-421-basic-grade-controls-3592058e/">E 421 Basic Grade Controls</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-422-vertical-curves-b3cbff29/">E 422 Vertical Curves</a></li></ul>
