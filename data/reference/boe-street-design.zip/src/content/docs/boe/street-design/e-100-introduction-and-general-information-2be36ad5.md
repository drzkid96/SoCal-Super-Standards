---
title: "E 100 Introduction and General Information"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information">Official BOE section</a></p>

<div><div>
        <div><p>This Manual covers the design of streets. It presents design criteria, standards, policies and procedures to the new designer and provides a reference source for the experienced designer. The contents are to be used as a guide and are not a substitute for professional experience. Sound judgment must be exercised in the application of these provisions, and they do not preclude the use of different methods when special or emergency conditions warrant and when authorized by responsible<span> supervision.</span></p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-110-manual-references-and-sources-information-6a515639/">E 110 Manual References and Sources of Information</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-120-definitions-9a38dde3/">E 120 Definitions</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-130-abbreviations-1a998745/">E 130 Abbreviations</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-purposes-d0bb5d41/">E 140 Fundamentals of Real Property for Street Design Purposes</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-150-legal-liability-and-maintenance-responsibility-c9133db0/">E 150 Legal Liability and Maintenance Responsibility</a></li></ul>
