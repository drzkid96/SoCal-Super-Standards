---
title: "E 700 New Project Construction"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction">Official BOE section</a></p>

<div><div>
        <div><p>During the construction of a project, the engineer must make use of certain other skills in addition to the technical ones required for design. These projects are either contracted by the City or will be owned by the City upon completion. The engineer’s relationship with the public, the contractor, the inspector, and the representatives other agencies involves skills in public relations as well as knowledge of construction methods, City standards of construction, traffic requirements, and other sources of information. This chapter attempts to summarize the design engineer’s role during this important period.</p><p>A significant portion of the public improvements in the City are constructed by land developers and other property owners. These may range in size from simple driveways to large tract or developments, including storm water drainage, sewage disposal, streets and sidewalks, streetlights, etc. The Bureau of Engineering has many responsibilities in connection with these improvements. In most cases, these responsibilities are the same as those for projects contracted by the City. Those cases in which they differ will be pointed out as they arise during the discussion that follows.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-710-construction-control-e2fc0ac6/">E 710 Construction Control</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-720-bid-document-ffc473d8/">E 720 Bid Document</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-730-changes-documents-cf1f966e/">E 730 Changes In Documents</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></li></ul>
