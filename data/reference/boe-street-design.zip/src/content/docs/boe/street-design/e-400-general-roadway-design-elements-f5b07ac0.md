---
title: "E 400 General Roadway Design Elements"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements">Official BOE section</a></p>

<div><div>
        <div><p>The controls and criteria previously presented, such as traffic data, speed, capacity, etc. have a direct bearing on the general design elements with the design speed being the overall control.  The general design elements are horizontal and vertical alignment, and sight distance. These elements, as well as superelevation, topography and meeting existing improvements have a joint relationship and effect on the geometric design. These effects are discussed in the succeeding sections.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-410-horizontal-alignment-9fca5bea/">E 410 Horizontal Alignment</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-420-vertical-alignment-e0a07544/">E 420 Vertical Alignment</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-430-combination-horizontal-and-vertical-alignment-c1f77ad9/">E 430 Combination of Horizontal and Vertical Alignment</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-440-sight-distance-488456e6/">E 440 Sight Distance</a></li></ul>
