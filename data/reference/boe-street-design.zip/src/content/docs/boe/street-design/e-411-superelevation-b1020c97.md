---
title: "E 411 Superelevation"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-410-horizontal-alignment-9fca5bea/">E 410 Horizontal Alignment</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-410-horizontal-alignment/e-411-superelevation">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Where horizontal curvature is introduced into the alignment, it is desirable to use a radius large enough to permit safe travel at the desired design speed without the use of superelevation. However, to permit safe operation for shorter radius curves, use is made of superelevation. Superelevation used on substandard radii of curvature will permit a more uniform speed in all lanes and will eliminate abrupt changes in the maximum safe speed, particularly on reverse curves.</p><p>The relationship between design speed, curvature, and superelevation is given by the formula:</p><p>$E+F=\frac{0.067V^2}{R}=\frac{V^2}{15R}$</p><p>Where  E = Superelevation rate foot per foot</p><p>F = Side friction factor in foot per foot</p><p>V = Vehicle speed in mph</p><p>R = Radius of curve in feet</p><p>The figures included in this section are based on these formula. Using the street classification and the corresponding design speed for the proposed project, values of radii, superelevation, and other factors may be obtained from these figures, which are briefly described in the following subsections.</p><h4>E 411.1 Side Friction Factors</h4><p>The maximum safe side friction factors vary from 0.09 foot per foot at 100 mph to 0.30 foot per foot at 20 mph. See Figure E 311.1. The side friction factor at impending skid is also shown on the figure.  The factor of safety for the design value of F varies from 3.33 at 100 mph to 1.67 at 20 mph.  The value of F recommended for design by AASHTO is also shown on the figure. It is slightly more conservative than the value recommended by the Bureau of Engineering.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph showing the side friction factors by velocity in miles per hour and formula " src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20400%20Fig%20E%20311.1%20Superelevation%20Side%20Friction%20Factors.png?itok=zE3FrGT_">



      </div>
          </div>

</div>

<figcaption>Graph showing the side friction factors by velocity in miles per hour and formula</figcaption>
</figure>
<p></p><h4><span>E 411.2 Maximum Safe Speed on Horizontal Curves</span></h4><p>Figure E 311.2 has been prepared from the exact formula for superelevation, using the recommended value of F for maximum safe speed and rates of superelevation varying from 0.05 foot per foot to 0.12 foot per foot. This figure should be used for the solution of all problems concerning safe speed.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Graph showing the maximum speed on horizontal curves for superelevation design" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20400%20Fig%20E%20311.2%20Maximum%20Safe%20Speed%20on%20Horizontal%20Curves.png?itok=ZfdKkdyJ">



      </div>
          </div>

</div>

<figcaption>Graph showing the maximum speed on horizontal curves for superelevation design</figcaption>
</figure>
<p></p><h4>E 411.3 Superelevation and Superelevation Transition</h4><p>The amount of superelevation and the length of the superelevation transition for radii larger than the minimum are shown graphically on Figure E 311.3. Formulas are given for calculating these values. The method of attaining the maximum superelevation is also shown. On flat grades, this recommended method of revolving the pavement surface about the centerline will result in sumps on the outer edge of the pavement. To avoid this condition, the pavement should be revolved about the inside edge rather than the centerline. In this case, the transition should be twice as long as the length shown on the figure. After a superelevation is computed, profiles of the pavement edge should be plotted, and any uneven or distorted grades should be changed by using smooth curves.</p><h4>E 411.4 Minimum Radius and Maximum Transition Length for Limiting Values of E and F</h4><p>Figure E 311.4 gives minimum radii and transition lengths with maximum superelevation of 0.06 foot, which is the desirable maximum for City streets. Minimum radii and transition lengths are also given for zero superelevation. The value of C is the rate of increase of the unbalanced centrifugal force in the formula for the length of transition. It is noted that the transition length to safely reverse the unbalanced centrifugal thrust is the same for the maximum superelevation, as well as for zero superelevation. This condition results from the fact that the formula for length is based on the maximum allowable unbalanced centrifugal thrust. From this figure it is possible to calculate the minimum desirable tangent between reversing curves of minimum radii. Since two-thirds of the maximum superelevation should be provided at the B.C. and E.C. of the curves, the minimum tangent length is two-thirds of the sum of the transition lengths. See Figure E<span> </span>311.5.</p><h4>E 411.5 Design of Horizontal Curves</h4><p>As an example, Figure E 311.5 shows the application of the superelevation charts to the design of a typical local hillside street.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing an example design of horizontal curves with superelevation on a local hillside street with a design speed of 25 mph" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20400%20Fig%20E%20311.5%20Design%20of%20Horizontal%20Curves%20with%20Superelevation_crop.png?itok=zMzAGPBO">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing an example design of horizontal curves with superelevation on a local hillside street with a design speed of 25 mph</figcaption>
</figure>
<p></p><h4>E 411.6 Minimum Length of Curve</h4><p>Figure E 311.6, below, lists the minimum centerline radius of horizontal curvature and the minimum length for a given highway classification, taking into consideration the maximum superelevation of 6 percent and the designated design speed. For smaller central angles, the centerline radius must be increased to maintain the indicated minimum length of curve.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Table showing the minimum length of curve by highway classification" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2024-08/E%20400%20Fig%20E%20311.6%20Minimum%20Length%20of%20Curve%20by%20St%20Class.PNG?itok=SaP5p8Qa">



      </div>
          </div>

</div>

<figcaption>Table showing the minimum length of curve by highway classification</figcaption>
</figure>
<p></p><p>An illustration of the use of this figure is as follows: Assume a local hillside highway classification with a required minimum centerline radius of 132 feet. The figure shows that a minimum of 100 feet of centerline arc length with a minimum central angle of 43.406 degrees must be provided. Where the central angle is less than 43.406 degrees, say 30 degrees, the centerline radius must be in- creased to a value that may be determined by using the following formula:</p><p>$R=\frac{L}{\Delta}$</p><p>Where R = Centerline radius required in feet</p><p>L<span> = </span>Minimum length of centerline required</p><p><span>∆ = </span>Central<span>  </span>angle<span>  </span>of<span> </span>centerline<span>  </span>in radians</p><p>Then:</p><p>$R=\frac{100}{0.523598}=190.989&#x27;$</p><p>This means a centerline radius of at least 190.989 feet, say 200 feet, must be provided.</p></div>
      </div></div>
