---
title: "E 580 Private Streets"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-580-private-streets">Official BOE section</a></p>

<div><div>
        <div><p>The increased filing of maps showing private streets as part of a planned residential development or condominium has necessitated a determination of policy regarding the use of private streets and the application of Private Street Regulations in the <a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-123254">LA Municipal Code, Chapter I, Article 8</a>. Experience of the Bureau of Engineering and other City departments indicates that approval of private streets should be discouraged for the following reasons:</p><ol><li>Private streets usually include substandard improvements.</li><li>The private road easements are narrow, resulting in substandard roadway widths.</li><li>The private street area may be utilized in the computation of lot areas of adjoining properties, which results in substandard lot sizes.</li><li>Various City Departments, such as Fire, Police, Water and Power, and Public Works object to their service vehicles having to travel on private streets for legal as well as physical reasons.</li><li>Purchasers of lots fronting private streets are often unaware that they are responsible for the maintenance of the street.</li><li>Private streets restrict the development of adjacent areas which require access to public streets.</li><li>The use of a private street with a condominium development is a violation of the Municipal Code, since the definition of a private street presumes more than one ownership.</li><li>Private streets combined with public streets in a tract result in complications and questionable legality when enforcing completion of improvements under improvement bonds.</li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-581-design-f5538af4/">E 581 Design Standards</a></li></ul>
