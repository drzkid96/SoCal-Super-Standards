---
title: "E 514 Alley Termination (Dead-End and Cul-De-Sac Alleys)"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-514-alley-termination">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Although it is usually desirable to locate alleys in such a manner that both ends of the alley are connected either to streets or to other alleys, it is not always feasible.  In hillside or mountainous terrain, the connections may be impractical because of economic considerations. Large cuts or fills may necessitate dead-ending the alley at some appropriate location to keep the grading to a minimum.  Other alleys may be cut off because of freeway construction or other projects. In new subdivisions, or in older existing alleys, it may be impractical to extend an alley through to the next street. This is usually because of extensive existing improvements in the logical path of alley prolongation.</p><p>Provisions must be made for a vehicular turning area where alleys dead-end. Figure E 113, Standard Street Dimensions, depicts the standard and minimum turning areas. Where these alleys are substandard width and cannot be widened, some modified form of equivalent turning area must be provided.</p></div>
      </div></div>
