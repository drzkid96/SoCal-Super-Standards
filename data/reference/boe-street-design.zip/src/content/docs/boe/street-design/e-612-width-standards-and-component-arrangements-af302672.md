---
title: "E 612 Width Standards and Component Arrangements"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-610-streets-fdc2b48b/">E 610 Streets</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-610-streets/e-612-width-standards-and-component-arrangements">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The following Los Angeles Municipal Code ordinances either designate the Master Plan to be used or specify the street widths and/or arrangement of the street cross-section<span> </span>components.</p><ol><li>Ordinance No. 122,064 (Division of Land) is used in new or proposed subdivisions of land.</li><li>Article 8 (Private Street Regulations) amended to, and including, Ordinance No. 122,064 contains the requirements to be met in the design of “Private Streets.”</li><li>Ordinance No. 120,796 (R-3 Ordinance) and Ordinance No. 125,340, an amendment to Section 12.37 of Ordinance No.120,796, contain the requirements to be met for street widths in the development of land zoned R-3 or of any less restricted zone.</li><li>Ordinance No. 122,312 (Lot Split Ordinance) is used when subdividing parcels of land not under the jurisdiction of the State and City’s subdivision laws.</li></ol><h3><span>E 612.1 Street Cross-Sections</span></h3><p><span>The Streets Dimension Standard Plan (</span><a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a><span>) </span><span>shows the standard street widths and cross-section component arrangement. The widths for alleys, private streets, and pedestrian walkways are discussed below. The sections illustrated are the standards for new streets. The sections designated for existing streets are the </span>desirable minimum standards and should be increased where practicable.</p><h4>E 612.11 Alleys </h4><p>(Alleys servicing predominantly industrially zoned areas should be provided with a 36-foot width. Commercial and residential alleys require a 20-foot<span> </span><span>width.)<sup>1</sup> </span>Alleys shall be a minimum of 20 feet in width and intersections and/or dead-end terminuses shall be designed to conform to the alley illustrations included in the<span> Streets Dimension Standard Plan (</span><a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a><span>).  </span></p><h4><span>E 612.12 Pedestrian Walkways (Inner Block Walks) </span></h4><p>A pedestrian walkway is designed for pedestrian use but may also be appropriate for slow-moving bicyclists.  All new public walkways or areas set aside for dedication as pedestrian walkways may be provided with a width between 10 to 25 feet. The design covering sidewalk grades discussed in <a href="/SoCal-Super-Standards/boe/street-design/e-652-sidewalks-a605f229/"><u>Section E 652, Sidewalks</u></a> should apply also to the design of pedestrian walkways.</p><h3>E 612.2 Pavement Traffic Lanes</h3><p>These vary in width and arrangement, depending on the vehicular composition, speed, traffic movements, and available roadway width.</p><h4>E 612.21 Lane Widths</h4><p><span>The current design criteria used by the City of Los Angeles for traffic lane widths are as follows:</span></p><ol><li>The absolute minimum width parking lane is 8 feet.</li><li>The desirable minimum width parking lane is 10 feet.</li><li>The absolute minimum width travel lane is 9 feet.</li><li>The desirable minimum width travel lane is 10 feet.</li><li>The standard width travel lane is 11 feet.</li><li>The maximum width travel lane is 12 feet.</li></ol><h4>E 612.22 Lane Arrangements</h4><p>In general, when no other considerations are given, major and secondary highways are divided into three equal standard width lanes in each direction. Right-turn flares and medians with left-turn pockets should be provided at the intersections. See <a href="/SoCal-Super-Standards/boe/street-design/e-660-medians-17bb4fe7/"><u>Section E 660, Medians</u></a>. When initiating or designing a street improvement, it is important to make every effort to secure sufficient roadway width to meet the above standards.</p><p>Since ideal conditions are not always attainable, it is necessary to consider the optimum arrangement of standard and substandard width lane combinations for a given set of traffic conditions and a given roadway width For example, for undivided highways or streets that do not have median strips and that permit high-speed traffic flow or have sinuous alignments, the widest lane should be placed nearest the street centerlines. The wider lane provides a safety margin between lines of traffic moving in opposite directions.</p><p>For streets having median strips, or for those streets where only slow-moving traffic is expected, such as in downtown business districts, the widest lane is generally placed nearest the curb for the following reasons:</p><ol><li>The wider lane facilitates the flow of traffic, since it is more difficult to judge the clearance between barriers, such as curbs, on the vehicle’s right side than on its left side.</li><li>The wider vehicles, such as buses and trucks, are usually directed toward the use of the lane nearest the curb.</li><li>The wider lane helps to reduce the conflict between moving traffic and parked vehicles.</li></ol><p>For examples of various lane arrangements, refer to Figures E 464.2A, B, and C.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing striping standards for major highways" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20464.2A%20Striping%20Standards%20for%20Major%20Highways_crop.png?itok=767JDWN6">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing striping standards for major highways</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing striping standards for three types of secondary highway segments." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20464.2B%20Striping%20Standards%20for%20Seconday%20Highways_Crop.png?itok=oG8nMGJZ">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing striping standards for three types of secondary highway segments.</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing the plan view of diamond interchanges for major and secondary highway segments." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20464.2C%20Diamond%20Interchange%20for%20Major%20and%20Secondary%20Highways_crop.png?itok=BSmMnTG_">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing the plan view of diamond interchanges for major and secondary highway segments.</figcaption>
</figure>
<hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and has been superseded by the text that follows.</li></ol><div><div><div id="_com_4"><p></p></div></div></div></div>
      </div></div>
