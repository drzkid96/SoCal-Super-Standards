---
title: "E 150 Legal Liability and Maintenance Responsibility"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-100-introduction-and-general-information-2be36ad5/">E 100 Introduction and General Information</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information/e-150-legal-liability-and-maintenance-responsibility">Official BOE section</a></p>

<div><div>
        <div><p>The property owner and the City assume responsibility for the maintenance of specific improvements lying within public dedications, private streets and easements. Either may be held liable for damages resulting from injuries incurred because of the negligent maintenance of improvements within the rights of way.</p><p>The information presented here is to acquaint the Designer with obligations to minimize liability claims or excessive maintenance costs.</p><p>For more specific details around street maintenance and legal liability, refer to the Bureau of Street Maintenance Manual and the City Attorney&#x27;s Office.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-37b1c5ea/">E 151 City Liability and Responsibility</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-0-b41c68f7/">E 152 Property Owner Liability and Responsibility</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-1-8060f65b/">E 153 Other Responsible Parties</a></li></ul>
