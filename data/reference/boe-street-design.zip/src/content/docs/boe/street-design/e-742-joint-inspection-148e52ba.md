---
title: "E 742 Joint Inspection"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection/e-742-joint-inspection">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Joint final inspections, arranged by the inspector, should be scheduled at least twenty-four hours in advance to ensure joint participation. A responsible engineer should be assigned to make the final joint inspection of the project.</p><p>For a small or uncomplicated project, the engineer should join the inspector in the job review. The engineer then signs the “Final Inspection Correction List” and receives a jointly signed copy.</p><p>For large, complex projects each engineer needs to jointly review only that portion of the project in which he is directly concerned. If the inspector has previously completed a list of corrections to be made by the contractor, and if there is no disagreement by the engineer, the engineer merely signs the list. he then receives a jointly signed copy. If the inspector has not completed his list, the engineer should make his own correction list. He should then keep one copy for himself and give one signed duplicate copy to the inspector prior to leaving the project site.</p><p>The engineer in making his correction list must use sound engineering judgment in his correction requirements. He should not make unreasonable demands or call attention to unimportant details or technicalities. Any unnecessarily stringent demands may result in higher bids on subsequent projects. All necessary explanations should be shown on the correction list.</p></div>
      </div></div>
