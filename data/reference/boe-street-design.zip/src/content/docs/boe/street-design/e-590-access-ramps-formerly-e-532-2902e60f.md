---
title: "E 590 Access Ramps (formerly E 532)"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-590-access-ramps-formerly-e-532">Official BOE section</a></p>

<div><div>
        <div><p>State law requires that sidewalks and curbs be accessible and usable <a>by people with disabilities</a><span> </span>. <span> </span>Accordingly, access ramps are necessary at street intersections and other pedestrian street crossings to provide a continuous usable route to places of public accommodations.</p><p>City policy relating to access ramps was established by the Board of Public Works on January 10, 1975 as follows:</p><ul><li>Access ramps shall be provided at all street intersections and corners where new curbs are installed or where curbs are substantially altered or repaired whether such work is being done with public or private funds.</li><li>Although the principal proponents of access ramps have been people with disabilities who use wheelchairs, people of all ages and abilities have been considered in formulating the City&#x27;s design criteria and standards: The design criteria and standards should be followed wherever possible.<span>  </span>However, because of the many variables involved, each street intersection is a special problem and requires the use of sound engineering judgment.</li></ul></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-8c6e65bc/">E 591 Design Criteria (formerly E 532.1)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-0-6ab97633/">E 592 Design Standards (formerly 532.2)</a></li></ul>
