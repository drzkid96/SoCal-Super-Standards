---
title: "E 200 Overview of Street Improvement Projects"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-overview-street-improvement-projects">Official BOE section</a></p>

<div><div>
        <div><p>To serve efficiently in the capacity of a street designer, the designer should have some knowledge of certain non-design functions in addition to those covered in the previous section The street designer may be called upon to help in the preparation of the list of street improvement projects to be included in the City budget. This involves a knowledge of the City street improvement policies, including the desirable extent of the street improvement (full improvement vs. stage improvement) and the preparation of an accurate preliminary project cost estimate. Since the above factors may influence the geometries, right of way, and other related items of the design as well as the workload of the design office, a brief discussion of these items will follow. (A more comprehensive treatment of the above aspects will be covered in Part C, Operations and Control, when this Part of the Manual is printed.)<sup>1</sup> Also included here are some typical calculations that are generally applicable and usually encountered by the street design office in making cost and quantity estimates.</p><hr><p>Footnotes</p><ol><li>The text in parenthesis is from the legacy Street Design Manual text and is no longer in use.</li></ol></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-210-street-classifications-and-network-concepts-4c8a1360/">E 210 Street Classifications and Network Concepts</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-220-financing-5a80427a/">E 220 Financing</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-230-street-improvement-policies-348b87cd/">E 230 Street Improvement Policies</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-240-calculations-and-problem-solutions-736a3a62/">E 240 Calculations and Problem Solutions</a></li></ul>
