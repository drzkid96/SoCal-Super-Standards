---
title: "E 143 Rights of City"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-140-fundamentals-real-property-street-design-purposes-d0bb5d41/">E 140 Fundamentals of Real Property for Street Design Purposes</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-100-introduction-and-general-information/e-140-fundamentals-real-property-street-design-5">Official BOE section</a> · City revision July 1, 1986</p>

<div><div>
        <div><p>The State has granted the City the power of EMINENT DOMAIN for purposes of CONDEMNATION. This power is the legal means by which the City may acquire private property for public use. The basic requirements for invoking the use of EMINENT DOMAIN procedures are:</p><ol><li>It must be shown that the property to be acquired is for public use, interest, convenience, or necessity; and</li><li>The property owner must be adequately compensated by the City for this acquisition.</li></ol><p>For the purposes of this Manual, it will be assumed that all Public Works projects are for the public&#x27;s use, and as such meet the requirements that permit the use of EMINENT DOMAIN procedures.</p></div>
      </div></div>
