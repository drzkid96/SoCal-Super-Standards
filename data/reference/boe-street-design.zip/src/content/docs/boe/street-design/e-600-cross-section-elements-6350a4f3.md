---
title: "E 600 Cross-Section Elements"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements">Official BOE section</a></p>

<div><div>
        <div><p>The various elements that go to make up a street, as well as the nomenclature of these elements, are discussed in the Sections and Subsections that follow.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-610-streets-fdc2b48b/">E 610 Streets</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-620-pavements-24c951c8/">E 620 Pavements</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-630-curbs-and-gutters-19d35d20/">E 630 Curbs and Gutters</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-640-concrete-gutters-8e4a12d9/">E 640 Concrete Gutters</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-650-borders-3f146405/">E 650 Borders</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-660-medians-17bb4fe7/">E 660 Medians</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-690-traffic-guides-and-barrier-installations-692a0ee6/">E 690 Traffic Guides and Barrier Installations</a></li></ul>
