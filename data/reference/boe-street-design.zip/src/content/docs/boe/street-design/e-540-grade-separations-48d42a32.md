---
title: "E 540 Grade Separations"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500 Design Criteria For Special Street Components and Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-540-grade-separations">Official BOE section</a></p>

<div><div>
        <div><p>Intersections fall into two broad classifications: intersections at grade and grade separations. the following discussion covers the location and design criteria of grade separations. A discussion of intersections at grade is presented in <a href="/SoCal-Super-Standards/boe/street-design/e-550-intersections-grade-1339d552/">Section E 550, Intersections At-Grade</a>.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-541-warrants-e496089a/">E 541 Warrants For Grade Separation</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-542-63468095/">E 542 Preliminary Design Considerations</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-543-overpass-4fa9b875/">E 543 Overpass Versus Underpass</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-544-design-ebac9cbc/">E 544 Design Criteria</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-545-146a3c37/">E 545 Temporary Detours</a></li></ul>
