---
title: "E 731 Prior To Advertising For Bids"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-730-changes-documents-cf1f966e/">E 730 Changes In Documents</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-730-changes-documents/e-731-prior-advertising-bids">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p><span>After the City Engineer signs the plans and before the City advertises for bids, any changes in design must be made to the plans. They must first go through the Division or District Engineer, then to the Engineer of Design for</span><span> </span><span>approval.</span></p><h4><span>E 731.1 Revisions of Plans</span></h4><p>Each sheet of each set of plans contains a “Revisions and Approvals” block. The “Revisions” portion contains columns headed Date, Description, and By (initials). The portion contains District or Division Engineer, City Engineer, and Date.</p><p>On the first sheet only, the description column is used to delineate by reference only the total changes on other sheets for that set of plans. Examples are Revised Sht. No.(s) . . ., Deleted Sht. No.(s) . . ., Added Sht. No.(s) . . ., etc. Also, if there are any delineation changes on sheet number one, brief descriptions of these changes are made. All sheets require the date that the change was made, revisions as outlined above, and either hand or mechanical lettering. The project engineer signs their initials opposite the change notation, the Division or District Engineer signs their name, and the City Engineer signs his name with the date of approval.</p></div>
      </div></div>
