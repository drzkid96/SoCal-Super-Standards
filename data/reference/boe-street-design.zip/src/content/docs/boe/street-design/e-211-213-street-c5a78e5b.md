---
title: "E 211-213 Street Classifications and Network Concepts"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-210-street-classifications-and-network-concepts-4c8a1360/">E 210 Street Classifications and Network Concepts</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-210-street-classifications/e-211-213-street">Official BOE section</a> · City revision August 6, 2025</p>

<div><div>
        <div><h2>E 211 Street Classifications</h2><h3>E 211.1 Mobility Plan 2035</h3><p>The State of California and the Los Angeles City Charter require that Los Angeles create and adopt a general plan. The <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> is one of the twelve elements of the City’s <a href="https://planning.lacity.gov/plans-policies/general-plan-overview">General Plan</a> and serves as a portion of the City’s Circulation Element. Its purpose is to establish a guide to the further development of a citywide transportation system which provides for the efficient movement of people and goods and balances the needs of all road users. The Mobility Plan 2035 establishes designated street classifications for arterial streets, scenic highways, divided streets, and modified street segments within the City (also mentioned in page 24 of the <a href="https://planning.lacity.gov/odocument/c9596f05-0f3a-4ada-93aa-e70bbde68b0b/Complete_Street_Design_Guide.pdf">Complete Street Design Guide</a>). The Mobility Plan 2035 also identifies a subset of streets for Enhanced Networks that are intended to prioritize the movement and travel of people using specific mode(s) of transportation.</p><h4>E 211.11 Citywide General Plan Circulation System</h4><p>The Mobility Plan 2035 contains Citywide General Plan Circulation System maps that designate rights-of-way into the following classifications:</p><ul><li>Arterial Streets,<ul><li>Boulevard I</li><li>Boulevard II</li><li>Avenue I</li><li>Avenue II</li><li>Avenue III</li></ul></li><li>Divided Streets</li><li>Modified Street Segments (also inventoried in Appendix F of the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>), and</li><li>Scenic Highways (also inventoried in Appendix B of the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>). </li></ul><h5>E 211.111 Arterial Streets</h5><p>Arterial streets are typically characterized by the presence of commercial uses, but single-family and multi-family residential uses may also be located along existing arterial streets. The table below summarizes the previous street classification designations and corresponding dimensions from before the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> and <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a> were adopted and approved in 2015 and the current street classification designations and corresponding dimensions for arterial streets in the City of Los Angeles.</p><div><table><colgroup><col><col><col><col></colgroup><caption>Previous and Current Designations of Arterial Streets</caption><thead><tr><th scope="col"><p>Previous Designation (pre-2015)</p></th><th scope="col"><p>Previous Designated Dimensions (Right-of-way / Roadway Width)</p></th><th scope="col"><p>Current Designation(s)</p></th><th scope="col"><p>Current Designated Dimensions (Right-of-way / Roadway Width)</p></th></tr></thead><tbody><tr><td><p>Major Highway Class I</p></td><td><p>(126&#x27;/102&#x27;)</p></td><td><p>Boulevard I</p></td><td><p>(136&#x27;/100&#x27;)</p></td></tr><tr><td><p>Major Highway Class II</p></td><td><p>(104&#x27;/80&#x27;)</p></td><td><p>Boulevard II</p></td><td><p>(110&#x27;/80&#x27;)</p></td></tr><tr><td rowspan="3"><p>Secondary Highway</p></td><td rowspan="3"><p>(90&#x27;/70&#x27;)</p></td><td><p>Avenue I</p></td><td><p>(100&#x27;/70&#x27;)</p></td></tr><tr><td><p>Avenue II</p></td><td><p>(86&#x27;/56&#x27;)</p></td></tr><tr><td><p>Avenue III</p></td><td><p>(72&#x27;/46&#x27;)</p></td></tr></tbody></table></div><h5>E 211.112 Divided Streets</h5><p>Due to their unique character and dimensions, all streets designated as divided are considered to have met their street standards and dedication shall be no more than is necessary to bring the abutting sidewalk dimension into compliance with the street standard. (Note 10 in <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a>)</p><h5>E 211.113 Modified Segments</h5><p>Due to the history and variety of street types and land use contexts in the City, many existing streets may not match the standard right-of-way, roadway, and/or border dimensions set in <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a>. In many such instances, the General Plan (<a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> or Community Plan) has assigned a street a “Modified” designation in front of its classification, such as “Modified Avenue I.” These street segments are inventoried in Appendix F of the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>. For streets with a Modified designation, the General Plan specifies modified dimensions for the overall right-of-way, roadway, border, or all. In some cases, a special cross-section is specified. The modified dimensions and cross-sections are available in NavigateLA.</p><h5>E 211.114 Scenic Highways</h5><p>Scenic Highways are identified in the Citywide <a href="https://planning.lacity.gov/plans-policies/general-plan-overview">General Plan</a> Circulation System maps as well as in a table in Appendix B of the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>. Scenic Highways within the City of Los Angeles have special controls for protection and enhancement of scenic resources. The Mobility Plan 2035 envisions that Corridor Plans for each designated Scenic Highway should be prepared in accordance with each corridor’s individual character or concept. These Corridor Plans may be incorporated into specific plans or district plan ordinances. In the absence of such adopted Scenic Corridor Plans, the interim Scenic Highway Guidelines were established as part of the Mobility Plan 2035 (see Appendix B of the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>). </p><h4>E 211.12 Standard Street Dimensions</h4><p>The Standard Street Dimensions (<a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1 - Standard Street Dimensions</a>) set the minimum width and improvement standards for all classes of public and private streets and alleys. <a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-122100">LAMC Section 17.05</a> establishes a Street Standards Committee (Committee) who is responsible for recommending changes to minimum width and improvement standards for all classes of public and private streets and alleys and submitting to the City Planning Commission for their consideration, approval, and adoption.</p><h3>E 211.2 Community Plans (Land Use Element)</h3><p>Together the City’s 34 Community Plans (which make up the Land Use Element of the <a href="https://planning.lacity.gov/plans-policies/general-plan-overview">General Plan)</a> establish neighborhood-specific goals and implementation strategies to achieve the broad objectives laid out in the City’s General Plan.</p><p>In addition to the arterial streets (Boulevards and Avenues) that are designated in the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a>, each Community Plan designates certain streets as Collector Streets. Community Plans may also provide specific street cross-sections for Modified Streets.</p><p>Each Community Plan’s Circulation Map shows Local Streets and other street types for information only. Collector, Local, and other street types are considered non-arterial streets.</p><p>The table below summarizes the street classification designations and corresponding dimensions from before the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> and <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a> were adopted and approved in 2015 and the current designations and corresponding dimensions for Collector streets in the City of Los Angeles.</p><div><table><colgroup><col><col><col><col></colgroup><caption>Previous and Current Designations of Collector Streets</caption><thead><tr><th scope="col"><p>Previous Designation (pre-2015)</p></th><th scope="col"><p>Previous Designated Dimensions (Right-of-way / Roadway Width)</p></th><th scope="col"><p>Current Designation(s)</p></th><th scope="col"><p>Current Designated Dimensions (Right-of-way / Roadway Width)</p></th></tr></thead><tbody><tr><td><p>Collector Street</p></td><td><p>(64&#x27;/44&#x27;)</p></td><td><p>Collector Street</p></td><td><p>(66&#x27;/40&#x27;)</p></td></tr><tr><td><p>Industrial Collector Street</p></td><td><p>(64&#x27;/48&#x27;)</p></td><td><p>Industrial Collector Street</p></td><td><p>(68&#x27;/48&#x27;)</p></td></tr><tr><td><p>Hillside Collector</p></td><td><p>(50&#x27;/40&#x27;)</p></td><td><p>Hillside Collector</p></td><td><p>(50&#x27;/40&#x27;)</p></td></tr></tbody></table></div><p>The Project Developer and/or Project Engineer should investigate whether their street is subject to localized street standards and/or guidelines that have been adopted within a Community Plan or Specific Plan to address community specific transportation needs. </p><h3>E 211.3 Select Streets</h3><p>For the purposes of assessing roadway pavement needs, the Bureau of Street Services identifies streets requiring a thicker pavement design to accommodate greater traffic loads called  Select Streets. The Bureau of Street Services considers any street not designated as a Select Street to be a “local street”. The Bureau of Street Services shall maintain a public record of its street designations. (Reference: <a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-157373">Los Angeles Municipal Code Section 62.06. Establishment of a Street Damage Restoration Fee</a>)</p><p>Generally, Select Streets are streets designated by the Mobility Plan as a Boulevard or Avenue street classification, also known as arterial streets. </p><h3>E 211.4 Local and Other Public Rights-of-Way</h3><p>Local streets connect road users to local residential neighborhoods or industrial areas through a more fine-grain street network than the arterial streets. The table below summarizes the local street classification designations and corresponding dimensions from before the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> and <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a> were adopted and approved in 2015 and the current designations and corresponding dimensions for these types of streets in the City of Los Angeles.</p><div><table><colgroup><col><col><col><col></colgroup><caption>Previous and Current Designations for Local Streets</caption><thead><tr><th scope="col"><p>Previous Designation (pre-2015)</p></th><th scope="col"><p>Previous Designated Dimensions (Right-of-way / Roadway Width)</p></th><th scope="col"><p>Current Designation(s)</p></th><th scope="col"><p>Current Designated Dimensions (Right-of-way / Roadway Width)</p></th></tr></thead><tbody><tr><td rowspan="2"><p>Local Street</p></td><td rowspan="2"><p>(60&#x27;/36&#x27;)</p></td><td><p>Local Standard</p></td><td><p>(60&#x27;/36&#x27;)</p></td></tr><tr><td><p>Local Limited</p></td><td><p>(50&#x27;/30&#x27;)</p></td></tr><tr><td><p>Industrial Local</p></td><td><p>(60&#x27;/44&#x27;)</p></td><td><p>Industrial Local</p></td><td><p>(64&#x27;/44&#x27;)</p></td></tr><tr><td><p>Hillside Local</p></td><td><p>(44&#x27;/36&#x27;)</p></td><td><p>Hillside Local</p></td><td><p>(44&#x27;/36&#x27;)</p></td></tr><tr><td><p>Hillside Limited Standard</p></td><td><p>(36&#x27;/28&#x27;)</p></td><td><p>Hillside Limited Standard</p></td><td><p>(36&#x27;/28&#x27;)</p></td></tr><tr><td rowspan="2"><p>Service Road</p></td><td rowspan="2"><p>20&#x27;</p></td><td><p>One-Way Service Road - Adjoining Arterial Streets</p></td><td><p>(26&#x27; or 32&#x27;*/12&#x27; or 18&#x27;*)</p></td></tr><tr><td><p>Bi-Directional Service Road - Adjoining Arterial Streets</p></td><td><p>(34&#x27; or 42&#x27;*/ 20&#x27; or 28&#x27;*)</p></td></tr></tbody></table></div><p>*<span>with parking on one side</span></p><h4>E 211.41 Other Public Rights-of-Way</h4><p>Streets and other public rights-of-way offer opportunities to provide for unique access conditions. The table below summarizes the street classification designations and corresponding dimensions from before the <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> and <a href="https://apps.engineering.lacity.gov/techdocs/stdplans/s-400/S-470-1_20151021_150849.pdf">Standard Plan S-470-1</a> were adopted and approved in 2015 and the current designations and corresponding dimensions for these unique types of streets in the City of Los Angeles.</p><div><table><colgroup><col><col><col><col></colgroup><caption>Previous and Current Designations Other Public Rights-of-Way</caption><thead><tr><th scope="col"><p>Previous Designation (pre-2015)</p></th><th scope="col"><p>Previous Designated Dimensions (Right-of-way / Roadway Width)</p></th><th scope="col"><p>Current Designation(s)</p></th><th scope="col"><p>Current Designated Dimensions (Right-of-way / Roadway Width)</p></th></tr></thead><tbody><tr><td><p>Standard Walkway</p></td><td><p>10&#x27; minimum walkway width</p></td><td><p>Pedestrian Walkway</p></td><td><p>10&#x27; - 25&#x27; walkway width</p></td></tr><tr><td colspan="2"><p>(New Designation)</p></td><td><p>Shared Street</p></td><td><p>17&#x27; minimum width</p></td></tr><tr><td colspan="2"><p>(New Designation)</p></td><td><p>Alley</p></td><td><p>20&#x27; minimum width</p></td></tr></tbody></table></div><h4>E 211.42 Proposed Streets</h4><p>The potential future location for proposed streets are identified in the Community Plan maps to improve and/or complement existing local circulation. Proposed streets are depicted in the Community Plans, consistent with <a href="https://planning.lacity.gov/plans-policies/general-plan-overview">General Plan</a> standards and criteria.</p><h2>E 212 Mobility Plan 2035 Networks</h2><p>The City&#x27;s <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> includes Network Concept maps (Chapter 6, PDF page 153) that identify a subset of streets for different modal priorities. The system consists of seven Network(s) chosen to prioritize use and travel by specific modes of transportation.  The Networks are updated regularly through the Community Plan process. The most up-to-date versions of the Networks can be found on NavigateLA under the City Planning layer group (Refer to Section E 213.3 Verifying Mobility Plan Network). A street may be assigned one or more of the following Network designations: </p><ol><li><strong>Pedestrian Enhanced Districts (PEDs):</strong> Segments on arterial streets where pedestrian improvements could be prioritized to provide better walking connections to and from the major destinations within communities.</li><li><strong>Bicycle Enhanced Network (BEN)</strong><ol><li><strong>Tier 1 Protected Bicycle Lanes:</strong> Streets intended to prioritize bicycle travel through the provision of bicycle facilities with physical separation (Class IV) separating bicyclists from motorists and other corresponding improvements.</li><li><strong>BEN Segments from the Neighborhood Enhanced Network (NEN)</strong> (e.g., Tier 1 - Neighborhood Enhanced Network): Slow speed, locally serving streets intended to provide connections within the Tier 1 BEN Protected Bicycle Lanes system through the provision of bicycle-related safety enhancements.</li></ol></li><li><strong>Bicycle Lane Network (BLN)</strong><ol><li><strong>Tier 2 - Bicycle Lane</strong>: Streets intended to facilitate bicycle travel on striped bicycle lanes (Class II), generally envisioned to be implemented by 2035.</li><li><strong>Tier 3 - Bicycle Lane</strong>: Streets intended to facilitate bicycle travel on striped bicycle lanes (Class II), generally envisioned to be implemented after 2035, due to right-of-way constraints or other feasibility challenges.</li></ol></li><li><strong>Transit Enhanced Network (TEN)</strong>: Streets intended to support transit service providers operating within the city (e.g., Metro, LADOT Transit) through the provision of transit-priority facilities and/or improvements that serve transit operations.<ol><li><strong>Moderate</strong>: Streets intended to support transit service by providing signal improvements and bus stop amenities.</li><li><strong>Moderate-Plus</strong>: Streets intended to support transit operations during peak travel periods by providing peak-hour bus lanes and corresponding improvements.</li><li><strong>Comprehensive</strong>: Streets intended to support transit operations all day by providing full-time bus lanes and corresponding improvements.</li></ol></li><li><strong>Vehicle Enhanced Network (VEN)</strong>: Arterial streets intended to facilitate vehicular access to the regional freeway system.</li><li><strong>Neighborhood Enhanced Network (NEN)</strong><ol><li><strong>Tier 1 - Neighborhood Enhanced Network</strong>: See “BEN Segments from the Neighborhood Enhanced Network” above.</li><li><strong>Tier 2 - Neighborhood Enhanced Network</strong>: Slow speed, locally serving streets intended to support slower-moving bicycle and pedestrian-related activity through the provision of safety enhancements.</li></ol></li><li><strong>Goods Movement Map</strong>: Streets or State facilities (highways, freeways) that contribute to the region’s movement of goods within the City. </li></ol><p>On April 9, 2024, the Los Angeles Safe Streets for All Initiative (Measure HLA, <a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-422786#:~:text=%C2%A0%C2%A0%C2%A0(a)-,Definitions.,-For%20the%20purposes">LAMC Section 85.11(a)</a>) ordinance took effect to require the City to implement its <a href="https://planning.lacity.gov/odocument/523f2a95-9d72-41d7-aba5-1972f84c1d36/Mobility_Plan_2035.pdf">Mobility Plan 2035</a> Network Concepts whenever the City carries out certain improvement projects. For more information, refer to the <a href="https://planning.lacity.gov/odocument/6fc05193-c065-4d18-834d-ead8a8fe1f53/HLA_Standard_Elements_Table.pdf">HLA Standard Elements Table - A Supplemental Document to the Complete Streets Design Guide</a>. </p><h2>E 213 Procedure to Identify Street Classifications and Other Policies</h2><p>For capital projects sponsored and delivered by the City, the person responsible for delivering a specific project, or the Project Manager, must identify the street classification(s), Network(s), and other policies applicable to the project’s design during the initiation and planning stages. For capital projects sponsored and delivered by government agencies or private developments permitted by the City, the Bureau of Engineering staff tasked with plan checking and/or permitting is responsible for verifying that the permit applicant’s design plans conform with the applicable street designation(s) and other applicable policies, and not preclude relevant Mobility Networks, prior to approving an application.</p><h3>E 213.1 Verifying Street Classification and Other Policies</h3><p>To confirm the designated Street Classification and other policies for a street or public right-of-way segment, follow this procedure:</p><ol><li>Visit <a href="https://navigatela.lacity.org/navigatela/">NavigateLA</a>, a web-based mapping application that delivers maps and reports based on data supplied by various City departments.</li><li>Use the search bar on the top-right corner to locate your street by entering the closest address or street intersection.</li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA webpage with the search bar circled in red." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Navigate%20LA%20search%20bar.jpg?itok=a9-U3elW">



      </div>
          </div>

</div>
<ol start="3"><li>Click on a street segment and a Report Window will pop up and display the street classification next to “Designation,” as well as the accompanying right-of-way width and roadway width dimensions below. Additional information is listed regarding whether the street is designated as a divided street or scenic highway or has a special cross-section.</li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA webpage with selected street segment designation circled in red." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Street%20Designation.jpg?itok=FbXWssr6">



      </div>
          </div>

</div>
<h3>E 213.2 Verifying Mobility Plan Network</h3><p><a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-422786#:~:text=%C2%A0%C2%A0%C2%A0(a)-,Definitions.,-For%20the%20purposes">LAMC Section 85.11(a)</a> (Measure HLA) requirements apply to an “Improvement” constructed by the City on a “Mobility Plan Street”, which shall be referred to as a “Mobility Plan Project” (all as defined in <a href="https://codelibrary.amlegal.com/codes/los_angeles/latest/lamc/0-0-0-422786#:~:text=%C2%A0%C2%A0%C2%A0(a)-,Definitions.,-For%20the%20purposes">LAMC Section 85.11(a)</a>). To confirm whether a street or public right-of-way segment is identified on one or more Mobility Plan Networks, follow this procedure:</p><ol><li>To view the Mobility Plan Networks in NavigateLA, go to the Table of Contents and navigate to the &quot;City Planning Department&quot; group of layers.</li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA search bar with the Table of Contents button circled in red. Table of Contents screenshot with City Planning Department circled in red. Red arrow showing expanded section." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Open%20Table%20of%20Contents.jpg?itok=6xP4b4tv">



      </div>
          </div>

</div>
<ol start="2"><li>Ensure the &quot;Mobility Plan Networks&quot; group of layers is turned on. Expand the layer group to toggle individual Networks on and off.<ol><li>Questions about whether a Network applies to a right-of-way should be emailed to the LA City Planning Mobility Team at <a href="mailto:planning.mobility@lacity.org">planning.mobility@lacity.org</a> (cc: LADOT Transportation Planning and Policy at <a href="mailto:ladot.tpp@lacity.org">ladot.tpp@lacity.org</a>). </li></ol></li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA Table of Contents with Mobility Plan Networks section expanded. All networks selected." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Select%20All%20Mobility%20Plan%20Networks.jpg?itok=QHva3jOO">



      </div>
          </div>

</div>
<ol start="3"><li>To ensure selection of all Network layers use the Tools menu to select the Navigation Tool “Select Features By Shape”. This tool allows a custom selection based on the drawing made using the mouse. Click on the page icon to the right of the Layer name in the Results window to view the Report.</li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA search bar with the toolbar button circled in red. NavigateLA toolbar with the Select Features by Shape button circled in red." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Toolbar.jpg?itok=uouGcJT9">



      </div>
          </div>

</div>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA webpage with drawn red circle selecting all network layers. Arrow pointing to Results window. Red circle indicating Report button next to Layer name." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Select%20Feature.jpg?itok=NjofGpg9">



      </div>
          </div>

</div>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="NavigateLA webpage with the Report window circled in red." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/View%20Report.jpg?itok=xl_sQ0bV">



      </div>
          </div>

</div>
<ol start="4"><li>Measure HLA note: If the City plans to do work in a segment of City-owned public right-of-way that overlaps with a Mobility Plan Network, it is the Project Manager’s responsibility to ensure that the project is compliant with Measure HLA. This includes determining whether the project qualifies as an Improvement, calculating the length of the Improvement, reviewing the HLA Standard Elements Table for standard and optional design elements, and (if required) submitting the project to the <a href="https://mp35implementation.lacity.gov/">Mobility Plan Dashboard</a> for review and posting.</li></ol><div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Mobility Plan Dashboard webpage" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/large/public/2025-07/Mobility%20Plan%20Dashboard.jpg?itok=tITXPFdS">



      </div>
          </div>

</div>
</div>
      </div></div>
