---
title: "E 222 Private Funds"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-220-financing-5a80427a/">E 220 Financing</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-220-financing/e-222-private-funds">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Funds from private individuals or corporations for the purpose of street construction are referred to as private funds. Projects using these funds are usually initiated by the property owners by petition by Council resolution under the Assessment Proceedings or the 1911 Act of the State’s Streets and Highways Code, or by the 1941 Los Angeles City Ordinance. Private funds are also used for construction of projects by permit and under the proceedings as outlined under various Los Angeles City Ordinances, such as the Subdivision, Parcel Map, Highway Dedication, and Improvement (R-3), and Zone Changes and Conditional Uses. In making these improvements, the items designated for payment with private funds are indicated in the above regulations and under <a href="/SoCal-Super-Standards/boe/street-design/e-231-private-7458cf3c/">E 231, Private Development</a> and <a href="/SoCal-Super-Standards/boe/street-design/e-232-select-d935408d/#:~:text=E%20232.2%20ASSESSMENT%20PROJECTS">E 232.2, Assessment Projects</a>.</p></div>
      </div></div>
