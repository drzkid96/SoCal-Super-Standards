---
title: "E 511 Location"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-511-location">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Provisions should be made for the location of alleys in the rear of all residential lots fronting on major and secondary highways. <a>They should also be included in new subdivisions where commercial or industrial zoning use is indicated, as per Ordinance No. 122,064, more commonly known as the “Subdivision  Ordinance”, and Ordinance No. 122,312, the “Lot-Split Ordinance.”</a></p><p>Figure E 611 shows a typical alley layout with a complete traffic circulatory system within a given block, where vehicles need not enter directly from an alley into a primary or secondary highway. <a>Also, refer to the discussion of alleys in </a>Section <a href="/SoCal-Super-Standards/boe/street-design/e-362-88999c2f/">E 362, Access Control</a><a>, and </a>Section <a href="/SoCal-Super-Standards/boe/street-design/e-651-block-corner-property-lines-b56f44ce/">E 651, Block Corner Property Lines</a><a>. See Figure E 611.</a></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing typical alley alignments" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-08/E%20500%20Fig%20611%20Site%20Plan%20on%20Alley%20Alignments.PNG?itok=8hQ4ADih">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing typical alley alignments</figcaption>
</figure>
</div>
      </div></div>
