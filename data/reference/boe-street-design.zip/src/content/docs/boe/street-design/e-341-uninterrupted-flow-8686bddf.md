---
title: "E 341 Uninterrupted Flow"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-340-highway-street-capacity-cff5a112/">E 340 Highway (Street) Capacity</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-340-highway-street-capacity/e-341-uninterrupted-flow">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>A free-flowing freeway or certain multilane arterial highways have the highest capacity, and this capacity can be more readily and precisely determined than that of most other local or city streets. The <em>Highway Capacity Manual</em>, Table No. 5, Section E 020F(3b), lists the basic capacity for multi-lane highways at 2,000 passenger ears per lane per hour:, the practical capacity for urban conditions (35-40 mph) is 1,500 passenger cars per lane per hour and for rural conditions (45-50 mph) is 1,000 passenger cars per lane per hour. If the highway standards are below normal, the design deficiencies which tend to reduce capacity are:</p><ol><li>Lane widths less than 11 feet.</li><li>Inadequate or marginal lateral clearance to vertical obstructions, such as retaining walls, poles, parked cars, etc.</li><li>Absence or inadequacy of shoulders.</li><li>Use by commercial vehicles.</li><li>Location and design of interchange facilities, such as poorly designed or inadequate acceleration or deceleration lanes.</li><li>The profile and alignment, where substandard design is used for providing sight distance and grades.</li><li>Driveway access frequency.</li><li>Signal spacing and timing.</li></ol></div>
      </div></div>
