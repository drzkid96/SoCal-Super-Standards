---
title: "E 390 Grade Design Policy"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-390-grade-design-policy">Official BOE section</a></p>

<div><div>
        <div><p>At this point some of the specific design criteria used for the City’s grade design policy are introduced. Further application of these design criteria is also presented for the specific types of projects listed in Chapter <a href="/SoCal-Super-Standards/boe/street-design/e-500-design-criteria-special-street-components-and-projects-dfc15668/">E 500, Design Criteria for Special Street Components and Projects</a>. Other design details may be found under Section <a href="/SoCal-Super-Standards/boe/street-design/e-640-concrete-gutters-8e4a12d9/">E 640, Concrete Gutters</a>, <a href="/SoCal-Super-Standards/boe/street-design/e-560-remodeling-improved-streets-dc4cf068/">E 560, Remodeling Improved Streets</a>, and in other sections of this Part of the Manual.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-391-design-details-97799cee/">E 391 Design Details</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-392-intersection-drainage-280f3682/">E 392 Intersection Drainage</a></li></ul>
