---
title: "Historical References"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-210-street-classifications-and-network-concepts-4c8a1360/">E 210 Street Classifications and Network Concepts</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-general-design-street-improvement-projects/e-210-street-classifications/historical-references">Official BOE section</a> · City revision August 6, 2025</p>

<div><div>
        <div><p>This document contains files that serve as historical references for the current content.</p></div>
      </div><div>
              <div>
          <span><span><span></span></span><span><a title="Open image in new window" href="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/documents/S-470-0.tif">S-470-0 (1999-2015)</a></span></span>
        </div>
              <div>
          <span><span><span></span></span><span><a title="Open image in new window" href="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/documents/B-3695.tif">B-3695 (1962-1969)</a></span></span>
        </div>
              <div>
          <span><span><span></span></span><span><a title="Open image in new window" href="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/documents/D-22549.tif">D-22549 (1969-1999)</a></span></span>
        </div>
              <div>
          <span><span><span></span></span><span><a title="Open file in new window" href="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/documents/E200-New-General%20Design.pdf">E 200 General Design (1970)</a></span></span>
        </div>
          </div></div>
