---
title: "E 440 Sight Distance"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-400-general-roadway-design-elements-f5b07ac0/">E 400 General Roadway Design Elements</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-400-general-roadway-design-elements/e-440-sight-distance">Official BOE section</a></p>

<div><div>
        <div><p>A primary consideration in the design of a highway is the arranging of the geometric elements to obtain adequate sight distance for safe and efficient operation. Sight distance should be considered in the preliminary design stages, when the horizontal and vertical alignments are still subject to adjustment.</p><p>Three items will be covered under the subject of sight distance:</p><ol><li>The distance required for stopping, applicable on all highways.</li><li>The distance required for overtaking and passing vehicles, applicable on two-lane and three-lane highways.</li><li>The criteria for measuring these distances in the design of horizontal and vertical alignment.</li></ol><p>The figures and equations presented will use the following notations in addition to those previously presented under horizontal and vertical alignment discussion:</p><p>S = Sight distance, stopping distance, or stopping sight distance in feet.</p><p>V = Design speed in miles per hour.</p><p>L = Length of vertical curve in feet (see figures and equations for other specific L designations).</p><p>a = Vertical acceleration in feet per second, per second</p><p>R= L/A = Minimum radius of vertical curve in feet (see figures and equations for other specific R designations).</p><p>A = Algebraic difference of grades in percent (see figures and equations for other specific A designations).</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-441-criteria-measuring-9e52aec6/">E 441 Criteria for Measuring</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-442-safe-stopping-distances-0dd10e1d/">E 442 Safe Stopping Distances</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-443-passing-sight-distance-two-lane-480de75e/">E 443 Passing Sight Distance For Two-Lane Highways</a></li></ul>
