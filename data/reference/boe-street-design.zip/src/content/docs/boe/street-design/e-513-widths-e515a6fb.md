---
title: "E 513 Widths"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-513-widths">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Ordinance No. 122,064, the “Subdivision Ordinance”, specifies that all alleys in new subdivisions should be 20 feet in width and alleys abutting industrial zoning 30 feet in width.</p><p>A design investigation should also be made for the widening of substandard width existing alleys. If it is not economically feasible to widen these alleys to standard widths, any lesser degree of widening that is practical should be considered.  </p></div>
      </div></div>
