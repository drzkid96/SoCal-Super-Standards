---
title: "E 240 Calculations and Problem Solutions"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-200-overview-street-improvement-projects-4d26d94a/">E 200 Overview of Street Improvement Projects</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-200-overview-street-improvement-projects/e-240-calculations-and-problem-solutions">Official BOE section</a></p>

<div><div>
        <div><p>This section includes various calculations and criteria used in preparing engineering cost estimates, earthwork computations, and software applications used for typical problems in street design.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-241-4498616b/">E 241 Cost Estimates</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-242-88ff26b6/">E 242 Geotechnical Report</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-243-0-793230d2/">E 243 CADD Platforms and Standards</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-242-0-3955cd86/">E 242 Earthwork Computations (Superseded)</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-243-9dfc1c55/">E 243 Electronic Computer Applications (Superseded)</a></li></ul>
