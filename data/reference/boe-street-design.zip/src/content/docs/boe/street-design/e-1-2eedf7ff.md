---
title: "E 523 Elbow Curves"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-520-cul-de-sacs-and-elbow-curves-1eb455a8/">E 520 Cul-de-Sacs and Elbow Curves</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-520-cul-de-sacs-and-elbow-curves/e-1">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>It Is desirable to design hillside and local streets to maintain a vehicular speed of 25 miles per hour. Therefore, where L-shaped intersections or sharp curves are encountered, the minimum horizontal radius that may be used is 380 feet for flat streets and 132 feet for hillside streets. <a>In those cases where a 132-foot centerline radius is used and where the radius is immediately preceded by a tangent section of more than 350 feet or a downgrade more than 10 percent, an elbow curve (flared curve) should be provided</a>. This elbow curve should be introduced at the vicinity of the acute alignment change.</p><p>The elbow curve may also be used to allow for increasing the frontage of adjacent lots where it is necessary to meet requirements of the Municipal Code. The widening of the curve is accomplished by increasing the outer property line radius by a maximum of 10 feet. The formula for determining this radius is:</p><p>C.L. radius of the street $+\frac{W}{2}+10&#x27;=r$</p><p>For example:</p><p>$132&#x27;+\frac{44&#x27;}{2}+10&#x27;=164&#x27;$</p><p>Therefore, the outer property line radius would be 164 feet. See Figure E 623, below.</p><p>Any deviations from the above requirements should be approved by the Division or District Engineer.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagram showing various elbow curve dimensions for hillside streets." src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_xl/public/2024-08/E%20500%20Fig%20623%20Elbow%20Curve%20for%20Hillside%20Street.PNG?itok=9xeos-mi">



      </div>
          </div>

</div>

<figcaption>Illustrative diagram showing various elbow curve dimensions for hillside streets.</figcaption>
</figure>
</div>
      </div></div>
