---
title: "E 541 Warrants For Grade Separation"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-540-grade-separations-48d42a32/">E 540 Grade Separations</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-540-grade-separations/e-541-warrants">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>In justifying the use of a grade separation, consideration is given to the type and volume of traffic, topography, available right of way, number of accidents, and economic costs. Due to the high cost, the City has limited its use of grade separations to the intersections of railroads with major and secondary highways. As basic guides for determining the need for railway grade separations, one or both of the following criteria may be used:</p><ol><li>When the average daily traffic times the number of trains equals 80,000 with at least 8 trains per day.</li><li>When there has been one accident per year during each of the last five years in which a train and a motor vehicle have been involved.</li></ol><p>The final judgment as to the need of a railway grade separation should consider the characteristics of the terrain, the existing surrounding improvements, and economic feasibility. <span> </span>Since the funds available are limited and there is a need and justification for these structures throughout the City, a priority list for the construction of these projects has been established. <span> </span>This list is subject to change, as are the existing traffic conditions and fund availability.</p></div>
      </div></div>
