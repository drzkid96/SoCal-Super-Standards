---
title: "E 744 Changes Prior To Final Acceptance"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-740-final-inspection-cd89cbf1/">E 740 Final Inspection</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-700-new-project-construction/e-740-final-inspection/e-744-changes-prior-final-acceptance">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>Occasionally, after the project has been constructed, additional facilities not previously anticipated may be required to provide a satisfactory job. The Bureau of Contract Administration, before accepting the project completion, should be notified of this pending work by the engineer making the change. See <a href="/SoCal-Super-Standards/boe/street-design/e-733-after-contract-awarded-4c363952/#:~:text=E%20733.1%20Change%20Orders"><u>Subsection E 733.1, Change Orders</u></a>. In addition, where these changes affect more than one office, the other affected offices should be notified. Each of these offices should satisfy itself that the work has been completed in accordance with the City’s standards.</p></div>
      </div></div>
