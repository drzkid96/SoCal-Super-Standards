---
title: "E 631 Structural Types and Uses"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-630-curbs-and-gutters-19d35d20/">E 630 Curbs and Gutters</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-600-cross-section-elements/e-630-curbs-and-gutters/e-631-structural-types-and-uses">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The structural types of curbs used depend on tire proposed curb location, the type of anticipated traffic, and drainage and economic considerations. The curb types may be further classified as to permanent or temporary use; barrier or mountable; and formed, rolled, or extruded.</p><h3><span>E </span>631.1 Permanent Curbs</h3><p>Permanent curbs of the barrier or the mountable type are constructed of portland cement concrete (PCC).<span> </span>There are two types of barrier curb.<span> </span>One type is constructed by pouring the PCC into prepared forms on an unimproved portion of the street; the details of construction of the Permanent Barrier Type “A”, “B”, and “C” are shown on Figure E 431.1. The other type is constructed by extruding the PCC directly onto the existing pavement surface. Typical sections of the permanent extruded and mountable type curbs are shown on Figures E 431A and E 431B.</p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing different types of curb and gutter" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20431.1%20Types%20of%20Curbs%20and%20Gutter_crop.png?itok=a1PHajO-">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing different types of curb and gutter</figcaption>
</figure>
<p></p><figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing special curbs and berms " src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20431A%20Special%20Curbs%20and%20Berms_Crop.png?itok=n3NDdUQ3">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing special curbs and berms</figcaption>
</figure>
<figure>
<div>
  
  


  <div>
    <div>Image</div>
              <div>
          


    

<img alt="Illustrative diagrams showing sections of special curb types" src="https://completestreetdesignmanual.engineering.lacity.gov/sites/street_design/files/styles/cke_media_resize_large/public/2024-10/E%20600%20Fig%20431B%20Special%20Curbs_Crop.png?itok=GSxy8MnZ">



      </div>
          </div>

</div>

<figcaption>Illustrative diagrams showing sections of special curb types</figcaption>
</figure>
<h4>E 631.11 Barrier Curbs</h4><p>Curbs that will prevent or tend to prevent vehicles from mounting them are referred to as barrier curbs.</p><h4>E 631.111 Type “A” Light Curb</h4><p>This is used for hillside and residential areas where only low volumes of vehicular traffic are expected. It is usually constructed abutting the existing gutter or, when constructed with new gutter, is not poured monolithically with the gutter.</p><p>It is not desirable to use this curb where dry-weather flow is anticipated unless concrete gutter is also provided.</p><h4><span>E <strong>631.112 </strong>Type “B” Heavy <strong>Curb</strong></span></h4><p>This is of heavier construction than Type “A” Light Curb and may be used on streets subject to high volumes of vehicular traffic. It is also used for median strips and channelization islands. As with Type</p><p>“A” Light Curb, concrete gutter should be used with Type “B” Heavy Curb where dry-weather flow is anticipated.</p><h4><span>E 631.113 Type “C”  Integral Concrete  Curb and Concrete Gutter</span></h4><p><span>Type “C” Concrete Curb poured integrally with concrete gutter or concrete pavement is normally used for most street improvement projects. This type of curb is constructed more economically than the separate construction or curb and gutter. In addition, it forms a more stable unit against vehicular impact and seepage of dry-weather flow under the curb and gutter.</span></p><h4>E 631.114 Extruded or Doweled Curbs</h4><p>Doweled or glued curbs, extruded curbs, or a combination of these types of concrete curbs may be placed directly on existing pavement.<span>  </span>See Figure E 431A Type “C” or “D” (mountable) may be used for doweled curb. See Figure<span>  </span>E<span> </span>431B.<span>  </span>Since this type of construction makes it unnecessary to remove the pavement, it is particularly suitable and economical for construction of median strips and traffic islands.<span>  </span>However, before this type of curb is used, a design study should be made to ensure that there is no dry-weather flow and that the existing pavement, grade, cross-section, and crown meet the City’s design standards.</p><h3><span>E 631.12 Mountable Curbs</span></h3><p><span>Mountable type </span><span>concrete curbs should use the Type “C” Integral </span><span>Curb and Gutter. See Figures E 431B and E 431.1. These curbs have a limited use in City</span><span> </span><span>streets. </span><span>They are generally restricted to landscaped portions of median strips, traffic islands, and shoulders, where they act as partial barriers to normal </span><span>vehicular traffic and are readily mountable by emergency or out-of-control vehicles. See </span><a href="/SoCal-Super-Standards/boe/street-design/e-662-types-medians-7fd2bb99/"><span>Section E 662, Types of Median</span></a><span>, and </span><a href="/SoCal-Super-Standards/boe/street-design/e-557-6dc0a325/#:~:text=E%20557.3%20Traffic%20Islands"><span>Subsection E 557.3, Traffic</span><span> </span><span>Islands</span></a><span>.</span></p><h3><span>E 631.2 Temporary</span><span> </span><span>Curbs</span><span> </span><span>(Berms)</span></h3><p>Temporary curbs (berms) of either the mountable or the barrier type are constructed of asphalt concrete pavement.<span>  </span>Temporary curbs may be used under the following circumstances:</p><ol><li>Projects where temporary detours are constructed.</li><li>Half-width streets where removal is anticipated because of future full-width street improvement;</li><li>Miscellaneous locations, such as temporary transitional curb between curbs of different alignment; at points where permanent type curbs end abruptly; areas where channelization for water or traffic is needed until permanent drainage or traffic facilities are provided; etc.</li></ol></div>
      </div></div>
