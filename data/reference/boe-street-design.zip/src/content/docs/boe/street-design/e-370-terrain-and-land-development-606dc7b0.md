---
title: "E 370 Terrain and Land Development"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-300-roadway-design-controls-and-criteria-dfce77ad/">E 300 Roadway Design Controls and Criteria</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-370-terrain-and-land-development">Official BOE section</a></p>

<div><div>
        <div><p>The following discussion will cover terrain and land development and their effect on the order of importance of the different design factors and the final grade determination. The type of terrain or intensity of land development may vary within a given project. It may become necessary to rearrange the order of importance of the design factors and, in so doing, change the grade either locally or throughout the entire project.</p></div>
      </div></div>

<ul><li><a href="/SoCal-Super-Standards/boe/street-design/e-371-flat-terrain-b6e08537/">E 371 Flat Terrain</a></li><li><a href="/SoCal-Super-Standards/boe/street-design/e-372-hillside-or-4b94490e/">E 372 Hillside or Mountainous Terrain</a></li></ul>
