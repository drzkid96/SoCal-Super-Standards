---
title: "E 512 Alignment"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-510-alleys-78363aa2/">E 510 Alleys</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-500-design-criteria-special-street-components-and-projects/e-510-alleys/e-512-alignment">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>As can be observed from Figure E 611, alleys are aligned parallel to or concentric with the street property lines. Most alley alignments are arranged either singly or in the form of an intersecting “T” or “H”. In some very old subdivisions, street and alley alignments merely followed the random pattern of land development in use at that time. This policy resulted in many streets and alleys with sharp angle points, tapered widths, and abrupt jogs in the alignment. Although the streets, in most cases, have since been improved and re- aligned to modern standards, the existing alley alignments remain substandard. Frequently, corner cut-offs, which would facilitate vehicular turning movements, were not provided at the inter- sections of two alleys. Also, failure to make turn- around provisions resulted in many dead-end alleys.</p><p>The City’s policy in regard to improving these alley alignments is as follows:</p><ol><li>Angle points and abrupt alignment changes are not permitted in new developments and are corrected in existing alley alignments.</li><li>Where two alleys intersect, a triangular corner cut-off of not less than 10 feet along each alley property line should be provided.</li><li>In existing alleys where no corner cut-offs have been provided, cut-offs of less than 10 feet may be acceptable where existing improvements limit the space available.</li></ol><p>Where it is economically feasible to do so, all existing substandard alley alignments should be corrected.</p></div>
      </div></div>
