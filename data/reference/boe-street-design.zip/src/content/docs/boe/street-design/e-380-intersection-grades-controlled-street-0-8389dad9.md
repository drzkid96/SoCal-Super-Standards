---
title: "E 381 Major Highway Intersecting Major Highway"
---

<nav class="boe-crumb" aria-label="Manual location"><a href="/SoCal-Super-Standards/boe/street-design/">Street Design Manual</a> <span aria-hidden="true">/</span> <a href="/SoCal-Super-Standards/boe/street-design/e-380-intersection-grades-controlled-street-5bf4ef05/">E 380 Intersection Grades Controlled by Street Classification</a></nav>

<p class="boe-source"><a href="https://completestreetdesignmanual.engineering.lacity.gov/e-300-roadway-design-controls-and-criteria/e-380-intersection-grades-controlled-street-0">Official BOE section</a> · City revision September 1, 1970</p>

<div><div>
        <div><p>The grades of all legs of the intersection between two major two major highways should be set so that each will function as a through roadway. This requirement will usually make it necessary to construct drainage structures at the intersections to eliminate dips and cross-gutters.</p></div>
      </div></div>
